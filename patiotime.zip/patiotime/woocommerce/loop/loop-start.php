<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$loop_wrap_class = array( 'products', 'columns-' . esc_attr( wc_get_loop_prop( 'columns' ) ) );
$product_list_style = patiotime_get_theme_mod( 'patiotime_woocommerce_product_list_style' );
if ( ! empty( $product_list_style ) ) {
    array_push( $loop_wrap_class, 'pt-food-menu' );
    array_push( $loop_wrap_class, patiotime_get_theme_mod( 'patiotime_woocommerce_product_list_food_menu_style' ) );
}

if ( apply_filters( 'loftocean_woocommerce_show_add_to_cart_button_on_mobile', false ) ) {
    array_push( $loop_wrap_class, 'mobile-show-btn' );
} ?>
<ul class="<?php echo esc_attr( implode( ' ', $loop_wrap_class ) ); ?>">
