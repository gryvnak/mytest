<?php
/**
* 404 template
*/

do_action( 'patiotime_check_front_requirement' );
do_action( 'patiotime_the_404' );
