=== PatioTime ===
Author: loftocean
Requires at least: WordPress 5.3
Tested up to: WordPress 6.4
Version: 1.8.0
License: GPL-2.0-or-later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: full-width-template, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-menu, editor-style, featured-images, rtl-language-support, sticky-post, threaded-comments, translation-ready

== Description ==
PatioTime is a Restaurant WordPress theme.

== Copyright ==
(c) Copyright Loft.Ocean 2022 to 2024 loftocean.com

PatioTime bundles the following third-party resources:

HTML5 Shiv v3.7.3, @afarkas @jdalton @jon_neal @rem
Licenses: MIT/GPL2
Source: https://github.com/aFarkas/html5shiv

Font Awesome 5.12.1, by @davegandy - http://fontawesome.io - @fontawesome
Licenses: Full Font Awesome Free license, http://fontawesome.io/license
Source: http://fontawesome.io

Elegant Icon Font, Copyright (c) Elegant Themes
Licenses: GPL v2.0 and MIT license, http://www.gnu.org/licenses/gpl-2.0.html, https://opensource.org/licenses/MIT
Source: https://www.elegantthemes.com/blog/resources/elegant-icon-font

Modernizr v2.8.3, copyright (c) Faruk Ates, Paul Irish, Alex Sexton
Licenses: BSD and MIT, www.modernizr.com/license/
Source: www.modernizr.com

FitVids 1.1, Copyright 2013, Chris Coyier
Licenses: WTFPL, http://sam.zoy.org/wtfpl/
Source: http://fitvidsjs.com/

Slick Slider 1.6.0, Ken Wheeler
Licensed: MIT, https://github.com/kenwheeler/slick/blob/master/LICENSE
Source: http://kenwheeler.github.io/slick/

All photos are licensed under The Unsplash License (https://unsplash.com/license)

== Changelog ==
= 1.8.0 =
* New: New Demo - Fine Dining
* New: Added a new custom widget for Elementor - PT Vertical Timeline
* New: PT Call To Action - Option to set image border radius
* New: PT Call To Action - Options to set inner border's color, border width, border radius and intentation
* New: PT Call To Action - Options to set overlay's border radius and intentation
* New: PT Call To Action - Option to always display text on touch screens when text visibility is set to Hover to Display
* New: PT Food Menu - Options to force titles to wrap on desktop/tablet view
* New: Option to adjust page title section's margin top below overlay site header
* Improved: Translation of OpenTable forms
* Fixed: PT Blog - Post source not working properly when there are multiple PT Blog widgets on the same page
* Fixed: Potential download issue in PatioTime Template Library
* Fixed: Style issues with WooCommerce's New Block Cart and Block Checkout
* Fixed: Minor CSS Issues
* Updated: Google Fonts List
* Updated: Required plugin PatioTime Core updated to v1.8.0

= 1.7.0 =
* Fixed: Compatibility issues between theme's custom Elementor elements and WPML
* Fixed: Minor compatibility issues with Elementor Pro
* Fixed: A minor compatibility issue with PHP 8.2
* Fixed: Warning message when enabling Elementor's Additional Custom Breakpoints feature
* Updated: Required plugin PatioTime Core updated to v1.7.0

= 1.6.0 =
* New: New Demo - Afternoon Tea & Drinks
* New: PT Mini Cart - Show Item Indicator
* New: PT Mini Cart - Options to set Item Indicator background and text color
* Improved: Compatibility with WordPress 6.3
* Fixed: PT Food Card - Predefined colors for Extra Label & Content not working
* Updated: Required plugin PatioTime Core updated to v1.6.0

= 1.5.0 =
* New: PT OpenTable - Set How far in advance can guests book online
* New: PT OpenTable - Set custom time slots
* New: PT OpenTable - Set custom number of guests
* New: Elementor Page Settings - Option to change color scheme for a specific page
* Improved: Theme Optmization for Elementor Flexbox Container (Still in beta, please use with caution)
* Fixed: Main Menu dropdown submenus could not be displayed on touch screen devices
* Fixed: The height of the background image is calculated incorrectly after the parallax animation is enabled for the section background image in the PT Slider
* Fixed: Minor CSS Issues
* Updated: Required plugin PatioTime Core updated to v1.5.0

= 1.4.0 =
* New: Option to show Add To Cart buttons for WooCommerce Products List on mobile devices
* New: PT Restaurant Info element - Option to open address link in a new tab
* New: PT Social Menu element - Options to adjust icon spacing and icon colors
* Improved: The issue of highlighting multiple anchors in the navigation menu at the same time
* Fixed: Minor CSS Issues
* Updated: Google Fonts List
* Updated: Required plugin PatioTime Core updated to v1.4.0

= 1.3.0 =
* New: PT Food Menu element - Option to add link to image
* New: PT Tabs - Active one of the tabs via URL
* New: Social Sharing - Added LinkedIn
* New: Social Menu Icons - Added Whatsapp
* New: PT Section Title element - Added option to tweak paragraph spacing for Text
* New: Single Post - Added option to hide post title section on that post
* New: Single Products - Added global options to hide top title section and select another site header for all single products (Options are in Customizer > WooCommerce > PT Extra)
* Fixed: Compatibility issue with Elementor 3.10.0 (released on January 10, 2023)
* Fixed: WordPress static "Posts" Page - "Hide Page Title Section" option not working
* Updated: Required plugin PatioTime Core updated to v1.3.0

= 1.2.0 =
* Added: New Demo - Pastry & Cafe
* Added: Search - Option to select post types to search for
* Added: PT Food Menu element - Option to show lines on mobile devices
* Added: PT Testimonial element - Option to change width of testimonial author image
* Added: PT Testimonial element - Option to change color of Star Rating
* Added: PT Rounded Image element - Option to add links to images
* Added: PT Call To Action element - Option to control Text Visibility
* Added: PT Call To Action element - Option to show or hide Inner Border
* Added: PT Navigation Menu element - Option to tweak Top Offset of submenu toggle buttons for Mobile Menu style
* Added: PT Instagram element - New Layout: Mosaic 2
* Improved: PT Food Menu element - Support adding HTML code to menu titles
* Improved: Single Page Title Section style for The Events Calendar plugin
* Fixed: Styling issue for custom 404 page
* Fixed: PT Testimonial element - Quote Mark sometimes not hidden correctly
* Fixed: Minor CSS Issues under Windows
* Updated: Required plugin PatioTime Core updated to v1.2.0

= 1.1.1 =
* Added: Support choosing custom site footer for different pages
* Added: Support choosing custom mobile menu for different pages
* Added: PT Products element - Option to enable products navigation
* Added: PT OpenTable element - Option to change date format
* Added: PT Count Down element - Option to adjust item spacing
* Added: PT Testimonials element - Option to display Star Rating
* Added: PT Testimonials element - Option to hide Quote Mark
* Added: Menu Toggle Button element - Added 2 new icon styles
* Added: Menu Toggle Button element - Option to add text
* Added: Menu Toggle Button element - Option to reverse position of icon and text
* Added: Options to change text alignment of elements in Elementor Section
* Improved: Food Menu Style for Products list on mobile view
* Updated: Required plugin PatioTime Core updated to v1.1.1

= 1.1.0 =
* Added: New Demo - Steakhouse
* Added: Options to change colors for Slider Arrows & Slider Dots
* Added: PT Button element - Option to change text color for Underline style buttons
* Added: PT Food Menu element - Added a new style option to hide lines
* Added: PT List element - Unordered List - Added option to change vertical alignment of icons
* Added: OpenTable Form element - Added option to change submit button colors
* Added: Contact Form 7 element - Added option to change submit button colors
* Added: PT Products element - Added options to change product list style to food menu layout and style
* Added: WooCommerce's Filter By Price widget - Added option to change the Filter button style: Default / Solid / Outline
* Added: WooCommerce Product Catalog - Added option to change product list style to food menu layout and style
* Added: WooCommerce Product Catalog - Added option to show product's short description
* Improved: Updated meta tag to include viewport-fit=cover for browser to extend the viewport under the notch and home bar in iPhone landscape mode
* Improved: For One Page Site and Sidemenu - Close Sidemenu automatically when clicking on any menu item
* Fixed: Custom Widget - PatioTime Instagram - Column settings did not work
* Fixed: WooCommerce Product Catalog - 1 Column Layout did not work
* Fixed: Other minor CSS issues
* Updated: Required plugin PatioTime Core updated to v1.1.0

= 1.0.5 =
* Added: New Demo - Sushi/Japanese Restaurant
* Added: Sidebar Layout Options for Shop pages
* Improved: Compatibility with WPML
* Improved: Compatibility with Polylang
* Fixed: Minor CSS Issues
* Updated: Required plugin PatioTime Core updated to v1.0.5

= 1.0.4 =
* Added: New Demo - Seafood Restaurant
* Added: Support adding Adobe Fonts (Typekit)
* Added: Support uploading custom fonts
* Added: Food Menu element - Options to adjust colors and typography of Multi-Price Labels
* Added: Button elements - Popup Box - More options to change popup's styles 
* Added: Option to change the post title section size for all single posts
* Improved: Close Sidemenu automatically when popup box opens
* Updated: Required plugin PatioTime Core updated to v1.0.4

= 1.0.3 =
* Fixed: Minor CSS Issues
* Updated: Import Demo Data
* Updated: Required plugin PatioTime Core updated to v1.0.3

= 1.0.2 =
* Added: Food Menu element - options to change colors of each label
* Added: Navigation Menu element - option to adjust the side paddings of menu items
* Added: Menu Toggle Button element - options to change the width and height of lines in the icon 
* Added: Instagram element - options to change the title's width, height, colors and typography
* Fixed: RTL minor style issues
* Updated: Import Data for Bar Demo
* Updated: Required plugin PatioTime Core updated to v1.0.2

= 1.0.1 =
* Improved: Instagram related functions
* Fixed: Minor bugs of custom widgets

= 1.0.0 =
* Initial Release
