( function( $ ) {
	"use strict";
	var tagA = document.createElement( 'a' ), cookieRootPath = '', $doc = $( document ), $win = $( window );

	tagA.href = patiotimeHelper && patiotimeHelper.siteURL ? patiotimeHelper.siteURL : '';
	cookieRootPath = tagA.pathname;

	window.patiotimeIsRTL = $( 'body' ).hasClass( 'rtl' );
	window.patiotimeParseInt = function ( val ) {
		return val ? parseInt( val, 10 ) : 0;
	}
	function patiotimeSetWindowProps( e ) {
		var top = patiotimeParseInt( $win.scrollTop() ), goUp = top < $win.previousTop;
		$win.previousTop = top;
		return { 'top': top, 'goUp': goUp, 'originalEvent': e };
	}
	$win.previousTop = patiotimeParseInt( $win.scrollTop() );
	window.patiotimeInnerHeight = patiotimeParseInt( $win.innerHeight() );
	window.patiotimeInnerWidth = patiotimeParseInt( $win.innerWidth() );
	document.addEventListener( 'DOMContentLoaded', function() {
		$win.on( 'resize', function( e ) {
			window.patiotimeInnerHeight = patiotimeParseInt( $win.innerHeight() );
			window.patiotimeInnerWidth = patiotimeParseInt( $win.innerWidth() );
			$doc.trigger( 'resize.patiotime.window', patiotimeSetWindowProps( e ) );
		} )
		.on( 'scroll', function( e ) {
			if ( Math.abs( patiotimeParseInt( $win.scrollTop() ) - $win.previousTop ) > 3 ) {
				$doc.trigger( 'scrolling.patiotime.window', patiotimeSetWindowProps( e ) );
			}
		} );
	} );

	$.fn.patiotimeJustifiedGallery = function() {
		if ( ! $( this ).length ) return;
		return $( this ).each( function() {
			var $gallery = $( this );
			$gallery.children( '.image-gallery' ).justifiedGallery( {
				'rtl': patiotimeIsRTL,
				'rowHeight': $gallery.data( 'row-height' ),
				'lastRow': $gallery.data( 'last-row' ),
				'margins': $gallery.data( 'margin' ),
				'captions': false
			} ).on( 'jg.complete', function( e ) {
				$gallery.addClass( 'justified-gallery-initialized' );
				$( document ).trigger( 'changed.patiotime.mainContent' );
			} );
		} );
	}

	$.fn.patiotimeSlickSlider = function( args ) {
		if ( ! $( this ).length ) return;

		args.rtl = patiotimeIsRTL;

		return $( this ).each( function() {
			$( this ).on( 'init', function( e ) {
				$( this ).find( '.gallery-item, .related-post' ).removeClass( 'hide' );
				$.fn.loftoceanImageLoading ? $( this ).loftoceanImageLoading() : '';
			} ).slick( args );
		} );
	}

	window.patiotimeCookie = {
		set: function( name, value, days ) {
			try {
			   	var expires = "";
				if ( days ) {
				   var date = new Date();
				   date.setTime( date.getTime() + ( days * 24 * 60 * 60 * 1000 ) );
				   expires = "; expires=" + date.toGMTString();
			   }
			   document.cookie = name + "=" + value + expires + "; path=" + cookieRootPath;
		   } catch( msg ) {}
	   },
	   get: function( name ) {
		   	try {
				var nameEQ = name + "=";
				var ca = document.cookie.split( ';' );
				for ( var i = 0; i < ca.length; i++ ) {
					var c = ca[i];
					while ( c.charAt(0) == " " ) {
						c = c.substring( 1, c.length );
					}
					if ( c.indexOf( nameEQ ) == 0 ) {
						return c.substring(nameEQ.length, c.length);
					}
				}
				return null;
			} catch ( msg ) {
				return null;
			}
		},
		remove: function( name ) {
			patiotimeCookie.set( name, '', -1 );
		}
	};

	window.patiotimeSessionStorage = {
		getItem: function( name ) {
			try {
				return sessionStorage.getItem( name );
			} catch ( msg ) {
				return null;
			}
		},
		setItem: function( name, value ) {
			try {
				sessionStorage.setItem( name, value );
			} catch ( msg ) {}
		}
	};

	window.patiotimeLocalStorage = {
		getItem: function( name ) {
			try {
				return localStorage.getItem( name );
			} catch ( msg ) {
				return null;
			}
		},
		setItem: function( name, value ) {
			try {
				localStorage.setItem( name, value );
			} catch ( msg ) {}
		}
	};

	$.fn.fixGoogleAdsenseInlineStyles = function() {
		var flex = document.getElementById( 'secondary' );
		const observer = new MutationObserver( function( mutations, observer ) {
			flex.style.height = "";
		} );
		observer.observe( flex, {
			attributes: true,
			attributeFilter: [ 'style' ]
		} );
		return this;
	}
} ) ( jQuery );
