( function( $ ) {
	"use strict";
    function patiotimeCheckPopupBox() {
        if ( $( '.pt-popup.pt-popup-box.pt-site-popup' ).length ) {
            var currentTime = ( new Date() ).getTime();
            if ( patiotimePopupBox.oncePerSession ) {
				var visited = ( 'on' == patiotimeLocalStorage.getItem( 'patiotimePopupBoxVisited' ) ), autoPopupMaxDuration = 600000,
					lastVisitTime = patiotimeLocalStorage.getItem( 'patiotimePopupBoxLastVisitTimestamp' ) || 1;

				patiotimeLocalStorage.setItem( 'patiotimePopupBoxLastVisitTimestamp', currentTime );
                if ( visited && ( ( currentTime - lastVisitTime ) < autoPopupMaxDuration ) ) {
                    return false;
                } else {
					patiotimeLocalStorage.setItem( 'patiotimePopupBoxVisited', 'on' );
                }
            }
            patiotimeShowPopupBox();
        }
    }
    function patiotimeShowPopupBox() {
        var timer = false, $popupForm = $( '.pt-popup.pt-popup-box.pt-site-popup' );
        if ( patiotimePopupBox.timer && ( timer = patiotimeParseInt( patiotimePopupBox.timer ) ) ) {
            setTimeout( function() { $popupForm.addClass( 'show' ); }, timer * 1000 )
        } else {
            $popupForm.addClass( 'show' );
        }
    }

    $( document ).on( 'patiotime.init', function() {
        var $popupBox = $( '.pt-popup.pt-popup-box.pt-site-popup' ), hasPopupBox = $popupBox.length;
        if ( hasPopupBox && patiotimePopupBox ) {
            patiotimeCheckPopupBox();
            $( 'body' ).on( 'click', '.pt-popup.pt-popup-box.pt-site-popup.show .close-button', function( e ) {
    			e.preventDefault();
    			$popupBox.removeClass( 'show' );
    		} )
			.on( 'click', function( e ) {
				if ( $popupBox.hasClass( 'show' ) ) {
					var $target = $( e.target );
					if ( $target.parents( '.pt-popup.pt-popup-box.pt-site-popup' ).length ) {
						$target.hasClass( 'container' ) || $target.parents( '.container' ).length ? '' : $popupBox.removeClass( 'show' );
					} else {
						$popupBox.removeClass( 'show' );
					}
				}
			} );
        }
    } );
} ) ( jQuery );
