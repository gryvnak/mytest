( function( $ ) {
	"use strict";
    var $cookieLaw = $( '.pt-cookies-popup' );
    if ( $cookieLaw.length && patiotimeCookieLaw && patiotimeCookieLaw.version ) {
        var sessionID = 'patiotimeCookieLaw' + patiotimeCookieLaw.version, visited = patiotimeLocalStorage.getItem( sessionID ),
            sessionStamp = patiotimeLocalStorage.getItem( sessionID + 'Stamp' ), now = ( new Date() ).getTime(), duration = 2592000000;
        if ( visited && sessionStamp && ( 'on' == visited ) && ( now - sessionStamp < duration ) ) {
            patiotimeLocalStorage.setItem( sessionID + 'Stamp', now );
            return;
        } else {
            var $win = $( window ), $doc = $( document ), cbFun = function ( top ) {
    			top > 150 ? $cookieLaw.removeClass( 'show' ) : '';
    		};
            $cookieLaw.hasClass( 'customize-preview-initial-hidden' ) ? '' : $cookieLaw.addClass( 'show' );
            if ( ! patiotimeCookieLaw.isPreview ) {
                cbFun( patiotimeParseInt( $win.scrollTop() ) );
    			$doc.on( 'scrolling.patiotime.window resize.patiotime.window', function( e, args ) {
    				cbFun( args['top'] );
    			} );
            }

            $cookieLaw.on( 'click', '.cookies-buttons > a', function( e ) {
                e.preventDefault();
                $cookieLaw.removeClass( 'show' );
                patiotimeLocalStorage.setItem( sessionID, 'on' );
                patiotimeLocalStorage.setItem( sessionID + 'Stamp', ( new Date() ).getTime() );
            } );
        }
    }
} ) ( jQuery );
