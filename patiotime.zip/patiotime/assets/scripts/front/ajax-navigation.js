( function ( $ ) {
	"user strict";
	/**
	* Callback function to show navigation if needed
	*/
	function patiotimeAjaxNav( data, $nav ) {
		if ( data && data.more ) {
			patiotimeAjaxNavigation.data.query.paged ++;
		} else {
			if ( $nav.hasClass( 'infinite' ) ) {
				$nav.find( '.load-more-btn.ajax' ).remove();
				$nav.removeClass( 'infinite' ).append( $( '<span>', { 'class': 'no-more-posts-message', 'text': patiotimeAjaxNavigation.noMoreText } ) );
			} else {
				$nav.find( '.load-more-btn.ajax.manual' ).remove();
				$nav.append( $( '<span>', { 'class': 'no-more-posts-message', 'text': patiotimeAjaxNavigation.noMoreText } ) );
			}
		}
		$nav.data( 'loading', false ).removeClass( 'loading' );
	}
	if ( patiotimeAjaxNavigation ) {
		var $doc = $( document );
		$doc.on( 'patiotimeAjaxNavigationProcessData', function( e, args ) {
			var $nav = args['target'].closest( '.navigation.pagination' ), $list = $nav.siblings( '.posts-wrapper' ).parent();
			if ( $list.length && $list.hasClass( 'posts' ) && $( args['data']['items'] ).length ) {
				var $wrap = false, $posts = $( '<div>' ).append( args['data']['items'] ), $gallery = $posts.find( '.image-gallery' ), hasGallery = $gallery.length, hasPreloader = $.fn.loftoceanImageLoading;
				$posts.children().addClass( 'new-post-item post' ).css( 'opacity', 0 );

				if ( $list.hasClass( 'layout-masonry' ) ) {
					var list = $list.data( 'post-list' ) ? $list.data( 'post-list' ) : [],
						$columns = $list.find( '.masonry-column' );
					$posts.children().each( function() {
						list.unshift( $( this ) );
					} );
					$list.data( 'post-list', list );
					if ( $list.data( 'mobile-mode' ) ) { // If in mobile mode, just append the posts
						$columns.first().append( $posts.children() );
						$( document ).trigger( 'loftcean/moreContent/loaded' );
						$list.find( '.new-post-item' ).removeClass( 'new-post-item' ).fadeTo( 300, 1 );
						patiotimeAjaxNav( args['data'], args['target'] );
						if ( hasPreloader ) {
							$list.loftoceanImageLoading();
						}
					} else { // Recalculate the height
						$columns.first().append( $posts.children() );
						$list.patiotimeMasonry( { 'post': '.post.new-post-item', 'append': true } );
						hasGallery ? $gallery.patiotimePostsGallery() : '';
						$( document ).trigger( 'loftcean/moreContent/loaded' );
						$list.find( '.new-post-item' ).removeClass( 'new-post-item' ).fadeTo( 300, 1 );
						patiotimeAjaxNav( args['data'], args['target'] );
						if ( hasPreloader ) {
			 				$list.loftoceanImageLoading();
			 			}
					}
				} else {
					$wrap = $list.find( '.posts-wrapper' );
					$wrap.append( $posts.children() );
	 				$( document ).trigger( 'loftcean/moreContent/loaded', { 'videos': ( args['data']['videos'] && Array.isArray( args['data']['videos'] ) ? args['data']['videos'] : false ) } );
					$list.find( '.new-post-item' ).removeClass( 'new-post-item' ).fadeTo( 300, 1 );
					hasGallery ? $gallery.patiotimePostsGallery() : '';
 					$( document ).trigger( 'changed.patiotime.mainContent' );
					patiotimeAjaxNav( args['data'], args['target'] );
	 				if ( hasPreloader ) {
		 				$list.loftoceanImageLoading();
		 			}
	 			}
	 		}
		} );
		$( 'body' ).on( 'patiotimeAjaxNavigationStart', '.pagination-container.load-more', function( e ) {
			e.preventDefault();
			var $nav = $( this ), $posts = $nav.parents( '.posts' );
			if ( $nav.data( 'loading' ) ) return false;

			$nav.data( 'loading', true ).addClass( 'loading' );
			var data = false;
			if ( $posts.length && $posts.first().attr( 'data-settings' ) ) {
				$posts = $posts.first();
				data = JSON.parse( $posts.attr( 'data-settings' ) );
				data[ 'query' ][ 'paged' ] += 1;
				$posts.attr( 'data-settings', JSON.stringify( data ) );
				data[ 'action' ] = patiotimeAjaxNavigation.data.action;
			} else {
				data = patiotimeAjaxNavigation.data;
			}
			$.post( patiotimeAjaxNavigation.url, data ).done( function( response ) {
				if ( response.success ) {
					$( document ).trigger( 'patiotimeAjaxNavigationProcessData', { 'data': response.data, 'target': $nav } );
				} else {
					$nav.data( 'loading', false ).removeClass( 'loading' );
				}
			} ).fail( function() {
				$nav.data( 'loading', false ).removeClass( 'loading' );
			} );
		} ).on( 'click', '.load-more-btn.ajax.manual', function( e ) {
			e.preventDefault();
			$( this ).closest( '.pagination-container.load-more' ).trigger( 'patiotimeAjaxNavigationStart' );
		} );

		$doc.data( 'previousTop', patiotimeParseInt( $( window ).scrollTop() ) );
		$doc.on( 'scrolling.patiotime.window', function( e ) {
			var $doc = $( this ), currentTop = patiotimeParseInt( $( window ).scrollTop() ),
				$autLoadMore = $( '.pagination-container.load-more.infinite' );
			if ( $autLoadMore.length && $doc.data( 'previousTop' ) && ( $doc.data( 'previousTop' ) < currentTop ) ) {
				var currentBottom = patiotimeParseInt( currentTop ) + patiotimeParseInt( $( window ).height() );
				$autLoadMore.each( function() {
					var navTop = $( this ).closest( '.navigation.pagination' ).offset().top;
					if ( ( navTop > currentTop ) &&  ( navTop < currentBottom ) ) {
						$( this ).trigger( 'patiotimeAjaxNavigationStart' );
						return false;
					}
				} );
			}
			$doc.data( 'previousTop', currentTop );
		} );
	}
} ) ( jQuery );
