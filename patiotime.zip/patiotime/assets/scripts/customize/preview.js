/**
* Copyright (c) Loft.Ocean
* http://www.loftocean.com
*/

( function( api, $, parent ) {
	"use strict";

	/** Global jQuery objects **/
	var $body = $( 'body' ), $head = $( 'head' ), $siteTitle = $( '.site-title a' ), $siteDescription = $( '.site-description' ), $toTop = $( '.to-top' ), $mobileMenuWrap = $( '.sidemenu' ),
		$popupBox = $( '.pt-popup.pt-popup-box' ), $mobileMenuContainer = $( '.sidemenu .container' ), $pageTitleSection = $( '.page-title-section' ), $cookieLaw = $( '.pt-cookies-popup' ),
		$siteFooterInstagram = $( '.site-footer .pt-widget_instagram' ), $siteFooterBottom = $( '.site-footer .site-footer-bottom' ), $defaultPageTitleBackground = $( '.page-title-default-background-image' ),
		$relatedPostTitle = $( '.related-posts .related-posts-title' ), $loader = $( '#pt-loader-wrapper' ), settingDefaultValues = {
			'patiotime_typography_heading_letter-spacing': '0',
			'patiotime_typography_subheading_letter-spacing': '0.05em',
			'patiotime_typography_text_letter-spacing': '0',
			'patiotime_typography_blog_title_letter-spacing': '0',
			'patiotime_typography_secondary_letter-spacing': '0.05em',
			'patiotime_typography_widget_title_letter-spacing': '0.05em',
			'patiotime_typography_menu_letter-spacing': '0.05em',
			'patiotime_typography_footer_bottom_menu_letter-spacing': '0'
		};

	/**
	* Get attachment url
	* @param string attachment id
	* @return mix if attachment exists attachment url, otherwise boolean false
	*/
	function getAttachmentUrl( id ) {
		if ( id && parent && parent.wp && parent.wp.media ) {
			var attachment = parent.wp.media.attachment( id );
			attachment.fetch();
			return attachment && attachment.attributes ? attachment.get( 'url' ) : false;
		}
		return false;
	}
	/**
	* Get attachment details
	*/
	function getAttachmentDetails( id ) {
		if ( id && parent && parent.wp && parent.wp.media ) {
			var attachment = parent.wp.media.attachment( id );
			attachment.fetch();
			return attachment && attachment.attributes ? attachment : false;
		}
		return false;
	}
	/**
	* Set inline styles to <head>
	* @param style id
	* @param string style
	*/
	function updateStyle( id, style ) {
		var $style 	= $head.find( '#' + id );
		style 	= style || '';
		if ( ! $style.length ) {
			$style = $( '<style>', { 'id': id } )
				.appendTo( $head );
		}
		$style.html( style );
	}
	/**
	* Refresh preview iframe
	*/
	function refreshPreviewFrame() {
		parent.wp.customize.previewer.refresh();
	}

	/** Customize setting event hanlder if their transort are set with postMessage **/
	api( 'blogname', function( value ) {
		value.bind( function( to ) {
			$siteTitle.length ? $siteTitle.text( to ) : '';
		} );
	} );
	api( 'blogdescription', function( value ) {
		value.bind( function( to ) {
			$siteDescription.length ? $siteDescription.text( to ) : '';
		} );
	} );

	// Site general
	api( 'patiotime_page_content_width', function( value ) {
		value.bind( function( to ) {
			if ( $body.length ) {
				if ( 'custom' == to ) {
					$body.removeClass( 'site-layout-fullwidth' ).addClass( 'custom-site-width' );
					updateStyle( 'patiotime-site-width', ':root { --custom-site-width: ' + api( 'patiotime_page_content_custom_width' )() + 'px; }' );
				} else {
					$body.removeClass( 'custom-site-width' ).addClass( 'site-layout-fullwidth' );
				}
			}
		} );
	} );
	api( 'patiotime_page_content_custom_width', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-site-width', ':root { --custom-site-width: ' + api( 'patiotime_page_content_custom_width' )() + 'px; }' );
		} );
	} );

	api( 'patiotime_show_back_to_top_button', function( value ) {
		value.bind( function( to ) {
			if ( $toTop.length ) {
				to ? $toTop.removeClass( 'hide' ) : $toTop.addClass( 'hide' );
			}
		} );
	} );
	api( 'patiotime_back_to_top_button_background_color', function( value ) {
		value.bind( function( to ) {
			if ( $toTop.length ) {
				$toTop.css( 'background-color', ( to ? to : 'var(--bg-color)' ) );
			}
		} );
	} );
	api( 'patiotime_back_to_top_button_icon_color', function( value ) {
		value.bind( function( to ) {
			if ( $toTop.length ) {
				$toTop.css( 'color', ( to ? to : 'var(--text-color)' ) );
			}
		} );
	} );
	api( 'patiotime_back_to_top_button_hover_background_color', function( value ) {
		value.bind( function( to ) {
			if ( $toTop.length ) {
				updateStyle( 'patiotime-back-to-top-hover-background-color', '.no-touch .to-top.show:hover { background-color: ' + ( to ? to : 'var(--bg-color)' ) + '; }' );
			}
		} );
	} );
	api( 'patiotime_back_to_top_button_hover_icon_color', function( value ) {
		value.bind( function( to ) {
			if ( $toTop.length ) {
				updateStyle( 'patiotime-back-to-top-hover-icon-color', '.no-touch .to-top.show:hover { color: ' + ( to ? to : 'var(--text-color)' ) + '; }' );
			}
		} );
	} );

	api( 'patiotime_general_cookie_law_enabled', function( value ) {
		value.bind( function( to ) {
			if ( $cookieLaw.length ) {
				to ? $cookieLaw.addClass( 'show' ) : $cookieLaw.removeClass( 'show' );
			}
		} );
	} );
	api( 'patiotime_general_cookie_law_accept_button_text', function( value ) {
		value.bind( function( to ) {
			if ( $cookieLaw.length ) {
				$cookieLaw.find( '.cookies-buttons a.button' ).text( to );
			}
		} );
	} );

	api( 'patiotime_general_popup_box_enable', function( value ) {
		value.bind( function ( to ) {
			if ( $popupBox.length ) {
				to ? $popupBox.addClass( 'show' ) : $popupBox.removeClass( 'show' );
			}
		} );
	} );
	api( 'patiotime_general_popup_box_size', function( value ) {
		value.bind( function( to ) {
			if ( $popupBox.length ) {
				if ( 'fullscreen' == to ) {
					$popupBox.addClass( 'pt-popup-fullsize' );
				} else {
					$popupBox.removeClass( 'pt-popup-fullsize' );
					updateStyle( 'patiotime-popupbox-custom-width', ':root { --popup-width: ' + api( 'patiotime_general_popup_box_custom_width' )() + 'px; }' );
				}
			}
		} );
	} );
	api( 'patiotime_general_popup_box_custom_width', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-popup-custom-width', ':root { --popup-width: ' + to + 'px; }' );
		} );
	} );
	api( 'patiotime_general_popup_box_color_scheme', function( value ) {
		value.bind( function( to ) {
			if ( $popupBox.length ) {
				$popupBox.removeClass( 'light-color dark-color' ).addClass( to );
			}
		} );
	} );
	api( 'patiotime_general_popup_box_background_color', function( value ) {
		value.bind( function( to ) {
			if ( $popupBox.length ) {
				$popupBox.css( 'background-color', to ? to : 'var(--bg-color)' );
			}
		} );
	} );
	api( 'patiotime_general_popup_box_background_image', function( value ) {
		value.bind( function( to ) {
			if ( $popupBox.length ) {
				var $background = $popupBox.find( '.screen-bg' );
				if ( to ) {
					var imageURL = getAttachmentUrl( to );
					$background.length ? $background.css( 'background-image', 'url(' + imageURL + ')' )
						: $popupBox.prepend( $( '<div>', { 'class': 'screen-bg' } ).css( 'background-image', 'url(' + imageURL + ')' ) );
				} else {
					$background.length ? $background.remove() : '';
				}
			}
		} );
	} );

	// Site header
	api( 'patiotime_mobile_site_header_copyright_text', function( value ) {
		value.bind( function( to ) {
			var $mobileCopyright = $( '.sidemenu.sidemenu-default .copyright' );
			if ( $mobileCopyright.length ) {
				to ? $mobileCopyright.html( to ).removeClass( 'hide' ) : $mobileCopyright.html( '' ).addClass( 'hide' );
			}
		} );
	} );

	api( 'patiotime_mobile_site_header_background_image', function( value ) {
		value.bind( function( to ) {
			if ( $mobileMenuContainer.length ) {
				to ? $mobileMenuContainer.css( 'background-image', 'url(' + getAttachmentUrl( to ) + ')' ) : $mobileMenuContainer.css( 'background-image', '' );
			}
		} );
	} );
	api( 'patiotime_mobile_site_header_background_color', function( value ) {
		value.bind( function( to ) {
			if ( $mobileMenuContainer.length ) {
				 $mobileMenuContainer.css( 'background-color', ( to ? to : '#000000' ) );
			}
	 	} );
	 } );
	api( 'patiotime_mobile_site_header_text_color', function( value ) {
		value.bind( function( to ) {
			if ( $mobileMenuContainer.length ) {
				 $mobileMenuContainer.css( 'color', ( to ? to : '#FFFFFF' ) );
			 }
		} );
	} );
	api( 'patiotime_mobile_site_header_entrance_animation', function( value ) {
		value.bind( function( to ) {
			if ( $mobileMenuWrap.length ) {
				$mobileMenuWrap.removeClass( 'slide-from-left fade-in' );
				to ? $mobileMenuWrap.addClass( to ) : '';
			}
		} );
	} );
	api( 'patiotime_mobile_site_header_width', function( value ) {
		value.bind( function( to ) {
			if ( $mobileMenuWrap.length ) {
				$mobileMenuWrap.removeClass( 'fullwidth custom-width' );
				to ? $mobileMenuWrap.addClass( to ) : '';
			}
		} );
	} );
	api( 'patiotime_mobile_site_header_custom_width', function( value ) {
		value.bind( function( to ) {
			if ( $mobileMenuWrap.length ) {
				updateStyle( 'patiotime-site-header-mobile-custom-width', '.sidemenu.custom-width { max-width: ' + to + 'px; }' );
			}
		} );
	} );

	// Site Footer
	api( 'patiotime_site_footer_instagram_new_tab', function( value ) {
		value.bind( function( to ) {
			if ( $siteFooterInstagram.length && $siteFooterInstagram.find( 'a' ).length ) {
				to ? $siteFooterInstagram.find( 'a' ).attr( 'target', '_blank' ) : $siteFooterInstagram.find( 'a' ).attr( 'target', '' );
			}
		} );
	} );
	api( 'patiotime_site_footer_bottom_layout', function( value ) {
		value.bind( function( to ) {
			if ( $siteFooterBottom.length ) {
				to ? $siteFooterBottom.addClass( 'column-single' ) : $siteFooterBottom.removeClass( 'column-single' );
			}
		} );
	} );
	api( 'patiotime_site_footer_bottom_text', function( value ) {
		value.bind( function( to ) {
			if ( $siteFooterBottom.length ) {
				var $textWidget = $siteFooterBottom.find( '.textwidget' );
				$textWidget.length ? $textWidget.html( to ) : refreshPreviewFrame();
			}
		} );
	} );
	api( 'patiotime_site_footer_bottom_background_color', function( value ) {
		value.bind( function( to ) {
			if ( $siteFooterBottom.length ) {
				$siteFooterBottom.css( 'background-color', ( to ? to : '#111111' ) );
			}
		} );
	} );
	api( 'patiotime_site_footer_bottom_text_color', function( value ) {
		value.bind( function( to ) {
			if ( $siteFooterBottom.length ) {
				$siteFooterBottom.css( 'color', ( to ? to : '#FFFFFF' ) );
			}
		} );
	} );

	// Colors and Styles
	api( 'patiotime_general_color_scheme', function( value ) {
		value.bind( function( to ) {
			$body.removeClass( 'light-color dark-color' ).addClass( to );
		} );
	} );
	api( 'patiotime_general_primary_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-primary-color', ':root { --primary-color: ' + ( to ? to : '#F56D6B' ) + '; } ' );
		} );
	} );
	api( 'patiotime_general_secondary_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-secondary-color', ':root { --secondary-color: ' + ( to ? to : '#C59764' ) + '; } ' );
		} );
	} );
	api( 'patiotime_general_light_scheme_background_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-light-background-color', ':root { --light-bg-color: ' + ( to ? to : '#FFFFFF' ) + '; } ' );
		} );
	} );
	api( 'patiotime_general_light_scheme_text_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-light-text-color', ':root { --light-text-color: ' + ( to ? to : '#000000' ) + '; } ' );
		} );
	} );
	api( 'patiotime_general_light_scheme_content_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-light-content-color', ':root { --light-content-color: ' + ( to ? to : '#111111' ) + '; } ' );
		} );
	} );
	api( 'patiotime_general_dark_scheme_background_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-dark-background-color', ':root { --dark-bg-color: ' + ( to ? to : '#0E0D0A' ) + '; } ' );
		} );
	} );
	api( 'patiotime_general_dark_scheme_text_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-dark-text-color', ':root { --dark-text-color: ' + ( to ? to : '#FFFFFF' ) + '; } ' );
		} );
	} );
	api( 'patiotime_general_dark_scheme_content_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-dark-content-color', ':root { --dark-content-color: ' + ( to ? to : '#EEEEEE' ) + '; } ' );
		} );
	} );

	api( 'patiotime_link_light_scheme_regular_color', function( value ) {
		value.bind( function( to ) {
			switch ( to ) {
				case 'primary':
					updateStyle( 'patiotime-light-link-color', ':root { --light-link-color: var(--primary-color); } ' );
					break;
				case 'secondary':
					updateStyle( 'patiotime-light-link-color', ':root { --light-link-color: var(--secondary-color); } ' );
					break;
				default:
					var customColor = api( 'patiotime_link_light_scheme_custom_regular_color' )();
					updateStyle( 'patiotime-light-link-color', ':root { --light-link-color: ' + ( customColor ? customColor : 'var(--primary-color)' ) + '; } ' );
			}
		} );
	} );
	api( 'patiotime_link_light_scheme_custom_regular_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-light-link-color', ':root { --light-link-color: ' + ( to ? to : 'var(--primary-color)' ) + '; } ' );
		} );
	} );
	api( 'patiotime_link_light_scheme_hover_color', function( value ) {
		value.bind( function( to ) {
			switch ( to ) {
				case 'primary':
					updateStyle( 'patiotime-light-link-hover-color', ':root { --light-link-color-hover: var(--primary-color); } ' );
					break;
				case 'secondary':
					updateStyle( 'patiotime-light-link-hover-color', ':root { --light-link-color-hover: var(--secondary-color); } ' );
					break;
				default:
					var customColor = api( 'patiotime_link_light_scheme_custom_hover_color' )();
					updateStyle( 'patiotime-light-link-hover-color', ':root { --light-link-color-hover: ' + ( customColor ? customColor : 'var(--primary-color)' ) + '; } ' );
			}
		} );
	} );
	api( 'patiotime_link_light_scheme_custom_hover_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-light-link-hover-color', ':root { --light-link-color-hover: ' + ( to ? to : 'var(--primary-color)' ) + '; } ' );
		} );
	} );
	api( 'patiotime_link_dark_scheme_regular_color', function( value ) {
		value.bind( function( to ) {
			switch ( to ) {
				case 'primary':
					updateStyle( 'patiotime-dark-link-color', ':root { --dark-link-color: var(--primary-color); } ' );
					break;
				case 'secondary':
					updateStyle( 'patiotime-dark-link-color', ':root { --dark-link-color: var(--secondary-color); } ' );
					break;
				default:
					var customColor = api( 'patiotime_link_dark_scheme_custom_regular_color' )();
					updateStyle( 'patiotime-dark-link-color', ':root { --dark-link-color: ' +  ( customColor ? customColor : 'var(--primary-color)' ) + '; } ' );
			}
		} );
	} );
	api( 'patiotime_link_dark_scheme_custom_regular_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-dark-link-color', ':root { --dark-link-color: ' + ( to ? to : 'var(--primary-color)' ) + '; } ' );
		} );
	} );
	api( 'patiotime_link_dark_scheme_hover_color', function( value ) {
		value.bind( function( to ) {
			switch ( to ) {
				case 'primary':
					updateStyle( 'patiotime-dark-link-hover-color', ':root { --dark-link-color-hover: var(--primary-color); } ' );
					break;
				case 'secondary':
					updateStyle( 'patiotime-dark-link-hover-color', ':root { --dark-link-color-hover: var(--secondary-color); } ' );
					break;
				default:
					var customColor = api( 'patiotime_link_dark_scheme_custom_hover_color' )();
					updateStyle( 'patiotime-dark-link-hover-color', ':root { --dark-link-color-hover: ' + ( customColor ? customColor : 'var(--primary-color)' ) + '; } ' );
			}
		} );
	} );
	api( 'patiotime_link_dark_scheme_custom_hover_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-darkt-link-hover-color', ':root { --dark-dark-color-hover: ' + ( to ? to : 'var(--primary-color)' ) + '; } ' );
		} );
	} );

	api( 'patiotime_button_shape', function( value ) {
		value.bind( function( to ) {
			$body.removeClass( 'pt-btn-rounded pt-btn-pill' );
			to ? $body.addClass( to ) : '';
		} );
	} );
	api( 'patiotime_button_background_color', function( value ) {
		value.bind( function( to ) {
			switch ( to ) {
				case 'primary':
					updateStyle( 'patiotime-button-background-color', ':root { --btn-bg: var(--primary-color); } ' );
					break;
				case 'secondary':
					updateStyle( 'patiotime-button-background-color', ':root { --btn-bg: var(--secondary-color); } ' );
					break;
				default:
					var customColor = api( 'patiotime_button_custom_background_color' )();
					updateStyle( 'patiotime-button-background-color', ':root { --btn-bg: ' + ( customColor ? customColor : 'var(--primary-color)' ) + '; } ' );
			}
		} );
	} );
	api( 'patiotime_button_custom_background_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-button-background-color', ':root { --btn-bg: ' + ( to ? to : 'var(--primary-color)' ) + '; } ' );
		} );
	} );
	api( 'patiotime_button_text_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-button-text-color', ':root { --btn-color: ' + ( to ? to : '#FFFFFF' ) + '; } ' );
		} );
	} );
	api( 'patiotime_button_hover_background_color', function( value ) {
		value.bind( function( to ) {
			switch ( to ) {
				case 'primary':
					updateStyle( 'patiotime-button-hover-background', ':root { --btn-bg-hover: var(--primary-color); } ' );
					break;
				case 'secondary':
					updateStyle( 'patiotime-button-hover-background', ':root { --btn-bg-hover: var(--secondary-color); } ' );
					break;
				default:
					var customColor = api( 'patiotime_button_hover_custom_background_color' )();
					updateStyle( 'patiotime-button-hover-background', ':root { --btn-bg-hover: ' + ( customColor ? customColor : 'var(--primary-color)' ) + '; } ' );
			}
		} );
	} );
	api( 'patiotime_button_hover_custom_background_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-button-hover-background', ':root { --btn-bg-hover: ' + ( to ? to : 'var(--primary-color)' ) + '; } ' );
		} );
	} );
	api( 'patiotime_button_hover_text_color', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-button-hover-text-color', ':root { --btn-color-hover: ' + ( to ? to : '#FFFFFF' ) + '; } ' );
		} );
	} );

	api( 'patiotime_form_field_style', function( value ) {
		value.bind( function( to ) {
			$body.removeClass( 'pt-form-underline pt-form-square pt-form-rounded pt-form-pill' ).addClass( to );
		} );
	} );
	api( 'patiotime_form_border_width', function( value ) {
		value.bind( function( to ) {
			updateStyle( 'patiotime-form-border', ':root { --form-bd-width: ' + ( to ? to : 0 ) + 'px; }' );
		} );
	} );

	// Typopraphy
	var typographySettings = {
		'heading': {
			'font-weight': '--hf-weight',
			'letter-spacing': '--hf-letter-spacing',
			'text-transform': '--hf-text-transform',
			'font-style': '--hf-style'
		},
		'subheading': {
			'font-size': '--shf-font-size',
			'font-weight': '--shf-weight',
			'letter-spacing': '--shf-letter-spacing',
			'text-transform': '--shf-text-transform',
			'font-style': '--shf-style'
		},
		'blog_title': {
			'font-weight': '--blog-title-weight',
			'letter-spacing': '--bt-letter-spacing',
			'text-transform': '--bt-text-transform',
			'font-style': '--bt-style'
		},
		'blog_content': {
			'font-size': '--post-text-size',
			'line-height': '--post-line-height'
		},
		'secondary': {
			'letter-spacing': '--sf-letter-spacing',
			'text-transform': '--sf-text-transform',
			'font-style': '--sf-style'
		},
		'widget_title': {
			'font-size': '--widget-title-size',
			'font-weight': '--widget-title-weight',
			'letter-spacing': '--widget-title-spacing',
			'text-transform': '--widget-title-trans',
			'font-style': '--widget-title-style'
		},
		'menu': {
			'font-size': '--nav-font-size',
			'font-weight': '--nav-font-weight',
			'letter-spacing': '--nav-font-letter-spacin',
			'text-transform': '--nav-font-transform'
		},
		'footer_bottom_menu': {
			'font-size': '--fbnav-font-size',
			'font-weight': '--fbnav-font-weight',
			'letter-spacing': '--fbnav-font-letter-spacing',
			'text-transform': '--fbnav-font-transform'
		}
	};
	var settingPrefix = 'patiotime_typography_';
	$.each( typographySettings, function( id, attrs ) {
		$.each( attrs, function( prop, cssVar ) {
			var settingID = settingPrefix + id + '_' + prop;
			api( settingID, function( value ) {
				value.bind( function( to ) {
					var currentValue = to ? to : ( settingID in settingDefaultValues ? settingDefaultValues[ settingID ] : '' );
				 	updateStyle( settingID, ':root { ' + cssVar + ': ' + currentValue + ( 'font-size' == prop ? 'px' : '' ) + '; } ' );
				} );
			} );
		} );
	} );
	var textTypographySettings = [ 'font-size', 'font-weight', 'letter-spacing', 'text-transform', 'font-style' ];
	$.each( textTypographySettings, function( index, prop ) {
		var settingID = settingPrefix + 'text_' + prop;
		api( settingID, function( value ) {
			value.bind( function( to ) {
				var currentValue = to ? to : ( settingID in settingDefaultValues ? settingDefaultValues[ settingID ] : '' );
				updateStyle( settingID, 'body { ' + prop + ': ' + to + ( 'font-size' == prop ? 'px' : '' ) + '; } ' );
			} );
		} );
	} );

	// Page title
	api( 'patiotime_page_title_section_size', function( value ) {
		value.bind( function( to ) {
			if ( $pageTitleSection.length ) {
				$pageTitleSection.removeClass( 'page-title-large page-title-small page-title-default' ).addClass( to );
			}
		} );
	} );
	api( 'patiotime_page_title_default_background_size', function( value ) {
		value.bind( function( to ) {
			if ( $defaultPageTitleBackground.length ) {
				$defaultPageTitleBackground.css( 'background-size', to );
			}
		} );
	} );
	api( 'patiotime_page_title_default_background_repeat', function( value ) {
		value.bind( function( to ) {
			if ( $defaultPageTitleBackground.length ) {
				$defaultPageTitleBackground.css( 'background-repeat', ( to ? 'repeat' : 'no-repeat' ) );
			}
		} );
	} );
	api( 'patiotime_page_title_default_background_position_x', function( value ) {
		value.bind( function( to ) {
			if ( $defaultPageTitleBackground.length ) {
				$defaultPageTitleBackground.css( 'background-position', to + ' ' + api( 'patiotime_page_title_default_background_position_y' )() );
			}
		} );
	} );
	api( 'patiotime_page_title_default_background_position_y', function( value ) {
		value.bind( function( to ) {
			if ( $defaultPageTitleBackground.length ) {
				$defaultPageTitleBackground.css( 'background-position', api( 'patiotime_page_title_default_background_position_x' )() + ' ' + to );
			}
		} );
	} );
	api( 'patiotime_page_title_default_background_attachment', function( value ) {
		value.bind( function( to ) {
			if ( $defaultPageTitleBackground.length ) {
				$defaultPageTitleBackground.css( 'background-attachment', ( to ? 'scroll' : 'fixed' ) );
			}
		} );
	} );
	api( 'patiotime_page_title_default_background_color', function( value ) {
		value.bind( function( to ) {
			if ( $pageTitleSection.length ) {
				to ? updateStyle( 'patiotime-page-title-background-color', '#page { --page-title-bg: ' + to + '; } ' ) : refreshPreviewFrame();
			}
		} );
	} );
	api( 'patiotime_page_title_default_text_color', function( value ) {
		value.bind( function( to ) {
			if ( $pageTitleSection.length ) {
				to ? updateStyle( 'patiotime-page-title-text-color', '#page { --page-title-color: ' + to + '; } ' ) : refreshPreviewFrame();
			}
		} );
	} );

	// Single post
	api( 'patiotime_blog_single_post_title_default_background_color', function( value ) {
		value.bind( function( to ) {
			if ( $pageTitleSection.length ) {
				to ? updateStyle( 'patiotime-single-title-background-color', '.single #page { --page-title-bg: ' + to + '; } ' ) : refreshPreviewFrame();
			}
		} );
	} );
	api( 'patiotime_blog_single_post_title_default_text_color', function( value ) {
		value.bind( function( to ) {
			if ( $pageTitleSection.length ) {
				to ? updateStyle( 'patiotime-single-title-text-color', '.single #page { --page-title-color: ' + to + '; } ' ) : refreshPreviewFrame();
			}
		} );
	} );
	api( 'patiotime_blog_single_post_related_post_section_title', function( value ) {
		value.bind( function( to ) {
			if ( $relatedPostTitle.length ) {
				$relatedPostTitle.text( to );
			}
		} );
	} );

	[ 'patiotime_above_site_footer_text_content', 'patiotime_general_cookie_law_message' ].forEach( function( id ) {
		api( id, function( value ) {
			value.bind( function( to ) {
				this.editorRefreshTimer ? clearTimeout( this.editorRefreshTimer ) : '';
				this.editorRefreshTimer = setTimeout( function() {
					parent.wp.customize.previewer.refresh();
				}, 600 );
			} );
		} );
	} );


	wp.customize.selectiveRefresh.bind( 'partial-content-rendered', function( placement ) {
		if ( 'patiotime_mobile_menu_content' == placement.partial.id ) {
			$mobileMenuWrap = $( '.sidemenu' );
			$mobileMenuContainer = $mobileMenuWrap.find( '.container' );
		}
	} );

	$( 'body' ).on( 'click', '.pt-popup.pt-popup-box.pt-site-popup.show .close-button', function( e ) {
		e.preventDefault();
		$popupBox.removeClass( 'show' );
	} )

} ) ( wp.customize, jQuery, parent );
