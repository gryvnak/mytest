( function( $ ) {
    "use strict";
    var $tabs = $( '#pt-dashboard-tabs-wrapper > a' ), $contents = $( '#pt-dashboard-form > .pt-dashboard-form-page' ), $demoTab = $( '#tab-demo.pt-dashboard-form-page' ),
        $hiddenActivaTab = $( 'input[name=patiotime_theme_settings_active_tab]' ), $openHours = $( '#tab-info.pt-dashboard-form-page .opening-hours-form tbody' ),
        $submenus = $( '#toplevel_page_patiotime-theme .wp-submenu > li' ).not( '.wp-submenu-head' ), $submit = $( '.pt-submit-button' ), $body = $( 'body' ),
        $customFonts = $( '.patiotime-custom-fonts-wrapper' ), $adobeID = $( '.patiotime-adobe-typekit-id' ), $adobeSyncBtn = $( '.patiotime-sync-adobe-fonts' );
    if ( $tabs.length && $contents.length ) {
        $tabs.on( 'click', function( e ) {
            e.preventDefault();
            var $tab = $( this ), targetID = $tab.attr( 'href' ), index = $tabs.index( $tab );
            if ( ! $tab.hasClass( 'nav-tab-active' ) && targetID && $contents.filter( targetID ).length ) {
                $submenus.removeClass( 'current' ).eq( index ).addClass( 'current' );
                [ '#tab-support', '#tab-demo', '#tab-tools', '#tab-integrations' ].includes( targetID ) ? $submit.hide() : $submit.show();

                $tabs.removeClass( 'nav-tab-active' );
                $tab.addClass( 'nav-tab-active' );
                $contents.removeClass( 'tab-active' );
                $contents.filter( targetID ).addClass( 'tab-active' );
                $hiddenActivaTab.val( targetID.replace( '#', '' ) );

            }
            return false;
        } );
    }
    if ( $openHours.length ) {
        $openHours.on( 'click', '.add', function( e ) {
            e.preventDefault();
            var $tr = $( this ).closest( 'tr' ).clone( true, true );
            $tr.find( 'input[type=text]' ).val( '' );
            $openHours.append( $tr );
            $openHours.find( 'tr' ).each( function( index, el ) {
                $( el ).find( 'input[type=text]' ).each( function() {
                    var $input = $( this );
                    $input.attr( 'name', $input.attr( 'name' ).replace( /\d/, index ) );
                    $input.attr( 'id', $input.attr( 'id' ).replace( /\d/, index ) );
                } );
            } );
        } ).on( 'click', '.remove', function( e ) {
            e.preventDefault();
            var $tr = $( this ).closest( 'tr' );
            if ( $tr.siblings().length ) {
                $tr.remove();
            } else {
                $tr.find( 'input[type=text]' ).val( '' );
            }
        } );
    }
    if ( $demoTab.length ) {
        $demoTab.on( 'click', '.pt-demo-box .button-install-open-modal', function( e ) {
            e.preventDefault();
            var $popup = $( this ).closest( '.pt-demo-box' ).children( '.pt-demo-popup-wrap' );
            $popup.length ? $popup.css( 'display', '' ) : '';
            return false;
        } )
        .on( 'click', '.pt-demo-popup-wrap .pt-demo-popup-corner-close', function( e ) {
            e.preventDefault();
            $( this ).closest( '.pt-demo-popup-wrap' ).css( 'display', 'none' );
            return false;
        } );
    }
    if ( $adobeID.length ) {
        var $message = $adobeID.siblings( '.message' ), message = patiotimeThemeSettings.adobeFonts.i18nText;
        $adobeID.on( 'keyup', function() {
            $message.html( '' ).hide();
        } );
        $adobeSyncBtn.on( 'click', function( e ) {
            e.preventDefault();
            $message.html( '' ).hide();
            if ( $adobeID.val() ) {
    			var $self = $( this ), url = wpApiSettings.root + 'loftocean/v1/sync-adobe-fonts/' + $adobeID.val();
    			$self.text( message[ 'sending' ] ).attr( 'disabled', 'disabled' );
    			$.get( url ).done( function( response ) {
                    if ( response.status ) {
                        $message.html( response.message ).show();
                    } else {
                        $message.html( message.error ).show();
                    }
    				$self.text( message[ 'done' ] );
    			} ).fail( function() {
                    $message.html( message.error ).show();
    				$self.text( message['fail'] );
    			} ).always( function() {
                    $self.removeAttr( 'disabled' );
                } );
            } else {
                $message.html( message.empty ).show();
            }
        } );
        $( '.patiotime-clear-adobe-fonts' ).on( 'click', function( e ) {
            e.preventDefault();
            var $self = $( this ), url = wpApiSettings.root + 'loftocean/v1/clear-adobe-fonts/';
            $adobeID.val( '' );
            $message.html( '' ).hide();
            $self.attr( 'disabled', 'disabled' );
            $.get( url ).always( function() {
                $self.removeAttr( 'disabled' );
            } );
        } );
    }
    if ( $customFonts.length ) {
        var $addBtn = $customFonts.find( '.patiotime-custom-font-add' ), tmpl = wp.template( 'patiotime-custom-font' ),
            defaultListSettins = [ { 'name': '', 'weight': '400', 'woff': '', 'woff2': '' } ], fontMedia = {
    		input: '',
    		frame: '',
    		frames: {},
    		mediaFrame: function() {
    			if ( ! this.frame ) {
    				this.frame = wp.media( {
    					id: 'patiotime-font-uploader',
    					editing: true,
    					multiple: false
    				} )
    				.on( 'select', function() {
    					var media =fontMedia.frame.state().get( 'selection' ).first().toJSON();
    					fontMedia.el.trigger( 'changed.patiotime.media', media );
    					fontMedia.el = '';
    				})
    				.on( 'open', function() {
    					var selection = fontMedia.frame.state().get( 'selection' );
    					selection.reset();
    				} );
    			}
    			return this.frame;
    		},
    		open: function( el, frame ) {
    			this.el = $( el ).first();
    			this.mediaFrame().open();
    		}
    	};
        function addDefaultCustomFontItem() {
            $addBtn.before( tmpl( { 'index': $addBtn.data( 'current-index' ), 'list': defaultListSettins } ) );
        }
        $customFonts.on( 'click', '.patiotime-custom-font-item-remove', function( e ) {
            e.preventDefault();
            var $item = $( this ).closest( '.patiotime-custom-font-item' );
            if ( ! $item.siblings( '.patiotime-custom-font-item' ).length ) {
                addDefaultCustomFontItem();
                $addBtn.data( 'current-index', ( 1 + $addBtn.data( 'current-index' ) ) );
            }
            $item.remove();
        } ).on( 'keyup', '.patiotime-custom-font-name', function( e ) {
            var $title = $( this ).closest( '.patiotime-custom-font-item' ).find( 'h3 .item-font-name' ),
                name = $( this ).val();
            if ( $title.length ) {
                name ? $title.html( ' - ' + name ) : $title.html( '' );
            }
        } ).on( 'click', '.patiotime-media-uploader', function( e ) {
            e.preventDefault();
            fontMedia.open( $( this ) );
        } ).on( 'changed.patiotime.media', '.patiotime-media-uploader', function( e, media ) {
            e.preventDefault();
            $( this ).siblings( 'input' ).val( media.url );
        } ).on( 'click', '.patiotime-media-remove', function( e ) {
            e.preventDefault();
            $( this ).siblings( 'input' ).val( '' );
        } );
        $addBtn.on( 'click', function( e ) {
            e.preventDefault();
            addDefaultCustomFontItem();
            $addBtn.data( 'current-index', ( 1 + $addBtn.data( 'current-index' ) ) );
        } );

        var defaultList = patiotimeThemeSettings && patiotimeThemeSettings.customFonts && Array.isArray( patiotimeThemeSettings.customFonts ) ? patiotimeThemeSettings.customFonts : defaultListSettins;
        $addBtn.before( tmpl( { 'index': 0, 'list': defaultList } ) );
        $addBtn.data( 'current-index', defaultList.length );
    }
} ) ( jQuery );
