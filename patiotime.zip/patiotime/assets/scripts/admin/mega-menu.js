( function( $ ) {
    "use strict";

    $( document ).on( 'ready', function() {
        var $menuEditor = $( '#menu-to-edit' );
        if ( $menuEditor.length ) {
            $menuEditor.on( 'change', '.patiotime-mega-menu-settings .patiotime-enable-mega-menu input', function( e ) {
                e.preventDefault();
                var $settings = $( this ).closest( '.patiotime-mega-menu-settings' ).find( '.mega-menu-settings' );
                if ( $( this ).is( ':checked' ) ) {
                    $settings.show();
                    $settings.filter( '.patiotime-mega-menu-drop-down-size' ).find( 'select' ).trigger( 'change' );
                } else {
                    $settings.hide();
                }
            } )
            .on( 'change', '.patiotime-mega-menu-settings .patiotime-mega-menu-drop-down-size select', function( e ) {
                e.preventDefault();
                var $customWidth = $( this ).closest( '.patiotime-mega-menu-settings' ).find( '.patiotime-dropdown-custom-width' );
                'custom-width' == $( this ).val() ? $customWidth.show() : $customWidth.hide();
            } )
            .on( 'click', '.menu-item .item-edit', function( e ) {
                var $item = $( this ).closest( '.menu-item' );
                if ( $item.hasClass( 'menu-item-edit-inactive' ) ) {
                    var $megaMenu = $item.find( '.patiotime-mega-menu-settings' ),
                        $settings = $megaMenu.find( '.mega-menu-settings' );
                    if ( $megaMenu.length ) {
                        if ( $megaMenu.find( '.patiotime-enable-mega-menu input' ).is( ':checked' ) ) {
                            $settings.show();
                            var $customWidth = $settings.filter( '.patiotime-dropdown-custom-width' );
                            ( 'fullwidth' == $megaMenu.find( '.patiotime-mega-menu-drop-down-size select' ).val() ) ? $customWidth.hide() : $customWidth.show();
                        } else {
                            $settings.hide();
                        }
                    }
                }
            } );
        }
    } );

} ) ( jQuery );
