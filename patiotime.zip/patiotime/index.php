<?php
// Main template
get_header();
$patiotime_current_archive_page = apply_filters( 'patiotime_get_current_achive_page', '' );
$patiotime_is_archvie_page = ! empty( $patiotime_current_archive_page );
$patiotime_is_archvie_page ? get_template_part( 'template-parts/page-header/archive', $patiotime_current_archive_page ) : get_template_part( 'template-parts/page-header/single-page' ); ?>

<div class="main">
	<div class="container">
		<div id="primary" class="primary content-area"><?php
        if ( $patiotime_is_archvie_page ) {
			do_action( 'patiotime_the_list_content', $patiotime_current_archive_page );
        } else {
            while( have_posts() ) {
                the_post();
                get_template_part( 'template-parts/content/single' );
            }
        } ?>
		</div>
		<?php get_sidebar(); ?>
	</div>
</div><!-- end of .main --><?php

get_footer();
