                <?php do_action( 'patiotime_the_content_close' ); ?>
            </div> <!-- end of #content -->
            <?php get_template_part( 'template-parts/site-footer/footer' ); ?>
            <?php do_action( 'patiotime_the_page_close' ); ?>
        </div> <!-- end of #page -->





<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": ["Restaurant", "BarOrPub"],
  "@id": "https://rizzlounge.com/#restaurant",
  "name": "RIZZ Lounge & Grill - Restaurant in Stamford CT",
  "alternateName": "RIZZ Lounge & Bar ",
  "url": "https://rizzlounge.com/",
  "image": "https://rizzlounge.com/wp-content/uploads/2026/02/Untitled-2-2026-02-09T160222.676.jpg",
  "logo": "https://rizzlounge.com/wp-content/uploads/2022/07/logo-1_2-white-1.png",
  "description": "RIZZ Lounge & Grill is a restaurant, lounge and grill in Stamford, CT offering contemporary dining, cocktails, live music, events and private dining.",
  "telephone": "+12039995708",
  "email": "info@rizzlounge.com",
  "priceRange": "$$",
  "servesCuisine": [
    "European",
    "Ukrainian",
    "American",
    "Grill",
    "Steakhouse"
  ],
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "121 Towne Street",
    "addressLocality": "Stamford",
    "addressRegion": "CT",
    "postalCode": "06902",
    "addressCountry": "US"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 41.0447394,
    "longitude": -73.5344665
  },
  "hasMap": "https://www.google.com/maps/place/RIZZ+Lounge+%26+Grill/@41.0447394,-73.5344665,17z/",
  "openingHoursSpecification": [
    {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": "Monday",
      "opens": "00:00",
      "closes": "00:00"
    },
    {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": [
        "Tuesday",
        "Wednesday",
        "Thursday"
      ],
      "opens": "17:00",
      "closes": "23:00"
    },
    {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": [
        "Friday",
        "Saturday"
      ],
      "opens": "15:00",
      "closes": "02:00"
    },
    {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": "Sunday",
      "opens": "14:00",
      "closes": "22:00"
    }
  ],
  "acceptsReservations": true,
  "potentialAction": {
    "@type": "ReserveAction",
    "target": {
      "@type": "EntryPoint",
      "urlTemplate": "https://rizzlounge.com/contact/",
      "inLanguage": "en-US",
      "actionPlatform": [
        "https://schema.org/DesktopWebPlatform",
        "https://schema.org/MobileWebPlatform"
      ]
    },
    "result": {
      "@type": "Reservation",
      "name": "Reserve a table at RIZZ Lounge & Grill"
    }
  },
  "sameAs": [
    "https://www.instagram.com/rizz_lounge/",
    "https://www.facebook.com/61576801700231/"
  ],
  "menu": "https://rizzlounge.com/menu/"
}
</script>


        <?php wp_footer(); ?>
        <?php do_action( 'patiotime_after_site_footer' ); ?>



    </body>
</html>
