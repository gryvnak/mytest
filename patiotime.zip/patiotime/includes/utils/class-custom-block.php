<?php
if ( ! class_exists( 'PatioTime_Utils_Custom_Block' ) ) {
	class PatioTime_Utils_Custom_Block {
        /**
        * Array cache the request results
        */
        protected static $cache = array();
		/**
		* Array site header args
		*/
		protected static $site_header_args = false;
        /**
        * Boolean if required plugins activated
        */
        protected static $is_plugins_activated = false;
        /**
        * Setup the initial status
        */
        public static function init() {
            PatioTime_Utils_Custom_Block::$is_plugins_activated = patiotime_is_theme_core_activated();

			add_filter( 'patiotime_get_custom_post_type', 'PatioTime_Utils_Custom_Block::get_custom_post_type_list', 10, 2 );
            add_action( 'patiotime_the_site_header', 'PatioTime_Utils_Custom_Block::the_site_header' );
			add_action( 'patiotime_the_main_site_footer', 'PatioTime_Utils_Custom_Block::the_main_site_footer' );
			add_action( 'patiotime_the_before_site_footer', 'PatioTime_Utils_Custom_Block::the_before_site_footer' );
			add_action( 'patiotime_the_mobile_menu', 'PatioTime_Utils_Custom_Block::the_mobile_menu' );
			add_action( 'patiotime_the_404', 'PatioTime_Utils_Custom_Block::the_404' );

			add_action( 'loftocean_custom_site_headers_before', 'PatioTime_Utils_Custom_Block::custom_site_header_before' );
			add_action( 'loftocean_custom_site_headers_after', 'PatioTime_Utils_Custom_Block::custom_site_header_after' );
        }
		/**
		* Get custom post type list
		*/
		public static function get_custom_post_type_list( $list, $post_type ) {
			if ( ! empty( $post_type ) && post_type_exists( $post_type ) ) {
				if ( ! isset( self::$cache[ $post_type ] ) ) {
					self::$cache[ $post_type ] = apply_filters( 'loftocean_get_custom_post_type_list', array(), $post_type );
				}
				return self::$cache[ $post_type ];
			}
			return array( '0' => esc_html__( 'Choose from the list', 'patiotime' ) );
		}
        /**
        * Check if use the custom block item
        */
        public static function check_custom_block( $custom_block ) {
			return PatioTime_Utils_Custom_Block::$is_plugins_activated && patiotime_does_item_exist( $custom_block );
        }
        /**
        * Show the site header
        */
        public static function the_site_header() {
			if ( apply_filters( 'patiotime_show_site_header', true ) ) {
				$customize_is_custom_site_header = ( 'custom' ==  patiotime_get_theme_mod( 'patiotime_site_header' ) );
				$is_custom_site_header = apply_filters( 'patiotime_is_custom_site_header', $customize_is_custom_site_header );
				if ( $is_custom_site_header ) {
					$custom_block = apply_filters(
						'patiotime_site_header_custom_block',
						( $customize_is_custom_site_header ? patiotime_get_theme_mod( 'patiotime_site_header_main_custom_block' ) : '' )
					);
					if ( PatioTime_Utils_Custom_Block::check_custom_block( $custom_block ) ) {
						self::$site_header_args = array( 'data' => apply_filters( 'patiotime_get_site_header_attrs', array( 'data-sticky-status' => patiotime_get_theme_mod( 'patiotime_sticky_site_header' ) ) ) );
						do_action( 'loftocean_the_custom_site_headers_content', $custom_block );
					} else {
		            	PatioTime_Utils_Custom_Block::the_template_part( 'template-parts/defaults/site-header', array( 'site_header' => 'custom' ) );
					}

					if ( 'disable' != patiotime_get_theme_mod( 'patiotime_sticky_site_header' ) ) {
						$sticky_custom_block = apply_filters(
							'patiotime_sticky_site_header_custom_block',
							( $customize_is_custom_site_header ? patiotime_get_theme_mod( 'patiotime_sticky_site_header_custom_block' ) : '' )
						);
						if ( PatioTime_Utils_Custom_Block::check_custom_block( $sticky_custom_block ) ) {
							self::$site_header_args = array( 'id' => 'sticky-site-header', 'class' => array( 'site-header', 'custom-sticky-header', 'hide' ) );
							do_action( 'loftocean_the_custom_site_headers_content', $sticky_custom_block );
						}
					}
				} else {
					PatioTime_Utils_Custom_Block::the_template_part( 'template-parts/defaults/site-header', array( 'site_header' => 'default' ) );
				}
			}
        }
        /**
        * Show the site footer main section
        */
        public static function the_main_site_footer() {
			if ( apply_filters( 'patiotime_show_main_site_footer', true ) ) :
				$custom_block = apply_filters( 'patiotime_custom_site_footer_main', patiotime_get_theme_mod( 'patiotime_site_footer_main_custom_block' ) );
				if ( PatioTime_Utils_Custom_Block::check_custom_block( $custom_block ) ) : ?>
					<div class="site-footer-main">
						<div class="container"><?php do_action( 'loftocean_the_custom_blocks_content', $custom_block ); ?></div>
					</div><?php
				endif;
			endif;
        }
        /**
        * Show the section above site footer
        */
        public static function the_before_site_footer() {
			if ( apply_filters( 'patiotime_show_before_site_footer', true ) ) :
				$custom_site_footer_above = apply_filters( 'patiotime_custom_site_footer_above', false );
				if ( ! empty( $custom_site_footer_above ) && PatioTime_Utils_Custom_Block::check_custom_block( $custom_site_footer_above ) ) : ?>
					<div class="before-footer">
						<div class="container"><?php do_action( 'loftocean_the_custom_blocks_content', $custom_site_footer_above ); ?></div>
					</div><?php
				else :
					if ( 'text' == patiotime_get_theme_mod( 'patiotime_above_site_footer_content_source' ) ) :
						PatioTime_Utils_Custom_Block::the_template_part( 'template-parts/defaults/before-site-footer' );
					else :
						$custom_block = patiotime_get_theme_mod( 'patiotime_above_site_footer_custom_block' );
						if ( PatioTime_Utils_Custom_Block::check_custom_block( $custom_block ) ) : ?>
							<div class="before-footer">
								<div class="container"><?php do_action( 'loftocean_the_custom_blocks_content', $custom_block ); ?></div>
							</div><?php
						endif;
					endif;
				endif;
			endif;
        }
        /**
        * Show the site footer
        */
        public static function the_mobile_menu( $args = array() ) {
			$custom_block = apply_filters( 'patiotime_custom_mobile_menu', patiotime_get_theme_mod( 'patiotime_mobile_site_header_menu' ) );
			if ( PatioTime_Utils_Custom_Block::check_custom_block( $custom_block ) ) :
				self::mobile_menu_wrapper_start( $args ); ?>
						<div class="sidemenu-header">
			                <span class="close-button"><?php esc_html_e( 'Close', 'patiotime' ); ?></span>
			            </div>
						<div class="sidemenu-content"><?php do_action( 'loftocean_the_custom_blocks_content', $custom_block ); ?></div>
					</div>
				</div><?php
			else :
				PatioTime_Utils_Custom_Block::the_template_part( 'template-parts/defaults/mobile-menu', $args );
			endif;
        }
        /**
        * Show the site footer
        */
        public static function the_404() {
			if ( apply_filters( 'patiotime_is_custom_404', false ) ) {
				PatioTime_Utils_Custom_Block::the_template_part( 'template-parts/content/custom-404' );
			} else {
				PatioTime_Utils_Custom_Block::the_template_part( 'template-parts/defaults/404' );
			}
        }
		/**
		* Display the template part
		*/
		protected static function the_template_part( $file, $args = array() ) {
			get_template_part( $file, '', $args );
		}
		/**
		* Custom site header before
		*/
		public static function custom_site_header_before( $args ) {
			if ( self::$site_header_args ) :
				$attrs = array_merge( array( 'id' => 'masthead', 'class' => array( 'site-header' ), 'data' => array() ), self::$site_header_args );
				$attrs[ 'class' ] = is_array( $attrs[ 'class' ] ) ? $attrs[ 'class' ] : (array)$attrs[ 'class' ];
				if ( ! empty( $args ) && ! empty( $args[ 'enable_overlap' ] ) && ( 'on' == $args[ 'enable_overlap' ] ) ) {
					array_push( $attrs[ 'class' ], 'overlap-header' );
				} ?>
				<header id="<?php echo esc_attr( $attrs[ 'id' ] ); ?>" class="<?php echo esc_attr( implode( ' ', $attrs[ 'class' ] ) ); ?>"<?php patiotime_the_tag_attributes( $attrs[ 'data' ] ); ?>><?php
			endif;
		}
		/**
		* Custom site header after
		*/
		public static function custom_site_header_after() {
			if ( self::$site_header_args ) : ?>
				</header><?php
				self::$site_header_args = false;
			endif;
		}
		/**
		* Mobile menu wrapper start
		*/
		public static function mobile_menu_wrapper_start( $args ) {
			if ( apply_filters( 'patiotime_mobile_menu_from_custom_settings', false ) ) :
				$attrs = apply_filters( 'patiotime_mobile_menu_wrapper_start_attributes', array() ); ?>
				<div <?php self::the_html_attributes( $attrs ); ?>>
					<div class="container"><?php
			else :
				$wrap_class = isset( $args, $args[ 'class' ] ) ? 'sidemenu-custom ' . $args[ 'class' ] : 'sidemenu-custom';  ?>
				<div <?php patiotime_the_mobile_menu_class( $wrap_class ); ?>><?php
				$mobile_site_header_background_image = patiotime_get_theme_mod( 'patiotime_mobile_site_header_background_image' );
			    $background_image_args = array(
			        'id' 	=> $mobile_site_header_background_image,
			        'sizes' => PatioTime_Utils_Image::get_image_sizes( array( 'module' => 'site', 'sub_module' => 'mobile-menu-background' ) )
			    ); ?>
					<div class="container"<?php patiotime_does_attachment_exist( $mobile_site_header_background_image ) ? patiotime_the_background_image_attrs( $background_image_args ) : ''; ?>><?php
			endif;
		}
		/**
		* Printe html attributes
		*/
		public static function the_html_attributes( $attrs ) {
			if ( patiotime_is_valid_array( $attrs ) ) {
				foreach( $attrs as $name => $value ) {
					printf( ' %1$s="%2$s"', esc_attr( $name ), esc_attr( $value ) );
				}
			}
		}
    }
    PatioTime_Utils_Custom_Block::init();
}
