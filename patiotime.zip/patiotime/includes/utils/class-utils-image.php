<?php
if ( ! class_exists( 'PatioTime_Utils_Image' ) ) {
	class PatioTime_Utils_Image {
		/**
		* Boolean if is mobile device
		*/
		public static $is_mobile = false;
		/**
		* String default image size, for image tag or static source requested
		*/
		public static $default_size = 'full';
		/**
		* Array default image sizes
		*	1. First element for normal device
		* 	2. Second element for retina device
		*/
		public static $default_sizes = array( 'full', 'full' );
		/**
		* Construct function
		*/
		public static function init() {
			add_filter( 'loftocean_modify_image_attributes', 'PatioTime_Utils_Image::change_image_attrs', 10, 2 );
			add_filter( 'loftocean_placeholder_size', 'PatioTime_Utils_Image::placeholder_size' );
			add_filter( 'loftocean_lazy_load_image_size', 'PatioTime_Utils_Image::lazy_load_image_size' );
			add_action( 'init', 'PatioTime_Utils_Image::set_settings' );
		}
		/**
		* Setup settings
		*/
		public static function set_settings() {
			self::$is_mobile = apply_filters( 'loftocean_is_mobile', false );
		}
		/**
		* Placeholder image size
		*/
		public static function placeholder_size( $size ) {
			return 'patiotime_255x9999';
		}
		/**
		* Lazy load image size
		*/
		public static function lazy_load_image_size( $size ) {
			return '255px';
		}
		/**
		* Calculate image size for each situation
		* @param array
		*	1. String: module
		*	2. String: sub_module
		* @return array image size for normal and retina screen [ normal screen, retina screen ]
		*/
		protected static function get_image_sizes_array( $args ) {
			if ( patiotime_module_enabled( 'patiotime_general_enable_full_image_size' ) ) {
				return patiotime_module_enabled( 'patiotime_general_enable_lazy_load' ) || patiotime_module_enabled( 'patiotime_general_enable_progressive_image_loading' )
					? self::$default_sizes : array( self::$default_size );
			}

			if ( ! empty( $args['module'] ) ) {
				$sub_module = empty( $args['sub_module'] ) ? false : $args['sub_module'];

				if ( self::$is_mobile ) {
					switch ( $args['module'] ) {
						case 'instagram':
							return array( 'patiotime_600x600-crop' );
						case 'archive':
							if ( in_array( $sub_module, array( 'masonry-2cols', 'masonry-3cols', 'large' ) ) ) {
								return array( 'patiotime_550x9999' );
							} else if ( 'carousel' == $sub_module ) {
								return array( 'patiotime_300x300-crop' );
							}
							break;
						case 'widget':
							switch ( $sub_module ) {
								case 'profile-image':
								case 'banner':
									return array( 'patiotime_370x9999' );
								case 'category-background':
									return array( 'patiotime_600x9999' );
							}
							break;
						case 'singular':
							if ( 'pagination' == $sub_module ) {
								return array( 'patiotime_255x9999' );
							}
						case 'site':
							if ( 'popup-form-background' == $sub_module ) {
								return array( 'patiotime_780x9999' );
							} else if ( 'page-header-404' == $sub_module ) {
								return array( 'patiotime_300x300-crop' );
							}
							break;
						case 'block':
							switch( $sub_module ) {
								case 'inline-post':
									return array( 'patiotime_550x9999' );
							}
							break;
					}
					return array( 'patiotime_1200x9999' );
				}

				switch ( $args['module'] ) {
					case 'instagram':
						$instagram_args = array( 'location' => 'footer', 'column' => 6 );
						if ( ! empty( $args['args'] ) && is_array( $args['args'] ) ) {
							$instagram_args = array_merge( $instagram_args, $args['args'] );
						}
						switch( $instagram_args['location'] ) {
							case 'footer':
								switch( $instagram_args['column'] ) {
									case '8':
										return array( 'patiotime_255x9999', 'patiotime_550x9999' );
									case '7':
										return array( 'patiotime_370x9999', 'patiotime_550x9999' );
									case '6':
										return array( 'patiotime_370x9999', 'patiotime_780x9999' );
									case '5':
										return array( 'patiotime_550x9999', 'patiotime_780x9999' );
									default:
										return array( 'patiotime_780x9999', 'patiotime_1200x9999' );
								}
							default:
								return array( 'patiotime_255x9999', 'patiotime_255x9999' );
						}
					case 'menu':
						if ( $sub_module ) {
							switch ( $sub_module ) {
								case 'mega-menu-1':
									return array( 'patiotime_1920x9999', 'patiotime_1920x9999' );
								case 'mega-menu-2':
									return array( 'patiotime_1200x9999', 'patiotime_1920x9999' );
								case 'mega-menu-3':
									return array( 'patiotime_780x9999', 'patiotime_1440x9999' );
								default:
								 	return array( 'patiotime_550x9999', 'patiotime_1200x9999' );
							}
						}
						break;
					case 'widget':
						if ( $sub_module ) {
							switch ( $sub_module ) {
								case 'category-background':
									return array( 'patiotime_370x9999', 'patiotime_600x9999' );
								case 'banner':
									return array( 'patiotime_370x9999', 'patiotime_600x9999' );
								case 'profile-image':
								 	return array( 'medium', 'patiotime_600x9999' );
								case 'list-thumbnail':
									return array( 'thumbnail', 'thumbnail' );
								case 'list-background':
									return array( 'patiotime_600x9999', 'patiotime_600x9999' );
							}
						}
						break;
					case 'singular':
						if ( $sub_module ) {
							switch ( $sub_module ) {
								case 'pagination':
									return array( 'thumbnail', 'patiotime_255x9999' );
								case 'content': // Images inside post content
								 	return array( 'patiotime_1920x9999', 'patiotime_1920x9999' );
								case 'gallery': // Gallery inside post content
									return array( 'patiotime_1200x9999', 'patiotime_1440x9999' );
								case 'related-posts': // Related posts after post main content
								 	return array( 'patiotime_600x9999', 'patiotime_600x9999' );
								case 'popup-slider': // Popup sliders
									return array( 'patiotime_1920x9999', 'patiotime_1920x9999' );
								case 'signup-form': // Signup form background image after post main content
									return array( 'patiotime_1920x9999', 'patiotime_1920x9999' );
							}
						}
						break;
					case 'archive':
						$image_ratio = patiotime_get_post_list_prop( 'image_ratio', '' );
						$page_layout = patiotime_get_post_list_prop( 'page_layout', '' );
						$fullwidth = empty( $page_layout );

						switch ( $sub_module ) {
							case 'featured-slider':
								return array( 'patiotime_1200x9999', 'patiotime_1920x9999' );
							case 'standard':
								return $fullwidth ? array( 'patiotime_1200x9999', 'patiotime_1920x9999' ) : array( '780x9999å', 'patiotime_1440x9999' );
							case 'masonry-2cols':
								return $fullwidth ? array( 'patiotime_550x9999', 'patiotime_1200x9999' ) : array( 'patiotime_370x9999', 'patiotime_780x9999' );
							case 'masonry-3cols':
								return $fullwidth ? array( 'patiotime_370x9999', 'patiotime_780x9999' ) : array( 'patiotime_255x9999', 'patiotime_550x9999' );
							case 'list':
								return $fullwidth ? array( 'patiotime_780x9999', 'patiotime_1200x9999' ) : array( 'patiotime_550x9999', 'patiotime_780x9999' );
							case 'grid-2cols':
							case 'grid-3cols':
							case 'overlay-2cols':
							case 'overlay-3cols':
								return array( 'patiotime_780x9999', 'patiotime_1200x9999' );
						}
						break;
					case 'site':
						if ( $sub_module ) {
							switch ( $sub_module ) {
								case 'popup-background':
									return array( 'patiotime_550x9999', 'patiotime_780x9999' );
								case 'mobile-menu-background':
									return array( 'patiotime_1920x9999', 'patiotime_1920x9999' );
								case 'page-header':
								case 'footer-background-image':
									return array( 'patiotime_1920x9999', 'patiotime_1920x9999' );
								case 'page-header-404':
									return array( 'patiotime_300x300-crop', 'patiotime_600x600-crop' );
							}
						}
						break;
					case 'block':
						switch( $sub_module ) {
							case 'inline-post':
								return array( 'patiotime_255x9999', 'patiotime_370x9999' );
						}
						break;
				}
			}
			return self::$default_sizes;
		}
		/**
		* Get image sizes for given situation
		* @param array
		* @return array
		*/
		public static function get_image_sizes( $args ) {
			$sizes = self::get_image_sizes_array( $args );
			return apply_filters( 'patiotime_image_sizes', $sizes, $args );
		}
		/**
		* Get image size for given situation
		* @param array
		* @return string
		*/
		public static function get_image_size( $args ) {
			$sizes = self::get_image_sizes( $args );
			return isset( $sizes[0] ) ? $sizes[0] : self::$default_size;
		}
		/**
		* Change image attribute
		*/
		public static function change_image_attrs( $attr, $original_attrs ) {
			$attribute_sizes = PatioTime_Utils_Image::get_attribute_sizes();
			$layout = patiotime_get_post_list_prop( 'layout' );
			$col = patiotime_get_post_list_prop( 'columns' );
			$newAttr = array();
			if ( ! empty( $attribute_sizes ) ) {
				$newAttr = array( 'sizes' => $attribute_sizes );
			}
			if ( ! empty( $layout ) && ! empty( $col ) ) {
				if ( empty( $original_attrs['class'] ) ) {
					$newAttr['class'] = ' image-layout-' . $layout . '-column-' . $col;
				} else {
					$newAttr['class'] = $original_attrs['class'] . ' image-layout-' . $layout . '-column-' . $col;
				}
			}
			if ( 0 === count( $newAttr ) ) {
				return $attr;
			} else if ( empty( $attr ) ) {
				return $newAttr;
			} else {
				return array_merge( (array)$attr, $newAttr );
			}
		}
		/**
		* Get image sizes
		*/
		public static function get_attribute_sizes() {
			$layout = patiotime_get_post_list_prop( 'layout' );
			if ( ( ! patiotime_module_enabled( 'patiotime_general_enable_full_image_size' ) ) && ( ! empty( $layout ) ) ) {
				$page_layout = patiotime_get_post_list_prop( 'page_layout' );
				$fullwidth = empty( $page_layout );

				switch( $layout ) {
					case 'masonry':
						if ( self::$is_mobile ) {
							return '420px';
						} else {
							$column = patiotime_get_post_list_prop( 'columns' );
							if ( 5 == $column ) {
								return '(max-width: 1366px) 255px, 303px';
							} else if ( 3 == $column ) {
								return $fullwidth ? '(max-width: 1366px) 353px, 433px' : '(max-width: 1366px) 233px, 313px';
							} else {
								return $fullwidth ? '(max-width: 1366px) 550px, 670px' : '(max-width: 1366px) 370px, 490px';
							}
						}
						break;
					case 'large':
						if ( self::$is_mobile ) {
							return '420px';
						} else {
							return $fullwidth ? '(max-width: 1366px) 1140px, 1380px' : '(max-width: 1366px) 780px, 1020px';
						}
						break;
					case 'other':
						if ( self::$is_mobile ) {
							return '420px';
						} else {
							return $fullwidth ? '(max-width: 1366px) 540px, 660px' : '(max-width: 1366px) 360px, 480px';
						}
						break;
				}
			}
			return false;
		}
	}
	PatioTime_Utils_Image::init();
}
