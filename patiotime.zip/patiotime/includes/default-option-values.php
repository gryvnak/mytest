<?php
/**
* Theme option default values
*/

global $patiotime_default_settings;

$patiotime_default_settings = apply_filters( 'patiotime_default_option_values', array(
	// Site logo width
	'patiotime_site_logo_width'											=> 160,

	/** section general layouts **/
	'patiotime_page_content_width'										=> '',
	'patiotime_page_content_custom_width'								=> '1200',
	'patiotime_page_background_image' 									=> '',
	'patiotime_page_background_position_x' 								=> 'center',
	'patiotime_page_background_position_y' 								=> 'center',
	'patiotime_page_background_size' 									=> 'auto',
	'patiotime_page_background_repeat' 									=> '',
	'patiotime_page_background_attachment' 								=> '',

	/** section back to top **/
	'patiotime_show_back_to_top_button'									=> 'on',
	'patiotime_back_to_top_button_background_color'						=> '',
	'patiotime_back_to_top_button_icon_color'							=> '',
	'patiotime_back_to_top_button_hover_background_color'				=> '',
	'patiotime_back_to_top_button_hover_icon_color'						=> '',

	/** section social **/
	'patiotime_general_social_like'										=> '',
	'patiotime_general_social_facebook'									=> 'on',
	'patiotime_general_social_twitter'									=> 'on',
	'patiotime_general_social_linkedin'									=> '',
	'patiotime_general_social_pinterest'								=> 'on',
	'patiotime_general_social_whatsapp'									=> '',

	/** section 404 page **/
	'patiotime_general_404_page_custom_block'							=> '0',

	/** section cookie law **/
	'patiotime_general_cookie_law_enabled'								=> '',
	'patiotime_general_cookie_law_message'								=> esc_html__( 'This website uses cookies to improve your web experience.', 'patiotime' ),
	'patiotime_general_cookie_law_accept_button_text'					=> esc_html__( 'Accept', 'patiotime' ),
	'patiotime_general_cookie_law_version'								=> 1,

	/** section popup box **/
	'patiotime_general_popup_box_enable'								=> '',
	'patiotime_general_popup_box_once_per_session'						=> 'on',
	'patiotime_general_popup_box_custom_block'							=> '0',
	'patiotime_general_popup_box_display_delay'							=> '5',
	'patiotime_general_popup_box_size'									=> 'fullscreen',
	'patiotime_general_popup_box_custom_width'							=> '600',
	'patiotime_general_popup_box_color_scheme'							=> 'light-color',
	'patiotime_general_popup_box_background_color'						=> '',
	'patiotime_general_popup_box_background_image'						=> '',
	'patiotime_general_popup_box_device_visibility'						=> 'all',

	/** section search **/
	'patiotime_general_search_default_post_types'						=> array( 'post' ),

	/** section one page menu **/
	'patiotime_enable_onepage_menu_check'								=> '',

	/** section site header general **/
	'patiotime_sticky_site_header'										=> 'scroll-up-enable',
	'patiotime_site_header'												=> '',
	'patiotime_default_site_header_enable_overlap'						=> '',
	'patiotime_default_site_header_hide_top_bar'						=> '',
	'patiotime_default_site_header_hide_search_icon'					=> '',
	'patiotime_default_site_header_hide_cart'							=> '',

	'patiotime_site_header_main_custom_block'							=> '0',
	'patiotime_sticky_site_header_custom_block'							=> '0',

	/** section site header fullscreen/mobile menu **/
	'patiotime_mobile_site_header_menu'									=> '0',
	'patiotime_mobile_site_header_copyright_text'						=> esc_html__( '© Copyright PatioTime WordPress Theme for Restaurant & Cafe.', 'patiotime' ),
	'patiotime_mobile_site_header_background_color'						=> '',
	'patiotime_mobile_site_header_background_image'						=> '',
	'patiotime_mobile_site_header_text_color'							=> '',

	'patiotime_mobile_site_header_entrance_animation'					=> '',
	'patiotime_mobile_site_header_width'								=> '',
	'patiotime_mobile_site_header_custom_width'							=> 375,

	/** section site footer main **/
	'patiotime_site_footer_main_custom_block'							=> '0',

	/** section site footer before footer **/
	'patiotime_above_site_footer_content_source'						=> 'text',
	'patiotime_above_site_footer_text_content'							=> '',
	'patiotime_above_site_footer_custom_block'							=> '0',

	/** section site footer instagram **/
	'patiotime_site_footer_enable_instagram'							=> '',
	'patiotime_site_footer_instagram_title'								=> '',
	'patiotime_site_footer_instagram_title_link'						=> '',
	'patiotime_site_footer_instagram_columns'							=> 6,
	'patiotime_site_footer_instagram_new_tab'							=> '',

	/** section site footer bottom **/
	'patiotime_site_footer_bottom_layout'								=> '',
	// translators: %1$s: font icon with color %2$s: line break
	'patiotime_site_footer_bottom_text'									=> esc_html__( '© Copyright PatioTime WordPress Theme for Restaurant & Cafe.', 'patiotime' ),
	'patiotime_site_footer_bottom_background_color'						=> '#111111',
	'patiotime_site_footer_bottom_text_color'							=> '#FFFFFF',

	'patiotime_site_footer_hide_bottom'									=> '',

	/*** section general colors */
	'patiotime_general_color_scheme'									=> 'light-color',
	'patiotime_general_primary_color'									=> '#DD5903',
	'patiotime_general_secondary_color'									=> '#C59764',
	'patiotime_general_light_scheme_background_color'					=> '#FFFFFF',
	'patiotime_general_light_scheme_text_color'							=> '#000000',
	'patiotime_general_light_scheme_content_color'						=> '#111111',
	'patiotime_general_dark_scheme_background_color'					=> '#0E0D0A',
	'patiotime_general_dark_scheme_text_color'							=> '#FFFFFF',
	'patiotime_general_dark_scheme_content_color'						=> '#EEEEEE',

	/** section link colors **/
	'patiotime_link_light_scheme_regular_color'							=> 'primary',
	'patiotime_link_light_scheme_custom_regular_color'					=> '',
	'patiotime_link_light_scheme_hover_color'							=> 'primary',
	'patiotime_link_light_scheme_custom_hover_color'					=> '',
	'patiotime_link_dark_scheme_regular_color'							=> 'primary',
	'patiotime_link_dark_scheme_custom_regular_color'					=> '',
	'patiotime_link_dark_scheme_hover_color'							=> 'primary',
	'patiotime_link_dark_scheme_custom_hover_color'						=> '',

	/** section button colors **/
	'patiotime_button_shape'											=> '',
	'patiotime_button_background_color'									=> 'primary',
	'patiotime_button_custom_background_color'							=> '',
	'patiotime_button_text_color'										=> '#FFFFFF',
	'patiotime_button_hover_background_color'							=> 'primary',
	'patiotime_button_hover_custom_background_color'					=> '',
	'patiotime_button_hover_text_color'									=> '#FFFFFF',

	/** section form styles **/
	'patiotime_form_field_style'										=> 'pt-form-underline',
	'patiotime_form_border_width'										=> '1',

	/** section typogaghy heading */
	'patiotime_typography_heading_font-family' 							=> 'Cormorant Garamond',
	'patiotime_typography_heading_font-weight'							=> '600',
	'patiotime_typography_heading_letter-spacing'						=> 0,
	'patiotime_typography_heading_text-transform'						=> 'none',
	'patiotime_typography_heading_font-style'							=> 'normal',

	/** section typogaghy subheading **/
	'patiotime_typography_subheading_font-family'						=> 'Jost',
	'patiotime_typography_subheading_font-size'							=> 15,
	'patiotime_typography_subheading_font-weight'						=> '400',
	'patiotime_typography_subheading_letter-spacing'					=> '0.05em',
	'patiotime_typography_subheading_text-transform'					=> 'uppercase',
	'patiotime_typography_subheading_font-style'						=> 'normal',

	/** section typogaghy text **/
	'patiotime_typography_text_font-family'								=> 'Jost',
	'patiotime_typography_text_font-weight'								=> '400',
	'patiotime_typography_text_letter-spacing'							=> '0',
	'patiotime_typography_text_text-transform'							=> 'none',
	'patiotime_typography_text_font-style'								=> 'normal',

	/** section typogaghy blog **/
	'patiotime_typography_blog_title_font-weight'						=> '600',
	'patiotime_typography_blog_title_letter-spacing'					=> '0',
	'patiotime_typography_blog_title_text-transform'					=> 'none',
	'patiotime_typography_blog_title_font-style'						=> 'normal',
	'patiotime_typography_blog_content_font-size'						=> '18',
	'patiotime_typography_blog_content_line-height'						=> '1.66',

	/** section typogaghy secondary */
	'patiotime_typography_secondary_font-family' 						=> 'Jost',
	'patiotime_typography_secondary_letter-spacing'						=> '',
	'patiotime_typography_secondary_text-transform'						=> 'none',
	'patiotime_typography_secondary_font-style'							=> 'normal',

	/** section typogaghy widget title **/
	'patiotime_typography_widget_title_font-family'						=> 'Jost',
	'patiotime_typography_widget_title_font-size'						=> 14,
	'patiotime_typography_widget_title_font-weight'						=> '500',
	'patiotime_typography_widget_title_letter-spacing'					=> '0.05em',
	'patiotime_typography_widget_title_text-transform'					=> 'uppercase',
	'patiotime_typography_widget_title_font-style'						=> 'normal',

	/** section typogaghy menu **/
	'patiotime_typography_menu_font-family'								=> 'Jost',
	'patiotime_typography_menu_font-size'								=> 13,
	'patiotime_typography_menu_font-weight'								=> '500',
	'patiotime_typography_menu_letter-spacing'							=> '0.05em',
	'patiotime_typography_menu_text-transform'							=> 'uppercase',
	'patiotime_typography_footer_bottom_menu_font-size'					=> 14,
	'patiotime_typography_footer_bottom_menu_font-weight'				=> '400',
	'patiotime_typography_footer_bottom_menu_letter-spacing'			=> '0',
	'patiotime_typography_footer_bottom_menu_text-transform'			=> 'uppercase',

	/** section page title **/
	'patiotime_page_title_section_size'									=> 'page-title-default',
	'patiotime_page_title_enable_custom_margin_top'						=> '',
	'patiotime_page_title_custom_desktop_margin_top'					=> '',
	'patiotime_page_title_custom_tablet_margin_top'						=> '',
	'patiotime_page_title_custom_mobile_margin_top'						=> '',
	'patiotime_page_title_default_background_color'						=> '',
	'patiotime_page_title_default_background_image'						=> '',
	'patiotime_page_title_default_background_size'						=> 'cover',
	'patiotime_page_title_default_background_repeat'					=> '',
	'patiotime_page_title_default_background_position_x'				=> 'center',
	'patiotime_page_title_default_background_position_y'				=> 'center',
	'patiotime_page_title_default_background_attachment' 				=> 'on',
	'patiotime_page_title_default_text_color'							=> '',
	'patiotime_page_title_show_breadcrumb'								=> '',

	/** section blog genenral **/
	'patiotime_blog_general_read_more_button_text' 						=> esc_html__( 'Read More', 'patiotime' ),
	'patiotime_blog_general_pagination_style'							=> 'ajax-manual',
	'patiotime_blog_general_layout_standard_post_excerpt_length' 		=> '50',
	'patiotime_blog_general_layout_list_post_excerpt_length'	 		=> '25',
	'patiotime_blog_general_layout_grid_post_excerpt_length' 			=> '25',
	'patiotime_blog_general_layout_masonry_post_excerpt_length' 		=> '25',
	'patiotime_blog_general_load_post_metas_dynamically'				=> '',

	/** section blog page **/
	'patiotime_blog_page_layout'										=> '',
	'patiotime_blog_page_post_list_layout'								=> 'masonry-3cols',
	'patiotime_blog_page_overlay_image_ratio'							=> 'img-ratio-2-3',
	'patiotime_blog_page_image_ratio'									=> 'img-ratio-3-2',
	'patiotime_blog_page_show_post_excerpt'								=> 'on',
	'patiotime_blog_page_show_read_more_button'							=> 'on',
	'patiotime_blog_page_show_author'									=> '',
	'patiotime_blog_page_show_category'									=> 'on',
	'patiotime_blog_page_show_publish_date'								=> 'on',
	'patiotime_blog_page_show_comment_counter'							=> '',
	'patiotime_blog_page_posts_per_page'								=> get_option( 'posts_per_page', 10 ),

	/** section single post **/
	'patiotime_blog_single_post_title_section_size'						=> '',
	'patiotime_blog_single_post_title_default_background_color'			=> '',
	'patiotime_blog_single_post_title_default_text_color'				=> '',
	'patiotime_blog_single_post_show_yoast_seo_breadcrumb'				=> '',
	'patiotime_blog_single_post_layout'									=> 'with-sidebar-right',
	'patiotime_blog_single_post_page_header_show_author'				=> 'on',
	'patiotime_blog_single_post_page_header_show_category'				=> 'on',
	'patiotime_blog_single_post_page_header_show_publish_date'			=> 'on',
	'patiotime_blog_single_post_page_header_show_comment_counter'		=> '',
	'patiotime_blog_single_post_page_footer_show_tags'					=> 'on',
	'patiotime_blog_single_post_page_footer_show_social_sharings'		=> 'on',
	'patiotime_blog_single_post_page_footer_show_author_info_box'		=> 'on',
	'patiotime_blog_single_post_page_footer_show_navigation'			=> 'on',
	'patiotime_blog_single_post_enable_related_posts'					=> '',
	'patiotime_blog_single_post_related_post_section_title'				=> esc_html__( 'You May Also Like', 'patiotime' ),
	'patiotime_blog_single_post_related_post_filter'					=> 'category',

	// Woocommerce
	'patiotime_woocommerce_product_list_style'							=> '',
	'patiotime_woocommerce_product_list_food_menu_style'				=> 'food-menu-style-1',
	'patiotime_woocommerce_product_list_show_short_description' 		=> '',
	'patiotime_woocommerce_product_list_short_description_length' 		=> 15,

	'patiotime_woocommerce_breadcrumb'									=> 'on',
	'patiotime_woocommerce_yoast_seo_breadcrumb'						=> '',
	'patiotime_woocommerce_archive_layout'								=> 'with-sidebar-right',
	'patiotime_woocommerce_single_layout'								=> 'with-sidebar-right',
	'patiotime_woocommerce_price_filter_button_style'					=> '',
	'patiotime_woocommerce_category_filter_enable_ajax'					=> '',

	'patiotime_woocommerce_single_product_hide_page_title_section'		=> '',
	'patiotime_woocommerce_single_product_site_header' 					=> '',
	'patiotime_woocommerce_single_product_custom_site_header'			=> '0',
	'patiotime_woocommerce_show_add_to_cart_button_on_mobile'			=> ''
) );
