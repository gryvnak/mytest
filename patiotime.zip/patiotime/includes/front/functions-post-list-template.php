<?php
/**
* Get post format label for list page
*/
function patiotime_the_list_format_label() {
    $format = get_post_format();
    if ( ! empty( $format ) ) {
        switch( $format ) {
            case 'gallery': ?>
                <div class="overlay-label format-label format-gallery"><span></span></div><?php
                break;
            case 'video': ?>
                <div class="overlay-label format-label format-video"><span></span></div><?php
                break;
        }
    }
}
/**
* Show featured image as needed
* @param string how to show the featured image as background image or inline image
*/
function patiotime_the_list_featured_image( $type = 'image' ) {
    if ( has_post_thumbnail() ) {
    	$layout = patiotime_get_post_list_prop( 'layout', 'large' );
        if ( in_array( $layout, array( 'grid', 'masonry', 'overlay' )  ) ) {
            $cols = patiotime_get_post_list_prop( 'columns', '' );
            $layout .= '-' . $cols . 'cols';
        }
    	$size = PatioTime_Utils_Image::get_image_sizes( array( 'module' => 'archive', 'sub_module' => $layout ) );
    	if ( ! empty( $type ) && ( 'background' === $type ) ) : ?>
            <a href="<?php the_permalink(); ?>">
                <?php patiotime_the_preload_bg( array( 'id' => get_post_thumbnail_id(), 'class' => 'featured-img-container', 'sizes' => $size ) ); ?>
            </a><?php
    	else : ?>
            <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( $size[0] ); ?></a><?php
    	endif;
    }
}
/**
* Show the list post title
*/
function patiotime_the_list_post_title() { ?>
    <h2 class="post-title">
        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
    </h2><?php
}
/**
* Show list categories
* @param array metas enabled
*/
function patiotime_the_list_category( $metas ) {
	if ( in_array( 'category', $metas ) ) {
        patiotime_the_meta_category();
	}
}
/**
* Show list date
* @param array metas enabled
*/
function patiotime_the_list_date( $metas ) {
    if ( in_array( 'date', $metas ) ) : ?>
        <div class="meta-item time">
            <a href="<?php the_permalink(); ?>">
                <time class="published" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
            </a>
        </div> <?php
    endif;
}
/**
* Show list comment icon
* @param array metas enabled
*/
function patiotime_the_list_comment( $metas ) {
    if ( in_array( 'comment_counts', $metas ) ) :
    	if ( comments_open() || ( 0 < get_comments_number() ) ) : ?>
            <div class="meta-item comment-count">
                <a href="<?php the_permalink(); ?>#comments"><i class="far fa-comments"></i> <?php echo esc_html( get_comments_number() ); ?></a>
            </div><?php
    	endif;
    endif;
}
/**
* Show list like icon
* @param array metas enabled
*/
function patiotime_the_list_author( $metas ) {
    if ( in_array( 'author', $metas ) ) :
        $author_id = get_the_author_meta( 'ID' );
        $author_url = get_author_posts_url( $author_id ); ?>
        <div class="meta-item author">
            <?php esc_html_e( 'By', 'patiotime' ); ?> <a href="<?php echo esc_url( $author_url ); ?>"><?php the_author(); ?></a>
        </div><?php
    endif;
}
/**
* Show list excerpt text
* @param array metas enabled
*/
function patiotime_the_list_excerpt( $metas ) {
	if ( in_array( 'excerpt', $metas ) ) : ?>
		<div class="post-excerpt"><?php the_excerpt(); ?></div><?php
	endif;
}
/**
* Show list read more button
* @param array metas enabled
*/
function patiotime_the_list_more_btn( $metas ) {
	if ( in_array( 'read_more_btn', $metas ) ) : ?>
        <div class="more-btn">
            <a class="read-more-btn button pt-btn-underline" href="<?php the_permalink(); ?>"><span><?php echo esc_html( patiotime_get_theme_mod( 'patiotime_blog_general_read_more_button_text' ) ); ?></span></a>
        </div><?php
	endif;
}
