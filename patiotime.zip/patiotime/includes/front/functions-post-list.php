<?php
/**
* Setup post list args
* @param array
*/
function patiotime_setup_post_list_args( $args ) {
	$GLOBALS['patiotime']['post_list'] = $args;
	do_action( 'loftocean_pre_post_list' );
}
add_action( 'patiotime_start_post_list_loop', 'patiotime_setup_post_list_args' );
/**
* Reset post list args
*/
function patiotime_reset_post_list_args() {
	unset( $GLOBALS['patiotime']['post_list'] );
	do_action( 'loftocean_reset_post_list' );
}
add_action( 'patiotime_end_post_list_loop', 'patiotime_reset_post_list_args' );
/**
* Get setting from post list args
* @param string
* @param string
* @return mix
*/
function patiotime_get_post_list_prop( $prop, $default = '' ) {
	if ( isset( $GLOBALS['patiotime'], $GLOBALS['patiotime']['post_list'], $GLOBALS['patiotime']['post_list'][ $prop ] ) ) {
		return $GLOBALS['patiotime']['post_list'][ $prop ];
	} else {
		return $default;
	}
}
/**
* Sets a property in the post list global.
* @param string
* @param string
*/
function patiotime_set_post_list_prop( $prop, $value = '' ) {
	if ( isset( $GLOBALS['patiotime'], $GLOBALS['patiotime']['post_list'] ) ) {
		$GLOBALS['patiotime']['post_list'][ $prop ] = $value;
	}
}
/**
* Display content after post list
*/
function patiotime_after_post_list_content() {
	$layout = patiotime_get_post_list_prop( 'layout', false );
	$nav_style = patiotime_get_theme_mod( 'patiotime_list_pagination_style' );
	if ( ( 'masonry' == $layout ) && in_array( $nav_style, array( 'ajax-manual', 'ajax-auto' ) ) ) :
		global $wp_query;
		$cols = patiotime_get_post_list_prop( 'columns', false );
		$total = $wp_query->post_count;
		$more_cols = $total < $cols ? ( $cols - $total ) : false;
		if ( $more_cols ) :
			for( $i = 0; $i < $more_cols; $i ++ ) : ?>
				<div class="masonry-column"></div><?php
			endfor;
		endif;
	endif;
}
add_action( 'patiotime_after_post_list_content', 'patiotime_after_post_list_content' );
/**
* Get post list layout and column
*/
function patiotime_get_post_list_layout_settings() {
	$sets = array( 'layout' => 'standard', 'column' => false );
	$layout = patiotime_get_theme_mod( 'patiotime_blog_page_post_list_layout' );
	$actual_sets = explode( '-', $layout );
	if ( patiotime_is_valid_array( $actual_sets ) ) {
		$sets[ 'layout' ] = $actual_sets[0];
		$sets[ 'column' ] = empty( $actual_sets[ 1 ] ) ? false : str_replace( 'cols', '', $actual_sets[ 1 ] );
	}
	return $sets;
}
/**
* Change default excerpt length
*/
function patiotime_excerpt_length( $length ) {
	$layout = patiotime_get_post_list_prop( 'layout' );
	$layouts = array( 'standard', 'list', 'grid', 'masonry', 'overlay' );
	if ( ! empty( $layout ) && in_array( $layout, $layouts ) ) {
		return absint( patiotime_get_theme_mod( 'patiotime_blog_general_layout_' . $layout . '_post_excerpt_length' ) );
	}
	return $length;
}
add_filter( 'excerpt_length', 'patiotime_excerpt_length', PHP_INT_MAX );
/**
* Chang excerpt text
*/
function patiotime_excerpt_more( $more ) {
	return ' ...';
}
add_filter( 'excerpt_more', 'patiotime_excerpt_more', PHP_INT_MAX );
/**
* Get archive page enabled post metas
* @param string archive page type
* @return array
*/
function patiotime_get_list_post_meta() {
	$metas = array();
	$all = array(
		'excerpt' => 'post_excerpt',
		'read_more_btn' => 'read_more_button',
		'category' => 'category',
		'author' => 'author',
		'date' => 'publish_date',
		'comment_counts' => 'comment_counter'
	);
	foreach( $all as $meta => $id ) {
		if ( patiotime_module_enabled( 'patiotime_blog_page_show_' . $id ) ) {
			array_push( $metas, $meta );
		}
	}
	return $metas;
}
/**
* Get post list wrap class
* @param string
* @param array
* @return array
*/
function patiotime_list_get_wrap_class( $sets = array( 'layout' => 'standard', 'column' => '' ) ) {
	$class = array( 'posts' );
	if ( ! empty( $sets[ 'layout' ] ) ) {
		array_push( $class, 'layout-' . $sets[ 'layout' ] );
		empty( $sets[ 'column' ] ) ? '' : array_push( $class, 'column-' . $sets[ 'column' ] );
		if ( 'overlay' == $sets[ 'layout' ] ) {
			array_push( $class, 'layout-grid' );
			array_push( $class, patiotime_get_theme_mod( 'patiotime_blog_page_overlay_image_ratio' ) );
		} else if ( in_array( $sets[ 'layout' ], array( 'grid', 'list' ) ) ) {
			array_push( $class, patiotime_get_theme_mod( 'patiotime_blog_page_image_ratio' ) );
		}

		$class = apply_filters( 'patiotime_post_list_wrap_class', $class, array( 'layout' => $sets[ 'layout' ], 'columns' => $sets[ 'column' ] ) );
		return array_unique( array_filter( $class ) );
	}
	return $class;
}
/**
* Get default post list posts class
*/
function patiotime_list_get_default_wrap_class() {
	return array( 'posts', 'layout-standard' );
}
/**
* Get masonry settings
* @param string layout
* @param int column
* @param int offset
* @return mix
*/
function patiotime_get_masonry_settings( $layout, $column, $query = false ) {
	if ( 'masonry' === $layout ) {
		if ( empty( $query ) ) {
			global $wp_query;
			$query = $wp_query;
		}
		$total = $query->post_count;
		$post_index = $query->current_post + 1;
		$is_start = ( 1 === $post_index );
		$is_end = ( $post_index === $total );
		$column_ends = patiotime_get_masonry_column_ends( $query, $column );
		if ( ! $is_start ) {
			foreach( $column_ends as $ce ) {
				if ( 1 == ( $post_index - $ce ) ) {
					$is_start = true;
					break;
				}
			}
		}
		if ( ! $is_end ) {
			foreach( $column_ends as $ce ) {
				if ( $post_index == $ce ) {
					$is_end = true;
					break;
				}
			}
		}
		return apply_filters( 'patiotime_masonry_column_settings', array(
			'is_start' => $is_start,
			'is_end' => $is_end
		), $query );
	}
	return false;
}
/**
* Help function to generate masonry layout necessary column settings
* @param object
* @param int
* @return array
*/
function patiotime_get_masonry_column_ends( $query, $column ) {
	$column_ends = patiotime_get_post_list_prop( 'masonry_column_ends', false );
	if ( empty( $column_ends ) ) {
		$total = $query->post_count;
		$column = empty( $column ) ? 2 : $column;
		$column_ends = array( $total );
		for( $i = $column; $i > 1; $i-- ) {
			$current = floor( $total / $i );
			if ( ! empty( $current ) ) {
				$total -= $current;
				array_unshift( $column_ends, $total );
			}
		}
		patiotime_set_post_list_prop( 'masonry_column_ends', $column_ends );
	}
	return $column_ends;
}
/**
* Pagination type link with page number
*/
function patiotime_list_pagination_link_number() {
	$prev_label = esc_html__( 'Prev', 'patiotime' );
	$next_label = esc_html__( 'Next', 'patiotime' );
	$prev_link 	= get_previous_posts_link( $prev_label );
	$next_link 	= get_next_posts_link( $next_label );

	if ( ! empty( $prev_link) || ! empty( $next_link ) ) : ?>
		<nav class="navigation pagination">
			<div class="pagination-container with-page-numbers">
				<h2 class="screen-reader-text"><?php esc_html_e( 'Posts navigation', 'patiotime' ); ?></h2>
				<?php if ( empty( $prev_link ) ) : ?>
					<span class="prev page-numbers"><?php esc_html_e( 'Prev', 'patiotime' ); ?> </span>
				<?php else: ?>
					<?php previous_posts_link( $prev_label ); ?>
				<?php endif; ?>
				<?php echo paginate_links( array( 'prev_next' => false, 'type' => 'plain' ) ); // phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped ?>
				<?php if ( empty( $next_link ) ) : ?>
					<span class="next page-numbers"> <?php esc_html_e( 'Next', 'patiotime' ); ?></span>
				<?php else: ?>
					<?php next_posts_link( $next_label ); ?>
				<?php endif; ?>
			</div>
		</nav> <?php
	endif;
}
/**
* Pagination type prev/next links only
*/
function patiotime_list_pagination_link_only() {
	$prev_label = esc_html__( 'Prev', 'patiotime' );
	$next_label = esc_html__( 'Next', 'patiotime' );
	$prev_link 	= get_previous_posts_link( $prev_label );
	$next_link 	= get_next_posts_link( $next_label );

	if ( ! empty( $prev_link) || ! empty( $next_link ) ) : ?>
		<nav class="navigation pagination">
			<div class="pagination-container prev-next">
				<h2 class="screen-reader-text"><?php esc_html_e( 'Posts navigation', 'patiotime' ); ?></h2>
				<?php if ( empty( $prev_link ) ) : ?>
					<span class="prev page-numbers"><?php esc_html_e( 'Prev', 'patiotime' ); ?> </span>
				<?php else: ?>
					<?php previous_posts_link( $prev_label ); ?>
				<?php endif; ?>
				<?php if ( empty( $next_link ) ) : ?>
					<span class="next page-numbers"> <?php esc_html_e( 'Next', 'patiotime' ); ?></span>
				<?php else: ?>
					<?php next_posts_link( $next_label ); ?>
				<?php endif; ?>
			</div>
		</nav> <?php
	endif;
}
/**
* Pagination style ajax loading manually
*/
function patiotime_list_pagination_ajax_manual() {
	if ( patiotime_test_ajax_nav() ) : ?>
		<nav class="navigation pagination">
			<div class="pagination-container load-more">
				<h2 class="screen-reader-text"><?php esc_html_e( 'Posts Navigation', 'patiotime' ); ?></h2>
				<a href="#" data-no-post-text="<?php esc_attr_e( 'No More Posts', 'patiotime' ); ?>" class="load-more-btn ajax manual">
					<span class="btn-text"><?php esc_html_e( 'Load More Posts', 'patiotime' ); ?></span>
					<span class="loading-text"><?php esc_html_e( 'Loading...', 'patiotime' ); ?></span>
				</a>
			</div>
		</nav><?php
	endif;
}
/**
* Pagination style ajax loading automatically
*/
function patiotime_list_pagination_ajax_auto() {
	if ( patiotime_test_ajax_nav() ) : ?>
		<nav class="navigation pagination">
			<div class="pagination-container load-more infinite">
				<h2 class="screen-reader-text"><?php esc_html_e( 'Posts Navigation', 'patiotime' ); ?></h2>
				<a href="#" data-no-post-text="<?php esc_attr_e( 'No More Posts', 'patiotime' ); ?>" class="load-more-btn ajax">
					<span class="loading-text"><?php esc_html_e( 'Loading...', 'patiotime' ); ?></span>
				</a>
			</div>
		</nav> <?php
	endif;
}
/**
* Show post List page pagination
*/
function patiotime_list_pagination() {
	$type = patiotime_get_theme_mod( 'patiotime_blog_general_pagination_style' );
	if ( ! empty( $type ) && in_array( $type, array( 'link-only', 'link-number', 'ajax-manual', 'ajax-auto' ) ) ) {
		call_user_func( 'patiotime_list_pagination_' . str_replace( '-', '_', $type ) );
	}
}
/**
* Test if show ajax pagination
*/
function patiotime_test_ajax_nav() {
	global $wp_query, $paged;
	$current_page = max( $paged, 1 );
	return $current_page < $wp_query->max_num_pages;
}
/**
* Add class attribute for previous posts link
* @param string
* @return string
*/
function patiotime_prev_posts_link_attrs( $attrs ) {
	return $attrs . ' class="prev page-numbers"';
}
add_filter( 'previous_posts_link_attributes', 'patiotime_prev_posts_link_attrs' );
/**
* Add class attribute for next posts link
* @param string
* @return string
*/
function patiotime_next_posts_link_attrs( $attrs ) {
	return $attrs . ' class="next page-numbers"';
}
add_filter( 'next_posts_link_attributes', 'patiotime_next_posts_link_attrs' );
