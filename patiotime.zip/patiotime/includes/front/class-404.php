<?php
if ( ! class_exists( 'PatioTime_Custom_404' ) ) {
	class PatioTime_Custom_404 {
        /**
        * Integer custom 404 page id
        */
        protected $custom_404_page_id = false;
		/**
		* Construct function
		*/
		public function __construct() {
            add_action( 'template_redirect', array( $this, 'init_hooks' ), 99 );
        }
        /**
        * Init custom 404 hooks
        */
        public function init_hooks() {
            $custom_block = patiotime_get_theme_mod( 'patiotime_general_404_page_custom_block' );
            if ( is_404() && patiotime_does_item_exist( $custom_block ) ) {
                $this->custom_404_page_id = $custom_block;

                add_filter( 'patiotime_is_custom_404', '__return_true' );
                add_filter( 'body_class', array( $this, 'body_class' ) );
                add_filter( 'patiotime_get_custom_404_page_id', array( $this, 'get_custom_404_page_id' ) );
                add_filter( 'patiotime_content_class', array( $this, 'content_class' ), 999999 );
                add_filter( 'patiotime_get_current_page_layout', array( $this, 'get_page_layout'), 999999 );
            }
		}
		/**
		* Get page sidebar settings
		*/
		public function get_page_layout( $layout ) {
			$template = get_page_template_slug( $this->custom_404_page_id );
			switch ( $template ) {
				case 'template-fullwidth.php':
				case 'template-wide-content.php':
					return '';
				case 'template-left-sidebar.php':
					return 'with-sidebar-left';
				default:
					return 'with-sidebar-right';
			}
			return $layout;
		}
		/**
		* Get main content layout class
		*/
		public function content_class( $class ) {
			$layout = $this->get_page_layout( '' );
			$sidebar_id = apply_filters( 'patiotime_sidebar_id', 'main-sidebar' );
			if ( ! empty( $layout ) && is_active_sidebar( $sidebar_id ) ) {
				array_push( $class, $layout );
			}
			return $class;
		}
		/**
		* Extra body class for single page
		*/
		public function body_class( $class ) {
			array_unshift( $class, 'custom-error-404' );
            array_unshift( $class, 'error404' );
			return $class;
		}
        /**
        * Get custom 404 page id
        */
        public function get_custom_404_page_id( $id ) {
            return $this->custom_404_page_id;
        }
	}
	new PatioTime_Custom_404();
}
