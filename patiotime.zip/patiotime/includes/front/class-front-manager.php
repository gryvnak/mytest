<?php
/**
* Main class for frontend
*/

if ( ! class_exists( 'PatioTime_Front_Manager' ) ) {
	class PatioTime_Front_Manager {
		/**
		* Object current class instance to make sure only once instance in running
		*/
		public static $instance = false;
		/**
		* Array restaurant info
		*/
		protected $restaurant_info = false;
		/**
		* Construct function
		*/
		public function __construct() {
			add_action( 'wp_loaded', array( $this, 'load_front_render' ), 999 );
			add_action( 'template_redirect', array( $this, 'load_front_hooks' ), 999 );
			add_filter( 'patiotime_get_current_page_layout', array( $this, 'get_page_layout'), 9999 );
			add_filter( 'patiotime_content_class', array( $this, 'content_class' ), 9999 );
			add_filter( 'get_the_author_description', 'wpautop', 9999 );
			add_filter( 'patiotime_get_restaurant_info', array( $this, 'get_restaurant_info' ) );

			add_action( 'wp_footer', array( $this, 'theme_footer' ) );
		}
		/**
		* Load single settings
		*/
		public function load_front_render() {
			$dir = PATIOTIME_THEME_INC . 'front/';
			require_once $dir . 'class-front-single.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $dir . 'class-front-block-render.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $dir . 'class-front-archive.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $dir . 'class-front-metas-cache.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $dir . 'class-404.php';  // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $dir . 'class-events.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
		}
		/**
		* WP hook function
		*/
		public function load_front_hooks() {
			$this->includes();
			add_filter( 'body_class', array( $this, 'body_class' ), 999 );
			add_filter( 'post_class', array( $this, 'post_class' ), 9999 );
			add_filter( 'patiotime_show_site_footer_bottom', array( $this, 'show_footer_bottom' ), 999999 );

			do_action( 'patiotime_image_loading_attributes' );
		}
		/**
		* Import required files
		*/
		private function includes() {
			$inc_dir = PATIOTIME_THEME_INC;
			$front_dir = PATIOTIME_THEME_INC . 'front/';

			require_once $inc_dir . 'utils/class-utils-sanitize.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $front_dir . 'functions-template.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $front_dir . 'class-walker-comment.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $front_dir . 'class-walker-menu.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
		}
		/**
		* Add extra class name to <body>
		* @param array class name list
		* @return array class name list
		*/
		public function body_class( $class ) {
			$button_shape = patiotime_get_theme_mod( 'patiotime_button_shape' );
			empty( $button_shape ) ? '' : array_push( $class, $button_shape );
			array_push( $class, esc_attr( patiotime_get_theme_mod( 'patiotime_general_color_scheme' ) ) );
			array_push( $class, ( 'custom' == patiotime_get_theme_mod( 'patiotime_page_content_width' ) ? 'custom-site-width' : 'site-layout-fullwidth' ) );
			array_push( $class, esc_attr( patiotime_get_theme_mod( 'patiotime_form_field_style' ) ) );
			in_array( 'theme-patiotime', $class ) ? '' : array_push( $class, 'theme-patiotime' );

			if ( apply_filters( 'patiotime_enable_onepage_menu_check', patiotime_module_enabled( 'patiotime_enable_onepage_menu_check' ) ) ) {
				array_push( $class, 'patiotime-enable-onepage-menu-check' );
			}
			return $class;
		}
		/**
		* Adjust post class if needed
		* @param array
		* @return array
		*/
		public function post_class( $class ) {
			if ( wp_doing_ajax() ) {
				array_push( $class, 'list-post' );
			}
			if ( post_password_required() && has_post_thumbnail() ) {
				array_push( $class, 'has-post-thumbnail' );
			}
			return $class;
		}
		/**
		* Check page layout for 404 page
		*/
		public function get_page_layout( $layout ) {
			return is_404() ? '' : $layout;
		}
		/**
		* Check content class for 404 page
		*/
		public function content_class( $class ) {
			return is_404() ? array_diff( $class, array( 'with-sidebar-right', 'with-sidebar-left' ) ) : $class;
		}
		/**
		* If show footer bottom
		*/
		public function show_footer_bottom( $show ) {
			if ( patiotime_module_enabled( 'patiotime_site_footer_hide_bottom' ) ) {
				return false;
			}
			return $show;
		}
		/**
		* Helper function to parse terms
		*/
		protected function get_terms( $sets, $type ) {
			$sets = explode( ',', $sets );
			$sets = array_filter( $sets );
			if ( patiotime_is_valid_array( $sets ) ) {
				$results = array();
				foreach ( $sets as $slug ) {
					$term = get_term_by( 'slug', $slug, $type );
					if ( false !== $term ) {
						array_push( $results, $term );
					}
				}
				return $results;
			}
			return false;
		}
		/**
		* Get current restaurant info
		*/
		public function get_restaurant_info( $info ) {
			if ( false === $this->restaurant_info ) {
				$address = get_option( 'patiotime_restaurant_address' );
				$mapURL = get_option( 'patiotime_restaurant_map_url' );
				$phone = get_option( 'patiotime_restaurant_phone' );
				$email = get_option( 'patiotime_restaurant_email' );
				$has_address = ! empty( $address );
				$has_phone = ! empty( $phone );
				$has_email = ! empty( $email );
				$this->restaurant_info = array(
					'has_info' => $has_address || $has_email || $has_phone,
					'address' => array( 'has' => $has_address, 'info' => $address ),
					'mapURL' => array( 'has' => ! empty( $mapURL), 'info' => $mapURL ),
					'phone' => array( 'has' => $has_phone, 'info' => $phone ),
					'email'	=> array( 'has' => $has_email, 'info' => $email )
				);
			}
			return $this->restaurant_info;
		}
		/**
		* Theme footer content for wp_footer
		*/
		public function theme_footer() {
			do_action( 'patiotime_the_mobile_menu' );
			get_template_part( 'template-parts/site-footer/back-to-top' );
			get_template_part( 'template-parts/site-footer/cookie-law' );
			get_template_part( 'template-parts/site-footer/popup-box' );
			get_template_part( 'template-parts/site-footer/fullscreen-search' );
		}
		/**
		* Instance Loader class
		*	there can only be one instance of loader
		* @return class Loader
		*/
		public static function init() {
			if ( false === self::$instance ) {
				self::$instance = new self();
			}
		}
	}
}
