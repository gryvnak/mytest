<?php
return apply_filters( 'patiotime_demo_configs', array(
    'main' => array(
        'title' => esc_html__( 'Main', 'patiotime' ),
        'screenshot' => 'https://patiotime.loftocean.com/wp-content/uploads/2022/03/home-01.jpg',
        'preview' => PATIOTIME_PREVIEW_BASE,
        'tag' => array(),
        'plugins' => array(),
        'content' => array()
    ),
    'bistro-pizza' => array(
        'title' => esc_html__( 'Bistro and Pizza Home', 'patiotime' ),
        'screenshot' => 'https://patiotime.loftocean.com/wp-content/uploads/2022/03/home-06.jpg',
        'preview' => PATIOTIME_PREVIEW_BASE . 'home-2/',
        'tag' => array(),
        'plugins' => array(),
        'content' => array()
    ),
    'casual-cafe' => array(
        'title' => esc_html__( 'Casual Cafe Home', 'patiotime' ),
        'screenshot' => 'https://patiotime.loftocean.com/wp-content/uploads/2022/03/home-07.jpg',
        'preview' => PATIOTIME_PREVIEW_BASE . 'home-3/',
        'tag' => array(),
        'plugins' => array(),
        'content' => array()
    ),
    'bar' => array(
        'title' => esc_html__( 'Bar Home', 'patiotime' ),
        'screenshot' => 'https://patiotime.loftocean.com/wp-content/uploads/2022/03/home-03.jpg',
        'preview' => PATIOTIME_PREVIEW_BASE . 'home-4/',
        'tag' => array(),
        'plugins' => array(),
        'content' => array()
    ),
    'elegant-rRestaurant' => array(
        'title' => esc_html__( 'Elegant Restaurant', 'patiotime' ),
        'screenshot' => 'https://patiotime.loftocean.com/wp-content/uploads/2022/03/home-02.jpg',
        'preview' => PATIOTIME_PREVIEW_BASE . 'home-5',
        'tag' => array(),
        'plugins' => array(),
        'content' => array()
    ),
    'seafood' => array(
        'title' => esc_html__( 'Seafood Home', 'patiotime' ),
        'screenshot' => 'https://patiotime.loftocean.com/wp-content/uploads/2022/03/home-04.jpg',
        'preview' => PATIOTIME_PREVIEW_BASE . 'home-6',
        'tag' => array(),
        'plugins' => array(),
        'content' => array()
    ),
    'local-restaurant' => array(
        'title' => esc_html__( 'Local Restaurant Home', 'patiotime' ),
        'screenshot' => 'https://patiotime.loftocean.com/wp-content/uploads/2022/03/home-05.jpg',
        'preview' => PATIOTIME_PREVIEW_BASE . 'home-7',
        'tag' => array(),
        'plugins' => array(),
        'content' => array()
    ),
    'coffee-food' => array(
        'title' => esc_html__( 'Coffee & Food Home', 'patiotime' ),
        'screenshot' => 'https://patiotime.loftocean.com/wp-content/uploads/2022/03/home-08.jpg',
        'preview' => PATIOTIME_PREVIEW_BASE . 'home-8',
        'tag' => array(),
        'plugins' => array(),
        'content' => array()
    )
) );
