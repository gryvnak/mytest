<?php
if ( ! class_exists( 'PatioTime_Importer_Manager' ) ) {
    class PatioTime_Importer_Manager {
        /**
        * Construct function
        */
        public function __construct() {
            add_filter( 'patiotime_get_demo_configs', array( $this, 'get_configs' ) );
            add_action( 'patiotime_theme_options', array( $this, 'load_files' ) );
        }
        /**
        * Demo configs
        */
        public function get_configs( $config = array() ) {
            return require_once PATIOTIME_THEME_INC . 'importer/configs.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
        }
        /**
        * Load required files
        */
        public function load_files() {
            require_once PATIOTIME_THEME_INC . 'importer/class-templates.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
        }
    }
//    new PatioTime_Importer_Manager();
}
