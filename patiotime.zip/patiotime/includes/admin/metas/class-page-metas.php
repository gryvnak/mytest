<?php
if ( ! class_exists( 'PatioTime_Page_Metas' ) ) {
	class PatioTime_Page_Metas {
		/**
		* Construct function
		*/
		public function __construct() {
			add_action( 'loftocean_save_page_metabox_settings', array( $this, 'save_page_meta' ), 10, 1 );
			add_filter( 'loftocean_metabox_get_page_title', array( $this, 'change_page_metabox_title' ), 10, 2 );
			add_filter( 'loftocean_the_page_metabox_html', array( $this, 'page_metabox' ) );

			if ( patiotime_is_gutenberg_enabled() ) {
				add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_editor_assets' ), 5 );
			}
		}
		/**
		* Enqueue gutenberg editor assets
		*/
		public function enqueue_editor_assets() {
			if ( ! apply_filters( 'loftocean_hide_page_settings', false ) ) {
				wp_enqueue_script(
					'patiotime-gutenberg-page-script',
					PATIOTIME_ASSETS_URI . 'scripts/editor/page-settings.js',
					array( 'wp-element', 'wp-i18n', 'wp-hooks', 'wp-components', 'wp-blocks', 'jquery' ),
					PATIOTIME_ASSETS_VERSION,
					true
				);
				wp_localize_script( 'patiotime-gutenberg-page-script', 'patiotimeBlockEditorSettings', array(
					'customBlock' => patiotime_get_custom_post_type( 'custom_blocks' ),
					'yoastSEO_enabled' => patiotime_is_yoast_seo_activated() && $this->enable_breadcrumbs(),
					'customSiteHeader' => patiotime_get_custom_post_type( 'custom_site_headers' ),
					'disableStickySiteHeader' => ( 'disable' == patiotime_get_theme_mod( 'patiotime_sticky_site_header' ) )
				) );
			}
		}
		/**
		* Change page metabox title
		* @param string
		* @param string
		* @return string
		*/
		public function change_page_metabox_title( $title, $type ) {
			if ( 'page' == $type ) {
				return esc_html__( 'PatioTime Single Page Options', 'patiotime' );
			} else {
				return $title;
			}
		}
		/**
		* Output page meta box html
		* @param object
		*/
		public function page_metabox( $post ) {
			if ( apply_filters( 'loftocean_hide_page_settings', false, $post ) ) {
				return '';
			}

			$post_id = $post->ID;
			$hide_site_header = get_post_meta( $post_id, 'patiotime_single_page_hide_site_header', true );
			$site_header_source = get_post_meta( $post_id, 'patiotime_single_page_site_header_source', true );
			$custom_site_header = get_post_meta( $post_id, 'patiotime_single_page_custom_site_header', true );
			$custom_sticky_site_header = get_post_meta( $post_id, 'patiotime_single_page_custom_sticky_site_header', true );
			$hide_page_title = get_post_meta( $post_id, 'patiotime_single_page_hide_page_title', true );
			$page_title_size = get_post_meta( $post_id, 'patiotime_single_page_header_section_size', true );
			$background_color = get_post_meta( $post_id, 'patiotime_single_page_header_background_color', true );
			$background_image = get_post_thumbnail_id();
			$has_background_image = ! empty( $background_image ) && patiotime_does_attachment_exist( $background_image );
			$background_positionx = get_post_meta( $post_id, 'patiotime_single_page_header_background_position_x', true );
			$background_positionx = empty( $background_positionx ) ? 'center' : $background_positionx;
			$background_positiony = get_post_meta( $post_id, 'patiotime_single_page_header_background_position_y', true );
			$background_positiony = empty( $background_positiony ) ? 'center' : $background_positiony;
			$background_size = get_post_meta( $post_id, 'patiotime_single_page_header_background_size', true );
			$background_size = empty( $background_size ) ? 'cover' : $background_size;
			$background_repeat = get_post_meta( $post_id, 'patiotime_single_page_header_background_repeat', true );
			$background_repeat = empty( $background_repeat ) ? 'off' : $background_repeat;
			$background_attachment = get_post_meta( $post_id, 'patiotime_single_page_header_background_scroll', true );
			$background_attachment = empty( $background_attachment ) ? 'off' : $background_attachment;
			$text_color = get_post_meta( $post_id, 'patiotime_single_page_header_text_color', true );
			$show_yoast_seo_breadcrumb = get_post_meta( $post_id, 'patiotime_single_page_header_show_breadcrumb', true );
			$hide_footer_main = get_post_meta( $post_id, 'patiotime_single_page_site_footer_hide_main', true );
			$custom_footer_main_source = get_post_meta( $post_id, 'patiotime_single_custom_site_footer_main_source', true );
			$custom_footer_main = get_post_meta( $post_id, 'patiotime_single_custom_site_footer_main', true );
			$hide_footer_above = get_post_meta( $post_id, 'patiotime_single_page_site_footer_hide_above', true );
			$custom_footer_above_source = get_post_meta( $post_id, 'patiotime_single_custom_site_footer_above_source', true );
			$custom_footer_above = get_post_meta( $post_id, 'patiotime_single_custom_site_footer_above', true );
			$hide_footer_instagram = get_post_meta( $post_id, 'patiotime_single_page_site_footer_hide_instagram', true );
			$hide_footer_bottom = get_post_meta( $post_id, 'patiotime_single_page_site_footer_hide_bottom', true );

			$custom_headers = patiotime_get_custom_post_type( 'custom_site_headers' );
			$custom_blocks = patiotime_get_custom_post_type( 'custom_blocks' );

			$custom_page_title_margin_top_source = get_post_meta( $post_id, 'patiotime_single_page_custom_page_title_margin_top_source', true );
			$custom_page_title_desktop_margin_top = get_post_meta( $post_id, 'patiotime_single_page_custom_page_title_desktop_margin_top', true );
			$custom_page_title_tablet_margin_top = get_post_meta( $post_id, 'patiotime_single_page_custom_page_title_tablet_margin_top', true );
			$custom_page_title_mobile_margin_top = get_post_meta( $post_id, 'patiotime_single_page_custom_page_title_mobile_margin_top', true );

			$mobile_menu_source = get_post_meta( $post_id, 'patiotime_single_custom_mobile_menu_source', true );
			$custom_mobile_menu = get_post_meta( $post_id, 'patiotime_single_custom_mobile_menu', true );
			$custom_mobile_menu_animation = get_post_meta( $post_id, 'patiotime_single_custom_mobile_menu_animation', true );
			$custom_mobile_menu_width = get_post_meta( $post_id, 'patiotime_single_custom_mobile_menu_width', true );
			$custom_mobile_menu_custom_width = get_post_meta( $post_id, 'patiotime_single_custom_mobile_menu_custom_width', true );

			$hide_mobile_menu_source = ! patiotime_is_valid_array( $custom_blocks );
			$hide_custom_mobile_menu = $hide_mobile_menu_source || ( 'custom' != $mobile_menu_source );
			$hide_custom_mobile_menu_custom_width = $hide_custom_mobile_menu || ( 'custom-width' != $custom_mobile_menu_width );

			$hide_source = ( 'on' == $hide_site_header );
			$hide_custom_headers = $hide_source || ( 'custom' != $site_header_source );

			$hide_custom_page_title_margin_top = ( 'custom' != $custom_page_title_margin_top_source );

			$hide_footer_main_source = ( 'on' == $hide_footer_main );
			$hide_custom_footer_main = $hide_footer_main_source || ( 'custom' != $custom_footer_main_source );

			$hide_footer_above_source = ( 'on' == $hide_footer_above );
			$hide_custom_footer_above = $hide_footer_above_source || ( 'custom' != $custom_footer_above_source ); ?>

			<h4 class="section-title"><?php esc_html_e( 'Site Header', 'patiotime' ); ?></h4>
			<p>
				<label for="patiotime_single_page_hide_site_header"><?php esc_html_e( 'Hide Site Header:', 'patiotime' ); ?></label>
				<input type="checkbox" name="patiotime_single_page_hide_site_header" id="patiotime_single_page_hide_site_header" value="on" <?php checked( $hide_site_header, 'on' ); ?>>
			</p>
			<p class="patiotime-single-header-source-wrapper"<?php if ( $hide_source ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_page_site_header_source"><?php esc_html_e( 'Site Header Source:', 'patiotime' ); ?></label>
				<select name="patiotime_single_page_site_header_source">
					<option value="" <?php selected( $site_header_source, '' ); ?>><?php esc_html_e( 'Inherit', 'patiotime' ); ?></option>
					<option value="custom" <?php selected( $site_header_source, 'custom' ); ?>><?php esc_html_e( 'Custom', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="patiotime-single-custom-site-headers-wrapper"<?php if ( $hide_custom_headers ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_page_custom_site_header"><?php esc_html_e( 'Select a Custom Site Header:', 'patiotime' ); ?></label>
				<select name="patiotime_single_page_custom_site_header">
					<?php foreach ( $custom_headers as $id => $label ) : ?>
						<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $custom_site_header, $id ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select><br>
				<span class="description"><?php
					printf(
						// translators: 1/2. html tag
						esc_html__( 'If there is no option in the dropdown list, please click %1$shere%2$s to create your own site header first.', 'patiotime' ),
						'<a href="' . esc_url( admin_url( 'edit.php?post_type=custom_site_headers' ) ) . '" target="_blank">',
						'</a>'
					); ?>
				</span>
			</p><?php
			if ( 'disable' != patiotime_get_theme_mod( 'patiotime_sticky_site_header' ) ) : ?>
			<p class="patiotime-single-custom-site-headers-wrapper"<?php if ( $hide_custom_headers ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_page_custom_sticky_site_header"><?php esc_html_e( 'Select a Custom Sticky Site Header:', 'patiotime' ); ?></label>
				<select name="patiotime_single_page_custom_sticky_site_header">
					<?php foreach ( $custom_headers as $id => $label ) : ?>
						<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $custom_sticky_site_header, $id ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select><br>
				<span class="description"><?php esc_html_e( 'You can choose another custom site header as the sticky header.', 'patiotime' ); ?></span>
			</p><?php
			endif; ?>

			<h4 class="section-title"><?php esc_html_e( 'Page Title Section', 'patiotime' ); ?></h4>
			<p>
				<label for="patiotime_single_page_hide_page_title"><?php esc_html_e( 'Hide Page Title Section:', 'patiotime' ); ?></label>
				<input type="checkbox" name="patiotime_single_page_hide_page_title" id="patiotime_single_page_hide_page_title" value="on" <?php checked( $hide_page_title, 'on' ); ?>>
			</p>
			<p>
				<label for="patiotime_single_page_header_section_size"><?php esc_html_e( 'Page Title Section Size:', 'patiotime' ); ?></label>
				<select name="patiotime_single_page_header_section_size">
					<option value="" <?php selected( $page_title_size, '' ); ?>><?php esc_html_e( 'Default', 'patiotime' ); ?></option>
					<option value="page-title-small" <?php selected( $page_title_size, 'page-title-small' ); ?>><?php esc_html_e( 'Small', 'patiotime' ); ?></option>
					<option value="page-title-default" <?php selected( $page_title_size, 'page-title-default' ); ?>><?php esc_html_e( 'Medium', 'patiotime' ); ?></option>
					<option value="page-title-large" <?php selected( $page_title_size, 'page-title-large' ); ?>><?php esc_html_e( 'Large', 'patiotime' ); ?></option>
				</select>
			</p>

			<p>
				<label for="patiotime_single_page_custom_page_title_margin_top_source" style="line-height: 18px;"><?php esc_html_e( 'Adjust Top Distance Below Overlap Site Header:', 'patiotime' ); ?></label>
				<select name="patiotime_single_page_custom_page_title_margin_top_source">
					<option value="" <?php selected( $custom_page_title_margin_top_source, '' ); ?>><?php esc_html_e( 'Inherit', 'patiotime' ); ?></option>
					<option value="custom" <?php selected( $custom_page_title_margin_top_source, 'custom' ); ?>><?php esc_html_e( 'Custom', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="patiotime-single-custom-page-title-margin-top-wrapper"<?php if ( $hide_custom_page_title_margin_top ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_page_custom_page_title_desktop_margin_top"><?php esc_html_e( 'For Desktop View:', 'patiotime' ); ?></label>
				<input type="number" name="patiotime_single_page_custom_page_title_desktop_margin_top" id="patiotime_single_page_custom_page_title_desktop_margin_top" value="<?php echo esc_attr( $custom_page_title_desktop_margin_top ); ?>">
			</p>
			<p class="patiotime-single-custom-page-title-margin-top-wrapper"<?php if ( $hide_custom_page_title_margin_top ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_page_custom_page_title_tablet_margin_top"><?php esc_html_e( 'For Tablet View:', 'patiotime' ); ?></label>
				<input type="number" name="patiotime_single_page_custom_page_title_tablet_margin_top" id="patiotime_single_page_custom_page_title_tablet_margin_top" value="<?php echo esc_attr( $custom_page_title_tablet_margin_top ); ?>">
			</p>
			<p class="patiotime-single-custom-page-title-margin-top-wrapper"<?php if ( $hide_custom_page_title_margin_top ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_page_custom_page_title_mobile_margin_top"><?php esc_html_e( 'For Mobile View:', 'patiotime' ); ?></label>
				<input type="number" name="patiotime_single_page_custom_page_title_mobile_margin_top" id="patiotime_single_page_custom_page_title_mobile_margin_top" value="<?php echo esc_attr( $custom_page_title_mobile_margin_top ); ?>">
			</p>

			<p>
				<label for="patiotime_single_page_header_background_color"><?php esc_html_e( 'Background Color:', 'patiotime' ); ?></label>
				<input name="patiotime_single_page_header_background_color" class="color-picker" id="patiotime_single_page_header_background_color" type="text" value="<?php echo esc_attr( $background_color ); ?>">
			</p>
			<p>
				<label for="patiotime_single_page_header_background_image"><?php esc_html_e( 'Background Image:', 'patiotime' ); ?></label>
				<span class="description"><?php esc_html_e( 'Upload a featured image and it will be used as the background image of page title section.', 'patiotime' ); ?></span>
			</p>
			<p class="background-settings"<?php if ( ! $has_background_image ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_page_header_background_position_x"><?php esc_html_e( 'Background Position X:', 'patiotime' ); ?></label>
				<select name="patiotime_single_page_header_background_position_x">
					<option value="left" <?php selected( $background_positionx, 'left' ); ?>><?php esc_html_e( 'Left', 'patiotime' ); ?></option>
					<option value="center" <?php selected( $background_positionx, 'center' ); ?>><?php esc_html_e( 'Center', 'patiotime' ); ?></option>
					<option value="right" <?php selected( $background_positionx, 'right' ); ?>><?php esc_html_e( 'Right', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="background-settings"<?php if ( ! $has_background_image ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_page_header_background_position_y"><?php esc_html_e( 'Background Position Y:', 'patiotime' ); ?></label>
				<select name="patiotime_single_page_header_background_position_y">
					<option value="top" <?php selected( $background_positiony, 'top' ); ?>><?php esc_html_e( 'Top', 'patiotime' ); ?></option>
					<option value="center" <?php selected( $background_positiony, 'center' ); ?>><?php esc_html_e( 'Center', 'patiotime' ); ?></option>
					<option value="bottom" <?php selected( $background_positiony, 'bottom' ); ?>><?php esc_html_e( 'Bottom', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="background-settings"<?php if ( ! $has_background_image ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_page_header_background_size"><?php esc_html_e( 'Background Size:', 'patiotime' ); ?></label>
				<select name="patiotime_single_page_header_background_size">
					<option value="auto" <?php selected( $background_size, 'auto' ); ?>><?php esc_html_e( 'Original', 'patiotime' ); ?></option>
					<option value="contain" <?php selected( $background_size, 'contain' ); ?>><?php esc_html_e( 'Fit to Screen', 'patiotime' ); ?></option>
					<option value="cover" <?php selected( $background_size, 'cover' ); ?>><?php esc_html_e( 'Fill Screen', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="background-settings"<?php if ( ! $has_background_image ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_page_header_background_repeat"><?php esc_html_e( 'Background Repeat:', 'patiotime' ); ?></label>
				<input type="checkbox" name="patiotime_single_page_header_background_repeat" id="patiotime_single_page_header_background_repeat" value="on" <?php checked( $background_repeat, 'on' ); ?>>
			</p>
			<p class="background-settings"<?php if ( ! $has_background_image ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_page_header_background_scroll"><?php esc_html_e( 'Background Image Scroll with Page:', 'patiotime' ); ?></label>
				<input type="checkbox" name="patiotime_single_page_header_background_scroll" id="patiotime_single_page_header_background_scroll" value="on" <?php checked( $background_attachment, 'on' ); ?>>
			</p>
			<?php if ( patiotime_is_yoast_seo_activated() && $this->enable_breadcrumbs() ) : ?>
			<p>
				<label for="patiotime_single_page_header_show_breadcrumb"><?php esc_html_e( 'Display Breadcrumb:', 'patiotime' ); ?></label>
				<select name="patiotime_single_page_header_show_breadcrumb" id="patiotime_single_page_header_show_breadcrumb">
					<option value="" <?php selected( $show_yoast_seo_breadcrumb, '' ); ?>><?php esc_html_e( 'Default', 'patiotime' ); ?></option>
					<option value="show" <?php selected( $show_yoast_seo_breadcrumb, 'show' ); ?>><?php esc_html_e( 'Show', 'patiotime' ); ?></option>
					<option value="hide" <?php selected( $show_yoast_seo_breadcrumb, 'hide' ); ?>><?php esc_html_e( 'Hide', 'patiotime' ); ?></option>
				 </select>
			</p>
			<?php endif; ?>
			<p>
				<label for="patiotime_single_page_header_text_color"><?php esc_html_e( 'Text Color:', 'patiotime' ); ?></label>
				<input name="patiotime_single_page_header_text_color" class="color-picker" id="patiotime_single_page_header_text_color" type="text" value="<?php echo esc_attr( $text_color ); ?>">
			</p>

			<h4 class="section-title"><?php esc_html_e( 'Site Footer', 'patiotime' ); ?></h4>
			<p>
				<label for="patiotime_single_page_site_footer_hide_main"><?php esc_html_e( 'Hide Site Footer Main:', 'patiotime' ); ?></label>
				<input type="checkbox" name="patiotime_single_page_site_footer_hide_main" id="patiotime_single_page_site_footer_hide_main" value="on" <?php checked( $hide_footer_main, 'on' ); ?>>
			</p>
			<p class="patiotime-single-site-footer-main-source-wrapper"<?php if ( $hide_footer_main_source ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_site_footer_main_source"><?php esc_html_e( 'Site Footer Main Source:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_site_footer_main_source">
					<option value="" <?php selected( $custom_footer_main_source, '' ); ?>><?php esc_html_e( 'Inherit', 'patiotime' ); ?></option>
					<option value="custom" <?php selected( $custom_footer_main_source, 'custom' ); ?>><?php esc_html_e( 'Custom', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="patiotime-single-custom-footer-main-wrapper"<?php if ( $hide_custom_footer_main ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_site_footer_main"><?php esc_html_e( 'Select a Custom Site Footer Main:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_site_footer_main">
					<?php foreach ( $custom_blocks as $id => $label ) : ?>
						<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $custom_footer_main, $id ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select><br>
				<span class="description"><?php
					printf(
						// translators: 1/2. html tag
						esc_html__( 'If there is no option in the dropdown list, please click %1$shere%2$s to create your own custom site footer main first.', 'patiotime' ),
						'<a href="' . esc_url( admin_url( 'edit.php?post_type=custom_blocks' ) ) . '" target="_blank">',
						'</a>'
					); ?>
				</span>
			</p>

			<p>
				<label for="patiotime_single_page_site_footer_hide_above"><?php esc_html_e( 'Hide Before Footer:', 'patiotime' ); ?></label>
				<input type="checkbox" name="patiotime_single_page_site_footer_hide_above" id="patiotime_single_page_site_footer_hide_above" value="on" <?php checked( $hide_footer_above, 'on' ); ?>>
			</p>
			<p class="patiotime-single-site-footer-above-source-wrapper"<?php if ( $hide_footer_main_source ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_site_footer_above_source"><?php esc_html_e( 'Before Footer Source:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_site_footer_above_source">
					<option value="" <?php selected( $custom_footer_above_source, '' ); ?>><?php esc_html_e( 'Inherit', 'patiotime' ); ?></option>
					<option value="custom" <?php selected( $custom_footer_above_source, 'custom' ); ?>><?php esc_html_e( 'Custom', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="patiotime-single-custom-footer-above-wrapper"<?php if ( $hide_custom_footer_above ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_site_footer_above"><?php esc_html_e( 'Select a Custom Before Footer:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_site_footer_above">
					<?php foreach ( $custom_blocks as $id => $label ) : ?>
						<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $custom_footer_above, $id ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</p>

			<p>
				<label for="patiotime_single_page_site_footer_hide_instagram"><?php esc_html_e( 'Hide Instagram:', 'patiotime' ); ?></label>
				<input type="checkbox" name="patiotime_single_page_site_footer_hide_instagram" id="patiotime_single_page_site_footer_hide_instagram" value="on" <?php checked( $hide_footer_instagram, 'on' ); ?>>
			</p>
			<p>
				<label for="patiotime_single_page_site_footer_hide_bottom"><?php esc_html_e( 'Hide Footer Bottom:', 'patiotime' ); ?></label>
				<input type="checkbox" name="patiotime_single_page_site_footer_hide_bottom" id="patiotime_single_page_site_footer_hide_bottom" value="on" <?php checked( $hide_footer_bottom, 'on' ); ?>>
			</p>

			<?php if ( ! $hide_mobile_menu_source ) : ?><h4 class="section-title"><?php esc_html_e( 'Fullscreen/Mobile Menu', 'patiotime' ); ?></h4><?php endif; ?>
			<p class="patiotime-single-mobile-menu-source-wrapper"<?php if ( $hide_mobile_menu_source ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_mobile_menu_source"><?php esc_html_e( 'Fullscreen/Mobile Menu Source:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_mobile_menu_source">
					<option value="" <?php selected( $mobile_menu_source, '' ); ?>><?php esc_html_e( 'Inherit', 'patiotime' ); ?></option>
					<option value="custom" <?php selected( $mobile_menu_source, 'custom' ); ?>><?php esc_html_e( 'Custom', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="patiotime-single-custom-mobile-menu-wrapper"<?php if ( $hide_custom_mobile_menu ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_mobile_menu"><?php esc_html_e( 'Select a Custom Fullscreen/Mobile Menu:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_mobile_menu">
					<?php foreach ( $custom_blocks as $id => $label ) : ?>
						<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $custom_mobile_menu, $id ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select><br>
				<span class="description"><?php
					printf(
						// translators: 1/2. html tag
						esc_html__( 'If there is no option in the dropdown list, please click %1$shere%2$s to create your own custom mobile menu first.', 'patiotime' ),
						'<a href="' . esc_url( admin_url( 'edit.php?post_type=custom_blocks' ) ) . '" target="_blank">',
						'</a>'
					); ?>
				</span>
			</p>
			<p class="patiotime-single-custom-mobile-menu-wrapper"<?php if ( $hide_custom_mobile_menu ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_mobile_menu_animation"><?php esc_html_e( 'Entrance Animation:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_mobile_menu_animation">
					<option value="" <?php selected( $custom_mobile_menu_animation, '' ); ?>><?php esc_html_e( 'Slide From Right', 'patiotime' ); ?></option>
					<option value="slide-from-left" <?php selected( $custom_mobile_menu_animation, 'slide-from-left' ); ?>><?php esc_html_e( 'Slide From Left', 'patiotime' ); ?></option>
					<option value="fade-in" <?php selected( $custom_mobile_menu_animation, 'fade-in' ); ?>><?php esc_html_e( 'Fade In', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="patiotime-single-custom-mobile-menu-wrapper"<?php if ( $hide_custom_mobile_menu ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_mobile_menu_width"><?php esc_html_e( 'Width:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_mobile_menu_width">
					<option value="" <?php selected( $custom_mobile_menu_width, '' ); ?>><?php esc_html_e( 'Default', 'patiotime' ); ?></option>
					<option value="fullwidth" <?php selected( $custom_mobile_menu_width, 'fullwidth' ); ?>><?php esc_html_e( 'Fit to Screen', 'patiotime' ); ?></option>
					<option value="custom-width" <?php selected( $custom_mobile_menu_width, 'custom-width' ); ?>><?php esc_html_e( 'Custom', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="patiotime-single-custom-mobile-menu-custom-width-wrapper"<?php if ( $hide_custom_mobile_menu_custom_width ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_mobile_menu_custom_width"><?php esc_html_e( 'Custom Width:', 'patiotime' ); ?></label>
				<input type="number" min="1" name="patiotime_single_custom_mobile_menu_custom_width" value="<?php echo esc_attr( $custom_mobile_menu_custom_width ); ?>" style="width: 80px;"> px
			</p><?php
		}
		/**
		* Save metas from page meta box
		* @param string id
		* @param object
		* @param string
		*/
		public function save_page_meta( $post_id ) {
			$checkbox_input = array(
				'patiotime_single_page_hide_site_header',
				'patiotime_single_page_hide_page_title',
				'patiotime_single_page_site_footer_hide_main',
				'patiotime_single_page_site_footer_hide_above',
				'patiotime_single_page_site_footer_hide_instagram',
				'patiotime_single_page_site_footer_hide_bottom'
			);
			foreach ( $checkbox_input as $checkbox_id ) {
				$checkbox_value = empty( $_REQUEST[ $checkbox_id ] ) ? '' : 'on';
				update_post_meta( $post_id, $checkbox_id, $checkbox_value );
			}

			$text_input = array(
				'patiotime_single_page_site_header_source',
				'patiotime_single_page_custom_site_header',
				'patiotime_single_page_custom_sticky_site_header',
                'patiotime_single_page_custom_page_title_margin_top_source',
                'patiotime_single_page_custom_page_title_desktop_margin_top',
                'patiotime_single_page_custom_page_title_tablet_margin_top',
                'patiotime_single_page_custom_page_title_mobile_margin_top',
				'patiotime_single_page_header_section_size',
				'patiotime_single_page_header_background_color',
				'patiotime_single_page_header_background_position_x',
				'patiotime_single_page_header_background_position_y',
				'patiotime_single_page_header_background_size',
				'patiotime_single_page_header_text_color',
				'patiotime_single_page_header_background_image_url',
				'patiotime_single_page_header_show_breadcrumb',
				'patiotime_single_custom_mobile_menu_source',
				'patiotime_single_custom_mobile_menu',
				'patiotime_single_custom_mobile_menu_animation',
				'patiotime_single_custom_mobile_menu_width',
				'patiotime_single_custom_mobile_menu_custom_width',
				'patiotime_single_custom_site_footer_main_source',
				'patiotime_single_custom_site_footer_main',
				'patiotime_single_custom_site_footer_above_source',
				'patiotime_single_custom_site_footer_above'
			);
			foreach ( $text_input as $text_id ) {
				$text_value = empty( $_REQUEST[ $text_id ] ) ? '' : sanitize_text_field( wp_unslash( $_REQUEST[ $text_id ] ) );
				update_post_meta( $post_id, $text_id, $text_value );
			}
			$background_image = empty( $_REQUEST[ 'patiotime_single_page_header_background_image' ] ) ? 0 : absint( wp_unslash( $_REQUEST[ 'patiotime_single_page_header_background_image' ] ) );
			update_post_meta( $post_id, 'patiotime_single_page_header_background_image', $background_image );

			$on_off = array(
				'patiotime_single_page_header_background_repeat',
				'patiotime_single_page_header_background_scroll'
			);
			foreach ( $on_off as $setting_id ) {
				update_post_meta( $post_id, $setting_id, ( empty( $_REQUEST[ $setting_id ] ) ? 'off' : 'on' ) );
			}
		}
		/**
		* Helper function
		*/
		protected function enable_breadcrumbs() {
			$pages = array( get_option( 'page_on_front' ), get_option( 'page_for_posts' ) );
			$pages = apply_filters( 'patiotime_woocommerce_static_pages', $pages );
			$pages = array_filter( $pages );
			$pages = array_unique( $pages );
			$current_post_id = 0;
			if ( isset( $_REQUEST[ 'post' ] ) ) {
				$current_post_id = sanitize_text_field( wp_unslash( $_REQUEST[ 'post' ] ) );
			}
			return ! patiotime_is_valid_array( $pages ) || ! in_array( $current_post_id, $pages );
		}
	}
	new PatioTime_Page_Metas();
}
