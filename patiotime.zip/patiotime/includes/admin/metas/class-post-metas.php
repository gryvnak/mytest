<?php
if ( ! class_exists( 'PatioTime_Post_Metas' ) ) {
	class PatioTime_Post_Metas {
		/**
		* Construct function
		*/
		public function __construct() {
			add_action( 'loftocean_post_metabox_html', 	array( $this, 'post_metabox' ) );
			add_action( 'loftocean_save_post_metabox_settings', array( $this, 'save_post_meta' ), 10, 1 );
			add_filter( 'loftocean_metabox_get_post_title', array( $this, 'change_post_metabox_title' ), 10, 2 );

			if ( patiotime_is_gutenberg_enabled() ) {
				add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_editor_assets' ), 5 );
			}
		}
		/**
		* Enqueue gutenberg editor assets
		*/
		public function enqueue_editor_assets() {
			wp_enqueue_script(
				'patiotime-gutenberg-post-script',
				PATIOTIME_ASSETS_URI . 'scripts/editor/post-settings.js',
				array( 'wp-element', 'wp-i18n', 'wp-hooks', 'wp-components', 'wp-blocks', 'jquery' ),
				PATIOTIME_ASSETS_VERSION,
				true
			);
			wp_localize_script( 'patiotime-gutenberg-post-script', 'patiotimeBlockEditorSettings', array(
				'customBlock' => patiotime_get_custom_post_type( 'custom_blocks' ),
				'customSiteHeader' => patiotime_get_custom_post_type( 'custom_site_headers' ),
				'disableStickySiteHeader' => ( 'disable' == patiotime_get_theme_mod( 'patiotime_sticky_site_header' ) )
			) );
		}
		/**
		* Change post metabox title
		* @param string
		* @param string
		* @return string
		*/
		public function change_post_metabox_title( $title, $type ) {
			if ( 'post' == $type ) {
				return esc_html__( 'PatioTime Single Post Options', 'patiotime' );
			} else {
				return $title;
			}
		}
		/**
		* Show post meta box html
		* @param object
		*/
		public function post_metabox( $post ) {
			$post_id = $post->ID;
			$hide_site_header = get_post_meta( $post_id, 'patiotime_single_post_hide_site_header', true );
			$site_header_source = get_post_meta( $post_id, 'patiotime_single_post_site_header_source', true );
			$custom_site_header = get_post_meta( $post_id, 'patiotime_single_post_custom_site_header', true );
			$custom_sticky_site_header = get_post_meta( $post_id, 'patiotime_single_post_custom_sticky_site_header', true );
			$hide_post_title = get_post_meta( $post_id, 'patiotime_single_post_hide_page_title', true );
			$hide_footer_main = get_post_meta( $post_id, 'patiotime_single_post_site_footer_hide_main', true );
			$custom_footer_main_source = get_post_meta( $post_id, 'patiotime_single_custom_site_footer_main_source', true );
			$custom_footer_main = get_post_meta( $post_id, 'patiotime_single_custom_site_footer_main', true );
			$hide_footer_above = get_post_meta( $post_id, 'patiotime_single_post_site_footer_hide_above', true );
			$custom_footer_above_source = get_post_meta( $post_id, 'patiotime_single_custom_site_footer_above_source', true );
			$custom_footer_above = get_post_meta( $post_id, 'patiotime_single_custom_site_footer_above', true );
			$hide_footer_instagram = get_post_meta( $post_id, 'patiotime_single_post_site_footer_hide_instagram', true );
			$hide_footer_bottom = get_post_meta( $post_id, 'patiotime_single_post_site_footer_hide_bottom', true );
			$post_template = get_post_meta( $post_id, 'patiotime_single_post_template', true );

			$custom_headers = patiotime_get_custom_post_type( 'custom_site_headers' );
			$custom_blocks = patiotime_get_custom_post_type( 'custom_blocks' );

			$custom_page_title_margin_top_source = get_post_meta( $post_id, 'patiotime_single_post_custom_page_title_margin_top_source', true );
			$custom_page_title_desktop_margin_top = get_post_meta( $post_id, 'patiotime_single_post_custom_page_title_desktop_margin_top', true );
			$custom_page_title_tablet_margin_top = get_post_meta( $post_id, 'patiotime_single_post_custom_page_title_tablet_margin_top', true );
			$custom_page_title_mobile_margin_top = get_post_meta( $post_id, 'patiotime_single_post_custom_page_title_mobile_margin_top', true );

			$mobile_menu_source = get_post_meta( $post_id, 'patiotime_single_custom_mobile_menu_source', true );
			$custom_mobile_menu = get_post_meta( $post_id, 'patiotime_single_custom_mobile_menu', true );
			$custom_mobile_menu_animation = get_post_meta( $post_id, 'patiotime_single_custom_mobile_menu_animation', true );
			$custom_mobile_menu_width = get_post_meta( $post_id, 'patiotime_single_custom_mobile_menu_width', true );
			$custom_mobile_menu_custom_width = get_post_meta( $post_id, 'patiotime_single_custom_mobile_menu_custom_width', true );

			$hide_mobile_menu_source = ! patiotime_is_valid_array( $custom_blocks );
			$hide_custom_mobile_menu = $hide_mobile_menu_source || ( 'custom' != $mobile_menu_source );
			$hide_custom_mobile_menu_custom_width = $hide_custom_mobile_menu || ( 'custom-width' != $custom_mobile_menu_width );

			$hide_source = ( 'on' == $hide_site_header );
			$hide_custom_headers = $hide_source || ( 'custom' != $site_header_source );

			$hide_custom_page_title_margin_top = ( 'custom' != $custom_page_title_margin_top_source );

			$hide_footer_main_source = ( 'on' == $hide_footer_main );
			$hide_custom_footer_main = $hide_footer_main_source || ( 'custom' != $custom_footer_main_source );

			$hide_footer_above_source = ( 'on' == $hide_footer_above );
			$hide_custom_footer_above = $hide_footer_above_source || ( 'custom' != $custom_footer_above_source ); ?>

			<h4 class="section-title"><?php esc_html_e( 'Site Header', 'patiotime' ); ?></h4>
			<p>
				<label for="patiotime_single_post_hide_site_header"><?php esc_html_e( 'Hide Site Header:', 'patiotime' ); ?></label>
				<input type="checkbox" name="patiotime_single_post_hide_site_header" id="patiotime_single_post_hide_site_header" value="on" <?php checked( $hide_site_header, 'on' ); ?>>
			</p>
			<p class="patiotime-single-header-source-wrapper"<?php if ( $hide_source ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_post_site_header_source"><?php esc_html_e( 'Site Header Source:', 'patiotime' ); ?></label>
				<select name="patiotime_single_post_site_header_source">
					<option value="" <?php selected( $site_header_source, '' ); ?>><?php esc_html_e( 'Inherit', 'patiotime' ); ?></option>
					<option value="custom" <?php selected( $site_header_source, 'custom' ); ?>><?php esc_html_e( 'Custom', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="patiotime-single-custom-site-headers-wrapper"<?php if ( $hide_custom_headers ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_post_custom_site_header"><?php esc_html_e( 'Select a Custom Site Header:', 'patiotime' ); ?></label>
				<select name="patiotime_single_post_custom_site_header">
					<?php foreach ( $custom_headers as $id => $label ) : ?>
						<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $custom_site_header, $id ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select><br>
				<span class="description"><?php
					printf(
						// translators: 1/2. html tag
						esc_html__( 'If there is no option in the dropdown list, please click %1$shere%2$s to create your own site header first.', 'patiotime' ),
						'<a href="' . esc_url( admin_url( 'edit.php?post_type=custom_site_headers' ) ) . '" target="_blank">',
						'</a>'
					); ?>
				</span>
			</p><?php
			if ( 'disable' != patiotime_get_theme_mod( 'patiotime_sticky_site_header' ) ) : ?>
			<p class="patiotime-single-custom-site-headers-wrapper"<?php if ( $hide_custom_headers ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_post_custom_sticky_site_header"><?php esc_html_e( 'Select a Custom Sticky Site Header:', 'patiotime' ); ?></label>
				<select name="patiotime_single_post_custom_sticky_site_header">
					<?php foreach ( $custom_headers as $id => $label ) : ?>
						<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $custom_sticky_site_header, $id ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select><br>
				<span class="description"><?php esc_html_e( 'You can choose another custom site header as the sticky header', 'patiotime' ); ?></span>
			</p><?php
			endif; ?>

			<h4 class="section-title"><?php esc_html_e( 'Page Title Section', 'patiotime' ); ?></h4>
			<p>
				<label for="patiotime_single_post_hide_page_title"><?php esc_html_e( 'Hide Page Title Section:', 'patiotime' ); ?></label>
				<input type="checkbox" name="patiotime_single_post_hide_page_title" id="patiotime_single_post_hide_page_title" value="on" <?php checked( $hide_post_title, 'on' ); ?>>
			</p>

			<p>
				<label for="patiotime_single_post_custom_page_title_margin_top_source" style="line-height: 18px;"><?php esc_html_e( 'Adjust Top Distance Below Overlap Site Header:', 'patiotime' ); ?></label>
				<select name="patiotime_single_post_custom_page_title_margin_top_source">
					<option value="" <?php selected( $custom_page_title_margin_top_source, '' ); ?>><?php esc_html_e( 'Inherit', 'patiotime' ); ?></option>
					<option value="custom" <?php selected( $custom_page_title_margin_top_source, 'custom' ); ?>><?php esc_html_e( 'Custom', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="patiotime-single-custom-page-title-margin-top-wrapper"<?php if ( $hide_custom_page_title_margin_top ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_post_custom_page_title_desktop_margin_top"><?php esc_html_e( 'For Desktop View:', 'patiotime' ); ?></label>
				<input type="number" name="patiotime_single_post_custom_page_title_desktop_margin_top" id="patiotime_single_post_custom_page_title_desktop_margin_top" value="<?php echo esc_attr( $custom_page_title_desktop_margin_top ); ?>"> px
			</p>
			<p class="patiotime-single-custom-page-title-margin-top-wrapper"<?php if ( $hide_custom_page_title_margin_top ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_post_custom_page_title_tablet_margin_top"><?php esc_html_e( 'For Tablet View:', 'patiotime' ); ?></label>
				<input type="number" name="patiotime_single_post_custom_page_title_tablet_margin_top" id="patiotime_single_post_custom_page_title_tablet_margin_top" value="<?php echo esc_attr( $custom_page_title_tablet_margin_top ); ?>"> px
			</p>
			<p class="patiotime-single-custom-page-title-margin-top-wrapper"<?php if ( $hide_custom_page_title_margin_top ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_post_custom_page_title_mobile_margin_top"><?php esc_html_e( 'For Mobile View:', 'patiotime' ); ?></label>
				<input type="number" name="patiotime_single_post_custom_page_title_mobile_margin_top" id="patiotime_single_post_custom_page_title_mobile_margin_top" value="<?php echo esc_attr( $custom_page_title_mobile_margin_top ); ?>"> px
			</p>

			<h4 class="section-title"><?php esc_html_e( 'Site Footer', 'patiotime' ); ?></h4>
			<p>
				<label for="patiotime_single_post_site_footer_hide_main"><?php esc_html_e( 'Hide Site Footer Main:', 'patiotime' ); ?></label>
				<input type="checkbox" name="patiotime_single_post_site_footer_hide_main" id="patiotime_single_post_site_footer_hide_main" value="on" <?php checked( $hide_footer_main, 'on' ); ?>>
			</p>
			<p class="patiotime-single-site-footer-main-source-wrapper"<?php if ( $hide_footer_main_source ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_site_footer_main_source"><?php esc_html_e( 'Site Footer Main Source:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_site_footer_main_source">
					<option value="" <?php selected( $custom_footer_main_source, '' ); ?>><?php esc_html_e( 'Inherit', 'patiotime' ); ?></option>
					<option value="custom" <?php selected( $custom_footer_main_source, 'custom' ); ?>><?php esc_html_e( 'Custom', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="patiotime-single-custom-footer-main-wrapper"<?php if ( $hide_custom_footer_main ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_site_footer_main"><?php esc_html_e( 'Select a Custom Site Footer Main:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_site_footer_main">
					<?php foreach ( $custom_blocks as $id => $label ) : ?>
						<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $custom_footer_main, $id ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select><br>
				<span class="description"><?php
					printf(
						// translators: 1/2. html tag
						esc_html__( 'If there is no option in the dropdown list, please click %1$shere%2$s to create your own custom site footer main first.', 'patiotime' ),
						'<a href="' . esc_url( admin_url( 'edit.php?post_type=custom_blocks' ) ) . '" target="_blank">',
						'</a>'
					); ?>
				</span>
			</p>

			<p>
				<label for="patiotime_single_post_site_footer_hide_above"><?php esc_html_e( 'Hide Before Footer:', 'patiotime' ); ?></label>
				<input type="checkbox" name="patiotime_single_post_site_footer_hide_above" id="patiotime_single_post_site_footer_hide_above" value="on" <?php checked( $hide_footer_above, 'on' ); ?>>
			</p>
			<p class="patiotime-single-site-footer-above-source-wrapper"<?php if ( $hide_footer_main_source ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_site_footer_above_source"><?php esc_html_e( 'Before Footer Source:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_site_footer_above_source">
					<option value="" <?php selected( $custom_footer_above_source, '' ); ?>><?php esc_html_e( 'Inherit', 'patiotime' ); ?></option>
					<option value="custom" <?php selected( $custom_footer_above_source, 'custom' ); ?>><?php esc_html_e( 'Custom', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="patiotime-single-custom-footer-above-wrapper"<?php if ( $hide_custom_footer_above ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_site_footer_above"><?php esc_html_e( 'Select a Custom Before Footer:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_site_footer_above">
					<?php foreach ( $custom_blocks as $id => $label ) : ?>
						<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $custom_footer_above, $id ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</p>

			<p>
				<label for="patiotime_single_post_site_footer_hide_instagram"><?php esc_html_e( 'Hide Instagram:', 'patiotime' ); ?></label>
				<input type="checkbox" name="patiotime_single_post_site_footer_hide_instagram" id="patiotime_single_post_site_footer_hide_instagram" value="on" <?php checked( $hide_footer_instagram, 'on' ); ?>>
			</p>
			<p>
				<label for="patiotime_single_post_site_footer_hide_bottom"><?php esc_html_e( 'Hide Footer Bottom:', 'patiotime' ); ?></label>
				<input type="checkbox" name="patiotime_single_post_site_footer_hide_bottom" id="patiotime_single_post_site_footer_hide_bottom" value="on" <?php checked( $hide_footer_bottom, 'on' ); ?>>
			</p>

			<?php if ( ! $hide_mobile_menu_source ) : ?><h4 class="section-title"><?php esc_html_e( 'Fullscreen/Mobile Menu', 'patiotime' ); ?></h4><?php endif; ?>
			<p class="patiotime-single-mobile-menu-source-wrapper"<?php if ( $hide_mobile_menu_source ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_mobile_menu_source"><?php esc_html_e( 'Fullscreen/Mobile Menu Source:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_mobile_menu_source">
					<option value="" <?php selected( $mobile_menu_source, '' ); ?>><?php esc_html_e( 'Inherit', 'patiotime' ); ?></option>
					<option value="custom" <?php selected( $mobile_menu_source, 'custom' ); ?>><?php esc_html_e( 'Custom', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="patiotime-single-custom-mobile-menu-wrapper"<?php if ( $hide_custom_mobile_menu ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_mobile_menu"><?php esc_html_e( 'Select a Custom Fullscreen/Mobile Menu:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_mobile_menu">
					<?php foreach ( $custom_blocks as $id => $label ) : ?>
						<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $custom_mobile_menu, $id ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select><br>
				<span class="description"><?php
					printf(
						// translators: 1/2. html tag
						esc_html__( 'If there is no option in the dropdown list, please click %1$shere%2$s to create your own custom mobile menu first.', 'patiotime' ),
						'<a href="' . esc_url( admin_url( 'edit.php?post_type=custom_blocks' ) ) . '" target="_blank">',
						'</a>'
					); ?>
				</span>
			</p>
			<p class="patiotime-single-custom-mobile-menu-wrapper"<?php if ( $hide_custom_mobile_menu ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_mobile_menu_animation"><?php esc_html_e( 'Entrance Animation:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_mobile_menu_animation">
					<option value="" <?php selected( $custom_mobile_menu_animation, '' ); ?>><?php esc_html_e( 'Slide From Right', 'patiotime' ); ?></option>
					<option value="slide-from-left" <?php selected( $custom_mobile_menu_animation, 'slide-from-left' ); ?>><?php esc_html_e( 'Slide From Left', 'patiotime' ); ?></option>
					<option value="fade-in" <?php selected( $custom_mobile_menu_animation, 'fade-in' ); ?>><?php esc_html_e( 'Fade In', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="patiotime-single-custom-mobile-menu-wrapper"<?php if ( $hide_custom_mobile_menu ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_mobile_menu_width"><?php esc_html_e( 'Width:', 'patiotime' ); ?></label>
				<select name="patiotime_single_custom_mobile_menu_width">
					<option value="" <?php selected( $custom_mobile_menu_width, '' ); ?>><?php esc_html_e( 'Default', 'patiotime' ); ?></option>
					<option value="fullwidth" <?php selected( $custom_mobile_menu_width, 'fullwidth' ); ?>><?php esc_html_e( 'Fit to Screen', 'patiotime' ); ?></option>
					<option value="custom-width" <?php selected( $custom_mobile_menu_width, 'custom-width' ); ?>><?php esc_html_e( 'Custom', 'patiotime' ); ?></option>
				</select>
			</p>
			<p class="patiotime-single-custom-mobile-menu-custom-width-wrapper"<?php if ( $hide_custom_mobile_menu_custom_width ) : ?> style="display: none;"<?php endif; ?>>
				<label for="patiotime_single_custom_mobile_menu_custom_width"><?php esc_html_e( 'Custom Width:', 'patiotime' ); ?></label>
				<input type="number" min="1" name="patiotime_single_custom_mobile_menu_custom_width" value="<?php echo esc_attr( $custom_mobile_menu_custom_width ); ?>" style="width: 80px;"> px
			</p>

			<h4 class="section-title"><?php esc_html_e( 'Post Template', 'patiotime' ); ?></h4>
			<p>
				<label for="patiotime_single_post_template"><?php esc_html_e( 'Post Template:', 'patiotime' ); ?></label>
				<select name="patiotime_single_post_template">
					<option value="" <?php selected( $post_template, '' ); ?>><?php esc_html_e( 'Default ( inherit from Customize > Blog > Single Post > Default Sidebar Layout )', 'patiotime' ); ?></option>
					<option value="with-sidebar-right" <?php selected( $post_template, 'with-sidebar-right' ); ?>><?php esc_html_e( 'Right Sidebar', 'patiotime' ); ?></option>
					<option value="with-sidebar-left" <?php selected( $post_template, 'with-sidebar-left' ); ?>><?php esc_html_e( 'Left Sidebar', 'patiotime' ); ?></option>
					<option value="fullwidth" <?php selected( $post_template, 'fullwidth' ); ?>><?php esc_html_e( 'No Sidebar', 'patiotime' ); ?></option>
				</select>
			</p><?php
		}
		/**
		* Save post meta
		* @param int post id
		*/
		public function save_post_meta( $post_id ) {
			$checkbox = array(
				'patiotime_single_post_hide_site_header',
				'patiotime_single_post_hide_page_title',
				'patiotime_single_post_site_footer_hide_main',
				'patiotime_single_post_site_footer_hide_above',
				'patiotime_single_post_site_footer_hide_instagram',
				'patiotime_single_post_site_footer_hide_bottom'
			);
			$selects = array(
				'patiotime_single_post_site_header_source',
				'patiotime_single_post_custom_site_header',
				'patiotime_single_post_custom_sticky_site_header',
                'patiotime_single_post_custom_page_title_margin_top_source',
                'patiotime_single_post_custom_page_title_desktop_margin_top',
                'patiotime_single_post_custom_page_title_tablet_margin_top',
                'patiotime_single_post_custom_page_title_mobile_margin_top',
				'patiotime_single_post_template',
				'patiotime_single_custom_mobile_menu_source',
				'patiotime_single_custom_mobile_menu',
				'patiotime_single_custom_mobile_menu_animation',
				'patiotime_single_custom_mobile_menu_width',
				'patiotime_single_custom_mobile_menu_custom_width',
				'patiotime_single_custom_site_footer_main_source',
				'patiotime_single_custom_site_footer_main',
				'patiotime_single_custom_site_footer_above_source',
				'patiotime_single_custom_site_footer_above'
			);
			foreach ( $checkbox as $option ) {
				$value = isset( $_REQUEST[ $option ] ) ? 'on' : '';
				update_post_meta( $post_id, $option, $value );
			}
			foreach ( $selects as $option ) {
				$value = isset( $_REQUEST[ $option ] ) ? sanitize_text_field( wp_unslash( $_REQUEST[ $option ] ) ) : '';
				update_post_meta( $post_id, $option, $value );
			}
		}
	}
	new PatioTime_Post_Metas();
}
