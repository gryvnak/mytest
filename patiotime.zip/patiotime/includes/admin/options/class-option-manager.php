<?php
if ( ! class_exists( 'PatioTime_Options_Manager' ) ) {
    class PatioTime_Options_Manager {
        /**
        * Construct function
        */
        public function __construct() {
            $this->load_files();
        }
        /**
        * Load files
        */
        protected function load_files() {
            require_once PATIOTIME_THEME_INC . 'admin/options/theme-settings/class-theme-settings.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
        }
    }
    new PatioTime_Options_Manager();
}
