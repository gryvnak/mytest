<?php
if ( ! class_exists( 'PatioTime_Theme_Option_Required_Plugins' ) ) {
	class PatioTime_Theme_Option_Required_Plugins extends PatioTime_Theme_Option_Section {
		/**
		* Setup environment
		*/
		protected function setup_env() {
			$this->id = 'tab-plugins';
			$this->title = esc_html__( 'Required Plugins', 'patiotime' );
			$this->defaults = array(
				'patiotime_auto_update_required_plugin' => '',
				'patiotime_auto_activate_required_plugin' => ''
			);

			add_filter( 'patiotime_admin_theme_settings_panel_get_default_tab', array( $this, 'default_tab' ) );
			add_filter( 'patiotime_enable_required_plugin_auto_update', array( $this, 'is_auto_update_enabled' ) );
			add_filter( 'patiotime_enable_required_plugin_auto_activate', array( $this, 'is_auto_active_enabled' ) );
			add_filter( 'auto_update_plugin', array( $this, 'set_plugin_auto_update' ), 999, 2 );
		}
		/**
		* Render tab content
		*/
		public function render_tab_content() {
			$auto_update_status = $this->get_value( 'patiotime_auto_update_required_plugin' );
			$auto_activate_status = $this->get_value( 'patiotime_auto_activate_required_plugin' ); ?>

            <h2><?php esc_html_e( 'PatioTime Core', 'patiotime' ); ?></h2><?php
			if ( $this->is_tgmpa_exists() ) : ?>
	            <p><?php printf(
					// translators: 1 & 2. html tag <strong>
					esc_html__( 'Please make sure you have installed and activated the required plugin %1$s"PatioTime Core"%2$s to get the full functionalities of the theme.', 'patiotime' ),
					'<strong>',
					'</strong>'
				); ?></p>
				<a class="button button-primary button-hero" href="<?php echo esc_url( admin_url( 'themes.php?page=tgmpa-install-plugins' ) ); ?>">
					<?php esc_html_e( 'Install Plugins', 'patiotime' ); ?>
				</a>
	            <hr><?php
			endif; ?>
            <h2><php esc_html_e( 'Auto Options', 'patiotime' ); ?></h2>
            <ul>
                <li>
                    <label for="patiotime_auto_update_required_plugin">
                        <input type="checkbox" id="patiotime_auto_update_required_plugin" name="patiotime_auto_update_required_plugin" value="on" <?php checked( 'on', $auto_update_status ); ?>>
                        <?php esc_html_e( 'Auto update the plugin when updating the theme', 'patiotime' ); ?>
					</label>
                </li>
                <li>
                    <label for="patiotime_auto_activate_required_plugin">
                        <input type="checkbox" id="patiotime_auto_activate_required_plugin" name="patiotime_auto_activate_required_plugin" value="on" <?php checked( 'on', $auto_activate_status ); ?>>
                        <?php esc_html_e( 'Auto activate the plugin when activating the theme', 'patiotime' ); ?>
					</label>
                </li>
                <li>
                    <a href="https://www.loftocean.com/patiotime-doc/documentation.html#basic-settings" target="_blank">
                        <?php esc_html_e( 'When should I enable the auto options above?', 'patiotime' ); ?>
                    </a>
                </li>
            </ul><?php
		}
		/**
		* Register options
		*/
		protected function register_options() {
			$this->options = array(
				'patiotime_auto_update_required_plugin' => 'PatioTime_Utils_Sanitize::sanitize_checkbox',
				'patiotime_auto_activate_required_plugin' => 'PatioTime_Utils_Sanitize::sanitize_checkbox'
			);
		}
		/**
		* Set required plugin auto update
		* @param boolean
		* @param object
		* @return boolean
		*/
		public function set_plugin_auto_update( $should_update, $plugin ) {
			if ( ! isset( $plugin->plugin ) || ( 'patiotime-core/patiotime-core.php' !== $plugin->plugin ) ) {
				return $should_update;
			} else {
				return apply_filters( 'patiotime_enable_required_plugin_auto_update', false );
			}
		}
		/**
		* If enable required plugin auto update
		* @param boolean
		* @return boolean
		*/
		public function is_auto_update_enabled( $enabled ) {
			return 'on' == $this->get_value( 'patiotime_auto_update_required_plugin' );
		}
		/**
		* If enable required plugin auto activate setting value
		* @param boolean
		* @return boolean
		*/
		public function is_auto_active_enabled( $enabled ) {
			return 'on' == $this->get_value( 'patiotime_auto_activate_required_plugin' );
		}
		/**
		* Help function to test tgmpa-install-plugins admin menu exists
		* @return boolean
		*/
		protected function is_tgmpa_exists() {
			global $submenu;
			return in_array( 'tgmpa-install-plugins', wp_list_pluck( $submenu['themes.php'], 2 ) );
		}
		/**
		* Default tab id
		*/
		public function default_tab( $tab ) {
			return $this->id;
		}
	}
	new PatioTime_Theme_Option_Required_Plugins();
}
