<?php
/**
* Customize panel colors/styles configuration files.
*/

if ( ! class_exists( 'PatioTime_Customize_Colors_Styles' ) ) {
	class PatioTime_Customize_Colors_Styles extends PatioTime_Customize_Configuration_Base {
		/**
		* String panel id
		*/
		public $panel_id = 'patiotime_panel_colors_styles';
		/**
		* Array default customize option values
		*/
		public $defaults = array();
		/**
		* Int current section priority
		*/
		protected $section_priority = 0;
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			global $patiotime_default_settings;
			$this->defaults = $patiotime_default_settings;

			$this->add_panel( $wp_customize );
			$this->add_section_general_colors( $wp_customize );
			$this->add_section_link_colors( $wp_customize );
			$this->add_section_button_styles( $wp_customize );
			$this->add_section_form_styles( $wp_customize );
		}
		/**
		* Register panel
		*/
		protected function add_panel( $wp_customize ) {
			$wp_customize->add_panel( $this->panel_id, array(
				'title'    => esc_html__( 'Colors & Styles', 'patiotime' ),
				'priority' => 30
			) );
		}
		/**
		* Register section general colors
		*/
		protected function add_section_general_colors( $wp_customize ) {
			$defaults = $this->defaults;
			$this->section_priority += 5;
			$section_id = 'patiotime_colors_section_general';
			$wp_customize->add_section( $section_id, array(
				'title'		=> esc_html__( 'General Colors', 'patiotime' ),
				'panel' 	=> $this->panel_id,
				'priority' 	=> $this->section_priority
			) );

			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_general_color_scheme', array(
				'default' 			=> $defaults['patiotime_general_color_scheme'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_general_primary_color', array(
				'default' 			=> $defaults['patiotime_general_primary_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_general_secondary_color', array(
				'default' 			=> $defaults['patiotime_general_secondary_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_general_colors_group_title', array(
				'default' 			=> '',
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_empty'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_general_light_scheme_background_color', array(
				'default' 			=> $defaults['patiotime_general_light_scheme_background_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_general_light_scheme_text_color', array(
				'default' 			=> $defaults['patiotime_general_light_scheme_text_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_general_light_scheme_content_color', array(
				'default' 			=> $defaults['patiotime_general_light_scheme_content_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_general_dark_scheme_background_color', array(
				'default' 			=> $defaults['patiotime_general_dark_scheme_background_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_general_dark_scheme_text_color', array(
				'default' 			=> $defaults['patiotime_general_dark_scheme_text_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_general_dark_scheme_content_color', array(
				'default' 			=> $defaults['patiotime_general_dark_scheme_content_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );

			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_general_color_scheme', array(
				'type'              => 'select',
				'label'             => esc_html__( 'Site Color Scheme', 'patiotime' ),
				'section'           => $section_id,
				'settings' 	        => 'patiotime_general_color_scheme',
				'choices'           => array(
					'light-color' => esc_html__( 'Light', 'patiotime' ),
					'dark-color'  => esc_html__( 'Dark', 'patiotime' )
				)
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_general_primary_color', array(
				'label'		=> esc_html__( 'Primary Color', 'patiotime' ),
				'section' 	=> $section_id,
				'settings'	=> 'patiotime_general_primary_color'
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_general_secondary_color', array(
				'label'		=> esc_html__( 'Secondary Color', 'patiotime' ),
				'section' 	=> $section_id,
				'settings'	=> 'patiotime_general_secondary_color'
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_general_colors_group_title', array(
				'type'		=> 'title_only',
				'label'		=> esc_html__( 'Background & Text Colors', 'patiotime' ),
				'section' 	=> $section_id,
				'settings'	=> 'patiotime_general_colors_group_title'
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_general_light_scheme_background_color', array(
				'label'		=> esc_html__( 'Light Scheme Background Color', 'patiotime' ),
				'section' 	=> $section_id,
				'settings'	=> 'patiotime_general_light_scheme_background_color'
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_general_light_scheme_text_color', array(
				'label'		=> esc_html__( 'Light Scheme Text Color', 'patiotime' ),
				'section' 	=> $section_id,
				'settings'	=> 'patiotime_general_light_scheme_text_color'
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_general_light_scheme_content_color', array(
				'label'		=> esc_html__( 'Light Scheme Content Color', 'patiotime' ),
				'section' 	=> $section_id,
				'settings'	=> 'patiotime_general_light_scheme_content_color'
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_general_dark_scheme_background_color', array(
				'label'		=> esc_html__( 'Dark Scheme Background Color', 'patiotime' ),
				'section' 	=> $section_id,
				'settings'	=> 'patiotime_general_dark_scheme_background_color'
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_general_dark_scheme_text_color', array(
				'label'		=> esc_html__( 'Dark Scheme Text Color', 'patiotime' ),
				'section' 	=> $section_id,
				'settings'	=> 'patiotime_general_dark_scheme_text_color'
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_general_dark_scheme_content_color', array(
				'label'		=> esc_html__( 'Dark Scheme Content Color', 'patiotime' ),
				'section' 	=> $section_id,
				'settings'	=> 'patiotime_general_dark_scheme_content_color'
			) ) );
		}
		/**
		* Register section link color
		*/
		protected function add_section_link_colors( $wp_customize ) {
			$defaults = $this->defaults;
			$this->section_priority += 5;
			$section_id = 'patiotime_link_colors';
			$wp_customize->add_section( $section_id, array(
				'title'		=> esc_html__( 'Links', 'patiotime' ),
				'panel' 	=> $this->panel_id,
				'priority'	=> $this->section_priority
			) );

			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_link_light_scheme_regular_color', array(
				'default' 			=> $defaults['patiotime_link_light_scheme_regular_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_link_light_scheme_custom_regular_color', array(
				'default' 			=> $defaults['patiotime_link_light_scheme_custom_regular_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color',
				'dependency' 		=> array( 'patiotime_link_light_scheme_regular_color' => array( 'value' => array( 'custom' ) ) )
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_link_light_scheme_hover_color', array(
				'default' 			=> $defaults['patiotime_link_light_scheme_hover_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_link_light_scheme_custom_hover_color', array(
				'default' 			=> $defaults['patiotime_link_light_scheme_custom_hover_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color',
				'dependency' 		=> array( 'patiotime_link_light_scheme_hover_color' => array( 'value' => array( 'custom' ) ) )
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_link_dark_scheme_regular_color', array(
				'default' 			=> $defaults['patiotime_link_dark_scheme_regular_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_link_dark_scheme_custom_regular_color', array(
				'default' 			=> $defaults['patiotime_link_dark_scheme_custom_regular_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color',
				'dependency' 		=> array( 'patiotime_link_dark_scheme_regular_color' => array( 'value' => array( 'custom' ) ) )
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_link_dark_scheme_hover_color', array(
				'default' 			=> $defaults['patiotime_link_dark_scheme_hover_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_link_dark_scheme_custom_hover_color', array(
				'default' 			=> $defaults['patiotime_link_dark_scheme_custom_hover_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color',
				'dependency' 		=> array( 'patiotime_link_dark_scheme_hover_color' => array( 'value' => array( 'custom' ) ) )
			) ) );

			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_link_light_scheme_regular_color', array(
				'type'              => 'select',
				'label'             => esc_html__( 'Regular - Light Scheme', 'patiotime' ),
				'section'           => $section_id,
				'settings' 	        => 'patiotime_link_light_scheme_regular_color',
				'choices'           => array(
					'primary' => esc_html__( 'Primary Color', 'patiotime' ),
					'secondary'  => esc_html__( 'Secondary Color', 'patiotime' ),
					'custom'  => esc_html__( 'Custom Color', 'patiotime' )
				)
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_link_light_scheme_custom_regular_color', array(
				'section' 			=> $section_id,
				'settings'			=> 'patiotime_link_light_scheme_custom_regular_color',
				'active_callback'	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_link_light_scheme_hover_color', array(
				'type'              => 'select',
				'label'             => esc_html__( 'Hover - Light Scheme', 'patiotime' ),
				'section'           => $section_id,
				'settings' 	        => 'patiotime_link_light_scheme_hover_color',
				'choices'           => array(
					'primary' => esc_html__( 'Primary Color', 'patiotime' ),
					'secondary'  => esc_html__( 'Secondary Color', 'patiotime' ),
					'custom'  => esc_html__( 'Custom Color', 'patiotime' )
				)
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_link_light_scheme_custom_hover_color', array(
				'section' 			=> $section_id,
				'settings'			=> 'patiotime_link_light_scheme_custom_hover_color',
				'active_callback'	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_link_dark_scheme_regular_color', array(
				'type'              => 'select',
				'label'             => esc_html__( 'Regular - Dark Scheme', 'patiotime' ),
				'section'           => $section_id,
				'settings' 	        => 'patiotime_link_dark_scheme_regular_color',
				'choices'           => array(
					'primary' => esc_html__( 'Primary Color', 'patiotime' ),
					'secondary'  => esc_html__( 'Secondary Color', 'patiotime' ),
					'custom'  => esc_html__( 'Custom Color', 'patiotime' )
				)
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_link_dark_scheme_custom_regular_color', array(
				'section' 			=> $section_id,
				'settings'			=> 'patiotime_link_dark_scheme_custom_regular_color',
				'active_callback'	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_link_dark_scheme_hover_color', array(
				'type'              => 'select',
				'label'             => esc_html__( 'Hover - Dark Scheme', 'patiotime' ),
				'section'           => $section_id,
				'settings' 	        => 'patiotime_link_dark_scheme_hover_color',
				'choices'           => array(
					'primary' => esc_html__( 'Primary Color', 'patiotime' ),
					'secondary'  => esc_html__( 'Secondary Color', 'patiotime' ),
					'custom'  => esc_html__( 'Custom Color', 'patiotime' )
				)
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_link_dark_scheme_custom_hover_color', array(
				'section' 			=> $section_id,
				'settings'			=> 'patiotime_link_dark_scheme_custom_hover_color',
				'active_callback'	=> array( $this, 'customize_control_active_cb' )
			) ) );
		}
		/**
		* Register section button styles
		*/
		protected function add_section_button_styles( $wp_customize ) {
			$defaults = $this->defaults;
			$this->section_priority += 5;
			$section_id = 'patiotime_button_styles';
			$wp_customize->add_section( $section_id, array(
				'title'		=> esc_html__( 'Buttons', 'patiotime' ),
				'panel' 	=> $this->panel_id,
				'priority'	=> $this->section_priority
			) );

			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_button_shape', array(
				'default'   		=> $defaults['patiotime_button_shape'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_button_colors_group_title', array(
				'default'   		=> '',
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_empty'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_button_background_color', array(
				'default'   		=> $defaults['patiotime_button_background_color'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_button_custom_background_color', array(
				'default'   		=> $defaults['patiotime_button_custom_background_color'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color',
				'dependency' 		=> array( 'patiotime_button_background_color' => array( 'value' => array( 'custom' ) ) )
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_button_text_color', array(
				'default'   		=> $defaults['patiotime_button_text_color'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_button_hover_background_color', array(
				'default'   		=> $defaults['patiotime_button_hover_background_color'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_button_hover_custom_background_color', array(
				'default'   		=> $defaults['patiotime_button_hover_custom_background_color'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color',
				'dependency' 		=> array( 'patiotime_button_hover_background_color' => array( 'value' => array( 'custom' ) ) )
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_button_hover_text_color', array(
				'default'   		=> $defaults['patiotime_button_hover_text_color'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_button_colors_notes', array(
				'default'   		=> '',
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_empty'
			) ) );

			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_button_shape', array(
				'type' 				=> 'select',
				'label' 			=> esc_html__( 'Default Button Shape', 'patiotime' ),
				'section' 			=> $section_id,
				'settings' 			=> 'patiotime_button_shape',
				'choices'			=> array(
					'' => esc_html__( 'Square', 'patiotime' ),
					'pt-btn-rounded' => esc_html__( 'Rounded', 'patiotime' ),
					'pt-btn-pill' => esc_html__( 'Pill', 'patiotime' )
				)
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_button_colors_group_title', array(
				'type' 		=> 'title_only',
				'label' 	=> esc_html__( 'Default Button Colors', 'patiotime' ),
				'section' 	=> $section_id,
				'settings' 	=> 'patiotime_button_colors_group_title'
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_button_background_color', array(
				'type'              => 'select',
				'label'             => esc_html__( 'Background Color', 'patiotime' ),
				'section'           => $section_id,
				'settings' 	        => 'patiotime_button_background_color',
				'choices'           => array(
					'primary' => esc_html__( 'Primary Color', 'patiotime' ),
					'secondary'  => esc_html__( 'Secondary Color', 'patiotime' ),
					'custom'  => esc_html__( 'Custom Color', 'patiotime' )
				)
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_button_custom_background_color', array(
				'section' 			=> $section_id,
				'settings'			=> 'patiotime_button_custom_background_color',
				'active_callback'	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_button_text_color', array(
				'section' 	=> $section_id,
				'label'		=> esc_html__( 'Text Color', 'patiotime' ),
				'settings'	=> 'patiotime_button_text_color'
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_button_hover_background_color', array(
				'type'              => 'select',
				'label'             => esc_html__( 'Hover Background Color', 'patiotime' ),
				'section'           => $section_id,
				'settings' 	        => 'patiotime_button_hover_background_color',
				'choices'           => array(
					'primary' => esc_html__( 'Primary Color', 'patiotime' ),
					'secondary'  => esc_html__( 'Secondary Color', 'patiotime' ),
					'custom'  => esc_html__( 'Custom Color', 'patiotime' )
				)
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_button_hover_custom_background_color', array(
				'section' 			=> $section_id,
				'settings'			=> 'patiotime_button_hover_custom_background_color',
				'active_callback'	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_button_hover_text_color', array(
				'section' 	=> $section_id,
				'label'		=> esc_html__( 'Hover Text Color', 'patiotime' ),
				'settings'	=> 'patiotime_button_hover_text_color'
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_button_colors_notes', array(
				'type' 		=> 'notes',
				'section' 	=> $section_id,
				'settings' 	=> 'patiotime_button_colors_group_title',
				'description' => esc_html__( 'When editing a button in Elementor, if you select "Default" for "Button Color", the button will use the colors you set here. These colors can be overwritten when editing each specific button.', 'patiotime' ),
			) ) );
		}
		/**
		* Register section form
		*/
		protected function add_section_form_styles( $wp_customize ) {
			$defaults = $this->defaults;
			$this->section_priority += 5;
			$section_id = 'patiotime_form_styles';
			$wp_customize->add_section( $section_id, array(
				'title'		=> esc_html__( 'Forms', 'patiotime' ),
				'panel' 	=> $this->panel_id,
				'priority'	=> $this->section_priority
			) );

			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_form_field_style', array(
				'default'   		=> $defaults['patiotime_form_field_style'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_form_border_width', array(
				'default'   		=> $defaults['patiotime_form_border_width'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'sanitize_text_field'
			) ) );

			$wp_customize->add_control ( new PatioTime_Customize_Control( $wp_customize, 'patiotime_form_field_style', array(
				'type' 		=> 'select',
				'label' 	=> esc_html__( 'Form Field Style', 'patiotime' ),
				'section' 	=> $section_id,
				'settings' 	=> 'patiotime_form_field_style',
				'choices' 	=> array(
					'pt-form-underline' => esc_html__( 'Underlined', 'patiotime' ),
					'pt-form-square' => esc_html__( 'Square', 'patiotime' ),
					'pt-form-rounded' => esc_html__( 'Rounded', 'patiotime' ),
					'pt-form-pill' => esc_html__( 'Pill', 'patiotime' ),
				)
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_form_border_width', array(
				'type' 			=> 'number_with_unit',
				'label' 		=> esc_html__( 'Border Width', 'patiotime' ),
				'after_text' 	=> 'px',
				'input_attrs'	=> array( 'min' => 1, 'max' => 10 ),
				'section' 		=> $section_id,
				'settings' 		=> 'patiotime_form_border_width'
			) ) );
		}
	}
	new PatioTime_Customize_Colors_Styles();
}
