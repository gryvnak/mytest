<?php
/**
* Customize section page title configuration files.
*/


if ( ! class_exists( 'PatioTime_Customize_Page_Title' ) ) {
	class PatioTime_Customize_Page_Title extends PatioTime_Customize_Configuration_Base {
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			global $patiotime_default_settings;
			$section_id = 'patiotime_section_page_title';
			$wp_customize->add_section( $section_id, array(
				'title' 	=> esc_html__( 'Page Title', 'patiotime' ),
				'priority' 	=> 60
			) );

			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_page_title_notes', array(
				'default'   		=> '',
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_empty'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_page_title_section_size', array(
				'default'   		=> $patiotime_default_settings[ 'patiotime_page_title_section_size' ],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_page_title_enable_custom_margin_top', array(
				'default'   		=> $patiotime_default_settings['patiotime_page_title_enable_custom_margin_top'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_page_title_custom_desktop_margin_top', array(
				'default'			=> $patiotime_default_settings['patiotime_page_title_custom_desktop_margin_top'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'absint',
				'dependency'		=> array(
					'patiotime_page_title_enable_custom_margin_top' => array( 'value' => array( 'on' ) )
				)
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_page_title_custom_tablet_margin_top', array(
				'default'			=> $patiotime_default_settings['patiotime_page_title_custom_tablet_margin_top'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'absint',
				'dependency'		=> array(
					'patiotime_page_title_enable_custom_margin_top' => array( 'value' => array( 'on' ) )
				)
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_page_title_custom_mobile_margin_top', array(
				'default'			=> $patiotime_default_settings['patiotime_page_title_custom_mobile_margin_top'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'absint',
				'dependency'		=> array(
					'patiotime_page_title_enable_custom_margin_top' => array( 'value' => array( 'on' ) )
				)
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_page_title_default_background_color', array(
				'default'			=> $patiotime_default_settings['patiotime_page_title_default_background_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_page_title_default_background_image', array(
				'default'			=> $patiotime_default_settings['patiotime_page_title_default_background_image'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'absint'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_page_title_default_background_size', array(
				'default'			=> $patiotime_default_settings['patiotime_page_title_default_background_size'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_choice',
				'dependency' 		=> array( 'patiotime_page_title_default_background_image' => array( 'value' => array( '', 0, '0' ), 'operator' => 'not in' ) )
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_page_title_default_background_repeat', array(
				'default'   		=> $patiotime_default_settings['patiotime_page_title_default_background_repeat'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_checkbox',
				'dependency' 		=> array( 'patiotime_page_title_default_background_image' => array( 'value' => array( '', 0, '0' ), 'operator' => 'not in' ) )
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_page_title_default_background_position_x', array(
				'default'			=> $patiotime_default_settings['patiotime_page_title_default_background_position_x'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_text_field',
				'dependency' 		=> array( 'patiotime_page_title_default_background_image' => array( 'value' => array( '', 0, '0' ), 'operator' => 'not in' ) )
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_page_title_default_background_position_y', array(
				'default'  			=> $patiotime_default_settings['patiotime_page_title_default_background_position_y'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'sanitize_text_field',
				'dependency' 		=> array( 'patiotime_page_title_default_background_image' => array( 'value' => array( '', 0, '0' ), 'operator' => 'not in' ) )
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_page_title_default_background_attachment', array(
				'default'			=> $patiotime_default_settings['patiotime_page_title_default_background_attachment'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_checkbox',
				'dependency' 		=> array( 'patiotime_page_title_default_background_image' => array( 'value' => array( '', 0, '0' ), 'operator' => 'not in' ) )
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_page_title_default_text_color', array(
				'default'			=> $patiotime_default_settings['patiotime_page_title_default_text_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_page_title_show_breadcrumb', array(
				'default'   		=> $patiotime_default_settings['patiotime_page_title_show_breadcrumb'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_checkbox'
			) ) );

			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_page_title_notes', array(
				'type'          => 'notes',
				'description'	=> esc_html__( 'These settings control the default styles for all page title sections, including single pages, blog page & archive pages, and shop pages.', 'patiotime' ),
				'section' 	    => $section_id,
				'settings' 	    => 'patiotime_page_title_notes'
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_page_title_section_size', array(
				'type' 				=> 'select',
				'label' 			=> esc_html__( 'Section Size', 'patiotime' ),
				'section' 			=> $section_id,
				'settings' 			=> 'patiotime_page_title_section_size',
				'choices' 			=> array(
					'page-title-small' => esc_html__( 'Small', 'patiotime' ),
					'page-title-default' => esc_html__( 'Medium', 'patiotime' ),
					'page-title-large' => esc_html__( 'Large', 'patiotime' )
				)
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_page_title_enable_custom_margin_top', array(
				'type'          => 'checkbox',
				'label_first'   => true,
				'label'         => esc_html__( 'Adjust Top Distance Below Overlap Site Header', 'patiotime' ),
				'section' 	    => $section_id,
				'settings' 	    => 'patiotime_page_title_enable_custom_margin_top'
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_page_title_custom_desktop_margin_top', array(
				'type' 				=> 'number_with_unit',
				'label' 			=> esc_html__( 'For Desktop View', 'patiotime' ),
				'description'		=> esc_html__( 'For screen width >= 1025px', 'patiotime' ),
				'after_text' 		=> 'px',
				'section' 			=> $section_id,
				'settings' 			=> 'patiotime_page_title_custom_desktop_margin_top',
				'active_callback' 	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_page_title_custom_tablet_margin_top', array(
				'type' 				=> 'number_with_unit',
				'label' 			=> esc_html__( 'For Tablet View', 'patiotime' ),
				'description'		=> esc_html__( 'For screen width >= 768px and <=1024px', 'patiotime' ),
				'after_text' 		=> 'px',
				'section' 			=> $section_id,
				'settings' 			=> 'patiotime_page_title_custom_tablet_margin_top',
				'active_callback' 	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_page_title_custom_mobile_margin_top', array(
				'type' 				=> 'number_with_unit',
				'label' 			=> esc_html__( 'For Mobile View', 'patiotime' ),
				'description'		=> esc_html__( 'For screen width <= 767px', 'patiotime' ),
				'after_text' 		=> 'px',
				'section' 			=> $section_id,
				'settings' 			=> 'patiotime_page_title_custom_mobile_margin_top',
				'active_callback' 	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_page_title_default_background_color', array(
				'label'		=> esc_html__( 'Default Background Color', 'patiotime' ),
				'section' 	=> $section_id,
				'settings'	=> 'patiotime_page_title_default_background_color'
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_page_title_default_background_image', array(
				'type'		=> 'image_id',
				'label'		=> esc_html__( 'Default Background Image', 'patiotime' ),
				'section'	=> $section_id,
				'settings'	=> 'patiotime_page_title_default_background_image'
			) ) );
			$wp_customize->add_control( new WP_Customize_Background_Position_Control( $wp_customize, 'patiotime_page_title_default_background_position', array(
				'label' 			=> esc_html__( 'Image Position', 'patiotime' ),
				'section'			=> $section_id,
				'active_callback' 	=> array( $this, 'customize_control_active_cb' ),
				'settings' 			=> array(
					'x' => 'patiotime_page_title_default_background_position_x',
					'y' => 'patiotime_page_title_default_background_position_y'
				)
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_page_title_default_background_size', array(
				'type' 				=> 'select',
				'label' 			=> esc_html__( 'Size', 'patiotime' ),
				'section' 			=> $section_id,
				'settings' 			=> 'patiotime_page_title_default_background_size',
				'active_callback' 	=> array( $this, 'customize_control_active_cb' ),
				'choices' 			=> array(
					'auto' 		=> esc_html__( 'Original', 'patiotime' ),
					'contain' 	=> esc_html__( 'Fit to Screen', 'patiotime' ),
					'cover'		=> esc_html__( 'Fill Screen', 'patiotime' )
				)
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_page_title_default_background_repeat', array(
				'type' 				=> 'checkbox',
				'label' 			=> esc_html__( 'Repeat', 'patiotime' ),
				'section' 			=> $section_id,
				'settings' 			=> 'patiotime_page_title_default_background_repeat',
				'active_callback' 	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_page_title_default_background_attachment', array(
				'type' 				=> 'checkbox',
				'label' 			=> esc_html__( 'Scroll with Page', 'patiotime' ),
				'section' 			=> $section_id,
				'settings'			=> 'patiotime_page_title_default_background_attachment',
				'active_callback' 	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_page_title_default_text_color', array(
				'label'		=> esc_html__( 'Default Text Color', 'patiotime' ),
				'section' 	=> $section_id,
				'settings'	=> 'patiotime_page_title_default_text_color'
			) ) );
			if ( patiotime_is_yoast_seo_activated() ) {
				$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_page_title_show_breadcrumb', array(
					'type'          => 'checkbox',
					'label_first'   => true,
					'label'         => esc_html__( 'Display Yoast SEO Breadcrumb', 'patiotime' ),
					'description'	=> sprintf(
						// translators: 1/2. html tag
						esc_html__( 'To display Yoast SEO Breadcrumb on Single Posts, please go to %1$sBlog > Single Post%2$s  to enable it.', 'patiotime' ),
						'<a href="#" class="show-control" data-control-id="patiotime_blog_single_post_show_yoast_seo_breadcrumb">',
						'</a>'
					),
					'section' 	    => $section_id,
					'settings' 	    => 'patiotime_page_title_show_breadcrumb'
				) ) );
			}
		}
	}
	new PatioTime_Customize_Page_Title();
}
