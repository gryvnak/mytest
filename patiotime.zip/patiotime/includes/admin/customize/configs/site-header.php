<?php
/**
* Customize section header configuration files.
*/

if ( ! class_exists( 'PatioTime_Customize_Site_Header' ) ) {
	class PatioTime_Customize_Site_Header extends PatioTime_Customize_Configuration_Base {
		/**
		* String panel id
		*/
		public $panel_id = 'patiotime_panel_site_header';
		/**
		* Array default customize option values
		*/
		public $defaults = array();
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			global $patiotime_default_settings;
			$this->defaults = $patiotime_default_settings;

			$this->add_panel( $wp_customize );
			$this->add_section_header( $wp_customize );
			$this->add_section_mobile_menu( $wp_customize );

			$header_image_section = $wp_customize->get_section( 'header_image' );
			if ( ! empty( $header_image_section ) && ( $header_image_section instanceof WP_Customize_Section ) ) {
				$header_image_section->panel = $this->panel_id;
				$header_image_section->priority = 20;
			}
		}
		/**
		* Register panel
		*/
		protected function add_panel( $wp_customize ) {
			$wp_customize->add_panel( $this->panel_id, array(
				'title'    => esc_html__( 'Site Header', 'patiotime' ),
				'priority' => 10
			) );
		}
		/**
		* Register section general
		*/
		protected function add_section_header( $wp_customize ) {
			$defaults = $this->defaults;
			$section_id = 'patiotime_site_header_section_general';
			$show_custom_block = patiotime_is_theme_core_activated();

			$wp_customize->add_section( $section_id, array(
				'title'	=> esc_html__( 'Header', 'patiotime' ),
				'panel' => $this->panel_id,
				'priority' => 10
			) );

			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_sticky_site_header', array(
				'default'			=> $defaults['patiotime_sticky_site_header'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_choice'
			) ) );

			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_site_header', array(
				'default'   		=> $defaults['patiotime_site_header'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_default_site_header_enable_overlap', array(
				'default'   		=> $defaults['patiotime_default_site_header_enable_overlap'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_checkbox',
				'dependency' 		=> array( 'patiotime_site_header' => array( 'value' => array( '' ) ) )
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_default_site_header_hide_top_bar', array(
				'default'   		=> $defaults['patiotime_default_site_header_hide_top_bar'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_checkbox',
				'dependency' 		=> array( 'patiotime_site_header' => array( 'value' => array( '' ) ) )
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_default_site_header_hide_search_icon', array(
				'default'   		=> $defaults['patiotime_default_site_header_hide_search_icon'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_checkbox',
				'dependency' 		=> array( 'patiotime_site_header' => array( 'value' => array( '' ) ) )
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_default_site_header_hide_cart', array(
				'default'   		=> $defaults['patiotime_default_site_header_hide_cart'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_checkbox',
				'dependency' 		=> array( 'patiotime_site_header' => array( 'value' => array( '' ) ) )
			) ) );

			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_site_header_main_custom_block', array(
				'default'   		=> $defaults['patiotime_site_header_main_custom_block'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'absint',
				'dependency' 		=> array( 'patiotime_site_header' => array( 'value' => array( 'custom' ) ) )
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_sticky_site_header_custom_block', array(
				'default'   		=> $defaults['patiotime_sticky_site_header_custom_block'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'absint',
				'dependency' 		=> array(
					'patiotime_site_header' => array( 'value' => array( 'custom' ) ),
					'patiotime_sticky_site_header' => array( 'value' => array( 'always-enable', 'scroll-up-enable' ) )
				)
			) ) );

			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_sticky_site_header', array(
				'type' 		=> 'select',
				'label' 	=> esc_html__( 'Sticky Header', 'patiotime' ),
				'section' 	=> $section_id,
				'settings' 	=> 'patiotime_sticky_site_header',
				'choices' 	=> array(
					'disable'			=> esc_html__( 'No', 'patiotime' ),
					'always-enable'		=> esc_html__( 'Always sticky', 'patiotime' ),
					'scroll-up-enable'	=> esc_html__( 'Sticky when scroll up', 'patiotime' )
				)
			) ) );

			if ( $show_custom_block ) {
				$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_site_header', array(
					'type' 		=> 'select',
					'label' 	=> esc_html__( 'Site Header', 'patiotime' ),
					'section' 	=> $section_id,
					'settings' 	=> 'patiotime_site_header',
					'choices' 	=> array(
						'' => esc_html__( 'Default', 'patiotime' ),
						'custom' => esc_html__( 'Custom', 'patiotime' )
					)
				) ) );
				$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_default_site_header_enable_overlap', array(
					'type' 				=> 'checkbox',
					'label_first'		=> true,
					'label' 			=> esc_html__( 'Enable Overlap Header', 'patiotime' ),
					'section' 			=> $section_id,
					'settings' 			=> 'patiotime_default_site_header_enable_overlap',
					'active_callback' 	=> array( $this, 'customize_control_active_cb' )
				) ) );
				$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_default_site_header_hide_top_bar', array(
					'type' 				=> 'checkbox',
					'label_first'		=> true,
					'label' 			=> esc_html__( 'Hide Top Bar', 'patiotime' ),
					'section' 			=> $section_id,
					'settings' 			=> 'patiotime_default_site_header_hide_top_bar',
					'active_callback' 	=> array( $this, 'customize_control_active_cb' )
				) ) );
				$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_default_site_header_hide_search_icon', array(
					'type' 				=> 'checkbox',
					'label_first'		=> true,
					'label' 			=> esc_html__( 'Hide Search Icon', 'patiotime' ),
					'section' 			=> $section_id,
					'settings' 			=> 'patiotime_default_site_header_hide_search_icon',
					'active_callback' 	=> array( $this, 'customize_control_active_cb' )
				) ) );
				$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_default_site_header_hide_cart', array(
					'type' 				=> 'checkbox',
					'label_first'		=> true,
					'label' 			=> esc_html__( 'Hide Mini Cart', 'patiotime' ),
					'section' 			=> $section_id,
					'settings' 			=> 'patiotime_default_site_header_hide_cart',
					'active_callback' 	=> array( $this, 'customize_control_active_cb' )
				) ) );

				$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_site_header_main_custom_block', array(
					'type' 		=> 'select',
					'label' 	=> esc_html__( 'Select a Custom Site Header', 'patiotime' ),
					'section' 	=> $section_id,
					'settings' 	=> 'patiotime_site_header_main_custom_block',
					'choices' 	=> patiotime_get_custom_post_type( 'custom_site_headers' ),
					'active_callback'	=> array( $this, 'customize_control_active_cb' ),
					'description' => sprintf(
						// translators: 1/2. html tag
						esc_html__( 'If there is no option in the dropdown list, please click %1$shere%2$s to create your own site header first.', 'patiotime' ),
						sprintf( '<a href="%s" target="_blank">', admin_url( 'edit.php?post_type=custom_site_headers' ) ),
						'</a>'
					)
				) ) );
				$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_sticky_site_header_custom_block', array(
					'type' 		=> 'select',
					'label' 	=> esc_html__( 'Select Sticky Header', 'patiotime' ),
					'section' 	=> $section_id,
					'settings' 	=> 'patiotime_sticky_site_header_custom_block',
					'choices'	=> patiotime_get_custom_post_type( 'custom_site_headers' ),
					'active_callback' => array( $this, 'customize_control_active_cb' ),
					'description' => esc_html__( 'You can choose another custom site header as the sticky header', 'patiotime' )
				) ) );
			} else {
				$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_default_site_header_enable_overlap', array(
					'type' 			=> 'checkbox',
					'label_first'	=> true,
					'label' 		=> esc_html__( 'Enable Overlap Header', 'patiotime' ),
					'section' 		=> $section_id,
					'settings' 		=> 'patiotime_default_site_header_enable_overlap'
				) ) );
				$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_default_site_header_hide_top_bar', array(
					'type' 			=> 'checkbox',
					'label_first'	=> true,
					'label' 		=> esc_html__( 'Hide Top Bar', 'patiotime' ),
					'section' 		=> $section_id,
					'settings' 		=> 'patiotime_default_site_header_hide_top_bar'
				) ) );
				$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_default_site_header_hide_search_icon', array(
					'type' 			=> 'checkbox',
					'label_first'	=> true,
					'label' 		=> esc_html__( 'Hide Search Icon', 'patiotime' ),
					'section' 		=> $section_id,
					'settings' 		=> 'patiotime_default_site_header_hide_search_icon'
				) ) );
				$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_default_site_header_hide_cart', array(
					'type' 			=> 'checkbox',
					'label_first'	=> true,
					'label' 		=> esc_html__( 'Hide Mini Cart', 'patiotime' ),
					'section' 		=> $section_id,
					'settings' 		=> 'patiotime_default_site_header_hide_cart'
				) ) );
			}
		}
		/**
		* Register section fullscreen/mobile menu
		*/
		protected function add_section_mobile_menu( $wp_customize ) {
			$defaults = $this->defaults;
			$section_id = 'patiotime_site_header_section_mobile_menu';

			$wp_customize->add_section( $section_id, array(
				'title'	=> esc_html__( 'Fullscreen/Mobile Menu', 'patiotime' ),
				'panel' => $this->panel_id,
				'priority' => 30
			) );

			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_mobile_site_header_notes', array(
				'default'   		=> '',
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_empty'
			) ) );

			if ( patiotime_is_theme_core_activated() ) {
				$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'patiotime_mobile_site_header_menu', array(
					'default'   		=> $defaults[ 'patiotime_mobile_site_header_menu' ],
					'transport' 		=> 'postMessage',
					'sanitize_callback' => 'absint'
				) ) );
				$wp_customize->selective_refresh->add_partial( 'patiotime_mobile_menu_content', array(
					'settings' 				=> array( 'patiotime_mobile_site_header_menu' ),
					'selector' 				=> '.sidemenu',
					'render_callback' 		=> array( $this, 'get_mobile_menu' ),
					'container_inclusive' 	=> true,
				) );
				$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_mobile_site_header_copyright_text', array(
					'default'   		=> $defaults['patiotime_mobile_site_header_copyright_text'],
					'transport' 		=> 'postMessage',
					'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_html',
					'dependency'		=> array( 'patiotime_mobile_site_header_menu' => array( 'value' => array( '0' ) ) )
				) ) );
			} else {
				$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_mobile_site_header_copyright_text', array(
					'default'   		=> $defaults['patiotime_mobile_site_header_copyright_text'],
					'transport' 		=> 'postMessage',
					'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_html'
				) ) );
			}
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_mobile_site_header_background_color', array(
				'default'   		=> $defaults[ 'patiotime_mobile_site_header_background_color' ],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_mobile_site_header_background_image', array(
				'default'   		=> $defaults[ 'patiotime_mobile_site_header_background_image' ],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'absint'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_mobile_site_header_text_color', array(
				'default'   		=> $defaults[ 'patiotime_mobile_site_header_text_color' ],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );

			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_mobile_site_header_entrance_animation', array(
				'default'			=> $defaults[ 'patiotime_mobile_site_header_entrance_animation' ],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_mobile_site_header_width', array(
				'default'			=> $defaults[ 'patiotime_mobile_site_header_width' ],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'PatioTime_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new PatioTime_Customize_Setting( $wp_customize, 'patiotime_mobile_site_header_custom_width', array(
				'default'			=> $defaults[ 'patiotime_mobile_site_header_custom_width' ],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'absint',
				'dependency' => array(
					'patiotime_mobile_site_header_width' => array( 'value' => array( 'custom-width' ) )
				)
			) ) );

			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_mobile_site_header_notes', array(
				'type' 		=> 'notes',
				'section' 	=> $section_id,
				'settings' 	=> 'patiotime_mobile_site_header_notes',
				'description' => esc_html__( 'Click the hamburger menu button to preview.', 'patiotime' )
			) ) );

			if ( patiotime_is_theme_core_activated() ) {
				$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_mobile_site_header_menu', array(
					'type' 		=> 'select',
					'label' 	=> esc_html__( 'Select Fullscreen/Mobile Menu', 'patiotime' ),
					'section' 	=> $section_id,
					'settings' 	=> 'patiotime_mobile_site_header_menu',
					'choices' 	=> patiotime_get_custom_post_type( 'custom_blocks' ),
					'description' => sprintf(
						// translators: 1/2. html tag
						esc_html__( 'If there is no option in the dropdown list, please click %1$shere%2$s to create your own custom blocks first.', 'patiotime' ),
						sprintf( '<a href="%s" target="_blank">', admin_url( 'edit.php?post_type=custom_blocks' ) ),
						'</a>'
					)
				) ) );
				$wp_customize->add_control ( new PatioTime_Customize_Control( $wp_customize, 'patiotime_mobile_site_header_copyright_text', array(
					'type' 		=> 'textarea',
					'label' 	=> esc_html__( 'Copyright Text', 'patiotime' ),
					'section' 	=> $section_id,
					'settings' 	=> 'patiotime_mobile_site_header_copyright_text',
					'active_callback' => array( $this, 'customize_control_active_cb' )
				) ) );
			} else {
				$wp_customize->add_control ( new PatioTime_Customize_Control( $wp_customize, 'patiotime_mobile_site_header_copyright_text', array(
					'type' 		=> 'textarea',
					'label' 	=> esc_html__( 'Copyright Text', 'patiotime' ),
					'section' 	=> $section_id,
					'settings' 	=> 'patiotime_mobile_site_header_copyright_text'
				) ) );
			}
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_mobile_site_header_background_color', array(
				'label'		=> esc_html__( 'Background Color', 'patiotime' ),
				'section' 	=> $section_id,
				'settings'	=> 'patiotime_mobile_site_header_background_color'
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_mobile_site_header_background_image', array(
				'type'		=> 'image_id',
				'label'		=> esc_html__( 'Background Image', 'patiotime' ),
				'section'	=> $section_id,
				'settings'	=> 'patiotime_mobile_site_header_background_image'
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'patiotime_mobile_site_header_text_color', array(
				'label'		=> esc_html__( 'Text Color', 'patiotime' ),
				'section' 	=> $section_id,
				'settings'	=> 'patiotime_mobile_site_header_text_color'
			) ) );

			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_mobile_site_header_entrance_animation', array(
				'type' 		=> 'select',
				'label' 	=> esc_html__( 'Entrance Animation', 'patiotime' ),
				'section' 	=> $section_id,
				'settings' 	=> 'patiotime_mobile_site_header_entrance_animation',
				'choices' 	=> array(
					'' => esc_html__( 'Slide From Right', 'patiotime' ),
					'slide-from-left' => esc_html__( 'Slide From Left', 'patiotime' ),
					'fade-in' => esc_html__( 'Fade In', 'patiotime' )
				)
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_mobile_site_header_width', array(
				'type' 		=> 'select',
				'label' 	=> esc_html__( 'Width', 'patiotime' ),
				'section' 	=> $section_id,
				'settings' 	=> 'patiotime_mobile_site_header_width',
				'choices' 	=> array(
					'' => esc_html__( 'Default', 'patiotime' ),
					'fullwidth'	=> esc_html__( 'Fit to Screen', 'patiotime' ),
					'custom-width' => esc_html__( 'Custom', 'patiotime' )
				)
			) ) );
			$wp_customize->add_control( new PatioTime_Customize_Control( $wp_customize, 'patiotime_mobile_site_header_custom_width', array(
				'type' 		=> 'number_with_unit',
				'label' 	=> esc_html__( 'Custom Width', 'patiotime' ),
				'after_text' => esc_html__( 'px', 'patiotime' ),
				'section' 	=> $section_id,
				'settings' 	=> 'patiotime_mobile_site_header_custom_width',
				'active_callback'	=> array( $this, 'customize_control_active_cb' )
			) ) );
		}
		/**
		* Mobile menu content
		*/
		public function get_mobile_menu() {
			if ( ! function_exists( 'patiotime_the_background_image_attrs' ) ) {
				$inc_dir = PATIOTIME_THEME_INC;
				require_once $inc_dir . 'front/functions-template.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
				require_once $inc_dir . 'front/class-walker-menu.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			} 
			PatioTime_Utils_Custom_Block::the_mobile_menu( array( 'class' => 'show' ) );
		}
	}
	new PatioTime_Customize_Site_Header();
}
