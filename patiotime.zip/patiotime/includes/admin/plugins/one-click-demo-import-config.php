<?php
function patiotime_ocdi_import_files () {
	$demos 		= array();
	$data_dir 	= trailingslashit( get_template_directory() ) . 'demo-data/';
	$data_uri 	= get_template_directory_uri() . '/demo-data/';
	$configs	= array(
		'PatioTime Main' => 'demo-1',
		'PatioTime Elegant' => 'demo-2',
		'PatioTime Bar' => 'demo-3',
		'PatioTime Bistro' => 'demo-4',
		'PatioTime Coffee' => 'demo-5',
		'PatioTime Casual Cafe' => 'demo-6',
		'PatioTime Seafood' => 'demo-7',
		'PatioTime Sushi' => 'demo-8',
		'PatioTime Steakhouse' => 'demo-9',
		'PatioTime Pastry' => 'demo-10',
		'PatioTime Afternoon Tea' => 'demo-11',
		'PatioTime Fine Dining' => 'demo-12'
	);
	foreach( $configs as $name => $path ) {
		$content 	= $data_dir . $path . '/content.xml';
		$widgets 	= $data_dir . $path . '/widgets.wie';
		$customize 	= $data_dir . $path . '/customizer.dat';
		// translators: %1$s: demo data root uri, %2$s: demo path
		$screenshot = sprintf( '%1$s%2$s/screenshot.jpg', $data_uri, $path );
		$demos[] = array(
			'import_file_name'             => $name,
			'local_import_file'            => $content,
			'local_import_widget_file'     => $widgets,
			'import_preview_image_url'     => $screenshot,
			'local_import_customizer_file' => $customize
		);
	}
	return $demos;
}
add_filter( 'pt-ocdi/import_files', 'patiotime_ocdi_import_files' );


function patiotime_ocdi_after_import_setup( $selected_import ) {
	// Assign menus to their locations.
	$main_menu 		= get_term_by( 'name', 'Main Menu', 'nav_menu' );
	$social_menu 	= get_term_by( 'name', 'Social Menu', 'nav_menu' );
	$footer_menu 	= in_array( $selected_import[ 'import_file_name' ], array( 'PatioTime Bistro', 'PatioTime Main', 'PatioTime Casual Cafe', 'PatioTime Steakhouse', 'PatioTime Fine Dining' ) )
		? get_term_by( 'name', 'Footer Menu', 'nav_menu' ) : get_term_by( 'name', 'Footer Menu 2', 'nav_menu' );

	set_theme_mod( 'nav_menu_locations', array(
		'primary-menu' 	=> empty( $main_menu ) ? '' : $main_menu->term_id,
		'social-menu' 	=> empty( $social_menu ) ? '' : $social_menu->term_id,
		'footer-menu'	=> empty( $footer_menu ) ? '' : $footer_menu->term_id
	) );

	$front_page = 'PatioTime Casual Cafe' == $selected_import[ 'import_file_name' ] ? get_page_by_path( 'home-casual-cafe' ) : get_page_by_path( 'home' );
	$blog_page = get_page_by_path( 'blog' );
	if ( $front_page || $blog_page ) {
		$no_blog_pages = array( 'PatioTime Coffee', 'PatioTime Seafood', 'PatioTime Sushi', 'PatioTime Steakhouse', 'PatioTime Pastry', 'PatioTime Fine Dining' );
		update_option( 'show_on_front', 'page' );
		$front_page ? update_option( 'page_on_front', $front_page->ID ) : '';
		$blog_page && ( ! in_array( $selected_import[ 'import_file_name' ], $no_blog_pages ) ) ? update_option( 'page_for_posts', $blog_page->ID ) : '';
	}


	if ( class_exists( 'WooCommerce' ) ) {
		switch( $selected_import[ 'import_file_name' ] ) {
			case 'PatioTime Pastry':
				$shop_page = get_page_by_path( 'shop-3' );
				$shop_page ? update_option( 'woocommerce_shop_page_id', $shop_page->ID ) : '';
				break;
			case 'PatioTime Bistro':
			case 'PatioTime Sushi':
				$shop_page = get_page_by_path( 'shop-2' );
				$shop_page ? update_option( 'woocommerce_shop_page_id', $shop_page->ID ) : '';
				break;
		}
	}
}
add_action('pt-ocdi/after_import', 'patiotime_ocdi_after_import_setup');
