<?php
if ( ! class_exists( 'PatioTime_Custom_Site_Header' ) ) {
    class PatioTime_Custom_Site_Header {
        /**
        * Array featured slider args base settings
        */
        protected $base_settings = array();
        /**
        * Construct function
        */
        public function __construct() {
            add_filter( 'patiotime_custom_styles', array( $this, 'custom_styles' ) );
        }
		/**
		* Generate custom styles
		*/
		public function custom_styles( $styles ) {
			global $patiotime_default_settings;
            $colors = array(
                'patiotime_mobile_site_header_background_color' => '.sidemenu .container { background-color: %s; }',
                'patiotime_mobile_site_header_text_color' => '.sidemenu .container { color: %s; }'
            );
            foreach( $colors as $id => $selector ) {
                $color = patiotime_get_theme_mod( $id );
                if ( ! empty( $color ) && isset( $patiotime_default_settings[ $id ] ) && ( $patiotime_default_settings[ $id ] != $color ) ) {
                    $styles[ $id ] = sprintf( $selector, $color );
                }
            }

            if ( 'custom-width' == patiotime_get_theme_mod( 'patiotime_mobile_site_header_width' ) ) {
                $custom = patiotime_get_theme_mod( 'patiotime_mobile_site_header_custom_width' );
                if ( $custom != $patiotime_default_settings[ 'patiotime_mobile_site_header_custom_width' ] ) {
                    $styles[ 'patiotime-site-header-mobile-custom-width' ] = sprintf(
                        '.sidemenu.custom-width { max-width: %spx; }',
                        absint( $custom )
                    );
                }
            }

            // Site header background image
            $background_image = patiotime_get_site_header_image();
            if ( ! empty( $background_image ) ) {
                $styles[ 'patiotime-site-header-background-image' ] = sprintf(
                    '.site-header { background-image: url(%s); }',
                    esc_url( $background_image )
                );
            }

			return $styles;
		}
    }
    new PatioTime_Custom_Site_Header();
}
