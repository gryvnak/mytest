<?php
if ( ! class_exists( 'PatioTime_Custom_General' ) ) {
    class PatioTime_Custom_General {
        /**
        * Construct function
        */
        public function __construct() {
            add_filter( 'patiotime_custom_styles', array( $this, 'custom_styles' ) );
            add_filter( 'patiotime_custom_style_vars', array( $this, 'custom_style_vars' ) );
        }
		/**
		* Generate custom style variables
		*/
		public function custom_style_vars( $vars ) {
            global $patiotime_default_settings;
            $root_vars = array();
            if ( 'custom' == patiotime_get_theme_mod( 'patiotime_page_content_width' ) ) {
    			$css_vars = array( '--custom-site-width' => 'patiotime_page_content_custom_width' );
    			foreach( $css_vars as $var => $id ) {
    				$root_vars[ $var ] = patiotime_get_theme_mod( $id ) . 'px';
    			}
            }

            if ( 'custom' == patiotime_get_theme_mod( 'patiotime_general_popup_box_size' ) ) {
                $custom_width = patiotime_get_theme_mod( 'patiotime_general_popup_box_custom_width' );
                $custom_width = absint( $custom_width );
                if ( $patiotime_default_settings[ 'patiotime_general_popup_box_custom_width' ] != $custom_width ) {
                    $root_vars[ '--popup-width' ] = $custom_width . 'px';
                }
            }
            if ( patiotime_is_valid_array( $root_vars ) ) {
                $vars[ ':root' ] = isset( $vars[ ':root' ] ) ? array_merge( $vars[ ':root' ], $root_vars ) : $root_vars;
            }

			return $vars;
        }
        /**
        * Generate custom styles
        */
        public function custom_styles( $styles ) {
            global $patiotime_default_settings;
            $colors = array(
                'patiotime_back_to_top_button_background_color' => '.to-top { background-color: %s; }',
                'patiotime_back_to_top_button_icon_color' => '.to-top { color: %s; }',
                'patiotime_back_to_top_button_hover_background_color' => '.no-touch .to-top.show:hover { background-color: %s; }',
                'patiotime_back_to_top_button_hover_icon_color' => '.no-touch .to-top.show:hover { color: %s; }',
                'patiotime_general_popup_box_background_color' => '.pt-popup.pt-popup-box.pt-site-popup { background-color: %s; }'
            );
            foreach( $colors as $id => $selector ) {
                $color = patiotime_get_theme_mod( $id );
                if ( ! empty( $color ) && isset( $patiotime_default_settings[ $id ] ) && ( $patiotime_default_settings[ $id ] != $color ) ) {
                    $styles[ $id ] = sprintf( $selector, $color );
                }
            }
            $styles[ 'patiotime-onepage-menu' ] = '.patiotime-enable-onepage-menu-check .current-menu-item > a:before { display: none !important; }';

            return $styles;
        }
    }
    new PatioTime_Custom_General();
}
