<?php
if ( ! class_exists( 'PatioTime_Custom_Blog' ) ) {
    class PatioTime_Custom_Blog {
        /**
        * Construct function
        */
        public function __construct() {
            add_filter( 'patiotime_custom_style_vars', array( $this, 'custom_style_vars' ) );
        }
		/**
		* Generate custom style variables
		*/
		public function custom_style_vars( $vars ) {
			global $patiotime_default_settings;
            $single_page_vars = array();
			$css_vars = array(
                '--page-title-bg' => 'patiotime_blog_single_post_title_default_background_color',
                '--page-title-color' => 'patiotime_blog_single_post_title_default_text_color'
			);
			foreach( $css_vars as $var => $id ) {
				$custom_value = patiotime_get_theme_mod( $id );
				if ( $custom_value != $patiotime_default_settings[ $id ] ) {
					$single_page_vars[ $var ] = $custom_value;
				}
			}
            if ( patiotime_is_valid_array( $single_page_vars ) ) {
                $vars[ '.single #page' ] = isset( $vars[ '.single #page' ] ) ? array_merge( $vars[ '.single #page' ], $single_page_vars ) : $single_page_vars;
            }

			return $vars;
		}
    }
    new PatioTime_Custom_Blog();
}
