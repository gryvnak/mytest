<?php
if ( ! class_exists( 'PatioTime_Custom_Page_Title' ) ) {
    class PatioTime_Custom_Page_Title {
        /**
        * Construct function
        */
        public function __construct() {
            add_filter( 'patiotime_custom_style_vars', array( $this, 'custom_style_vars' ) );
            add_filter( 'patiotime_custom_styles', array( $this, 'custom_styles' ) );
        }
		/**
		* Generate custom style variables
		*/
		public function custom_style_vars( $vars ) {
			global $patiotime_default_settings;
            $page_vars = array();
			$css_vars = array(
                '--page-title-bg' => 'patiotime_page_title_default_background_color',
                '--page-title-color' => 'patiotime_page_title_default_text_color'
			);
			foreach( $css_vars as $var => $id ) {
				$custom_value = patiotime_get_theme_mod( $id );
				if ( $custom_value != $patiotime_default_settings[ $id ] ) {
					$page_vars[ $var ] = $custom_value;
				}
			}
            if ( patiotime_is_valid_array( $page_vars ) ) {
                $vars[ '#page' ] = isset( $vars[ '#page' ] ) ? array_merge( $vars[ '#page' ], $page_vars ) : $page_vars;
            }

			return $vars;
		}
        /**
        * Custom CSS
        */
        public function custom_styles( $css ) {
            if ( patiotime_module_enabled( 'patiotime_page_title_enable_custom_margin_top' ) ) {
                $custom_settings = array(
                    'patiotime_page_title_custom_desktop_margin_top' => '@media screen and (min-width: 1025px)',
                    'patiotime_page_title_custom_tablet_margin_top' => '@media screen and (max-width: 1024px) and (min-width: 768px)',
                    'patiotime_page_title_custom_mobile_margin_top' => '@media screen and (max-width: 767px)'
                );
                $selector = '.overlap-header ~ .site-content .page-title-section .container';
                foreach( $custom_settings as $setting => $prefix ) {
                    $custom_margin_top = apply_filters( $setting, patiotime_get_theme_mod( $setting ) );
                    if ( is_numeric( $custom_margin_top ) ) {
                        $css[ $setting ] = sprintf( '%1$s { %2$s { margin-top: %3$spx; } }', $prefix, $selector, $custom_margin_top );
                    }
                }
            }
            return $css;
        }
    }
    new PatioTime_Custom_Page_Title();
}
