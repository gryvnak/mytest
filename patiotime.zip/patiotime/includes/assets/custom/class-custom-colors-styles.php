<?php
if ( ! class_exists( 'PatioTime_Custom_Colors_Styles' ) ) {
    class PatioTime_Custom_Colors_Styles {
        /**
        * Construct function
        */
        public function __construct() {
            add_filter( 'patiotime_custom_style_vars', array( $this, 'custom_style_vars' ) );
        }
		/**
		* Generate custom style variables
		*/
		public function custom_style_vars( $vars ) {
			global $patiotime_default_settings;
            $root_vars = array();
			$css_vars = array(
				'--primary-color' => 'patiotime_general_primary_color',
                '--secondary-color' => 'patiotime_general_secondary_color',
				'--light-bg-color' => 'patiotime_general_light_scheme_background_color',
                '--light-text-color' => 'patiotime_general_light_scheme_text_color',
                '--light-content-color' => 'patiotime_general_light_scheme_content_color',
                '--dark-bg-color' => 'patiotime_general_dark_scheme_background_color',
                '--dark-text-color' => 'patiotime_general_dark_scheme_text_color',
                '--dark-content-color' => 'patiotime_general_dark_scheme_content_color',
                '--form-bd-width' => 'patiotime_form_border_width',
                '--btn-color' => 'patiotime_button_text_color',
                '--btn-color-hover' => 'patiotime_button_hover_text_color'
			);
			foreach( $css_vars as $var => $id ) {
				$custom_value = patiotime_get_theme_mod( $id );
				if ( $custom_value != $patiotime_default_settings[ $id ] ) {
					$root_vars[ $var ] = sprintf( ( '--form-bd-width' == $var ) ? '%spx' : '%s', $custom_value );
                    if ( '--primary-color' == $var ) {
                        $root_vars[ '--primary-color-semi' ] = patiotime_hex2rgba( $custom_value, '0.3' );
                    }
				}
			}

            $css_vars = array(
                '--light-link-color' => array( 'prefix' => 'patiotime_link_light_scheme_', 'color' => 'regular_color' ),
                '--dark-link-color' => array( 'prefix' => 'patiotime_link_dark_scheme_', 'color' => 'regular_color' ),
                '--light-link-color-hover' => array( 'prefix' => 'patiotime_link_light_scheme_', 'color' => 'hover_color' ),
                '--dark-link-color-hover' => array( 'prefix' => 'patiotime_link_dark_scheme_', 'color' => 'hover_color' ),
                '--btn-bg' => array( 'prefix' => 'patiotime_button_', 'color' => 'background_color' ),
                '--btn-bg-hover' => array( 'prefix' => 'patiotime_button_hover_', 'color' => 'background_color' ),
            );
            foreach ( $css_vars as $var => $attrs ) {
                $option = patiotime_get_theme_mod( $attrs['prefix'] . $attrs[ 'color' ] );
                if ( 'primary' != $option ) {
                    if ( 'secondary' == $option ) {
                        $root_vars[ $var ] = 'var(--secondary-color)';
                    } else {
                        $id = $attrs['prefix'] . 'custom_' . $attrs[ 'color' ];
                        $custom_color = patiotime_get_theme_mod( $id );
                        if ( $patiotime_default_settings[ $id ] = $custom_color ) {
                            $root_vars[ $var ] = $custom_color;
                        }
                    }
                }
            }
            if ( patiotime_is_valid_array( $root_vars ) ) {
                $vars[ ':root' ] = isset( $vars[ ':root' ] ) ? array_merge( $vars[ ':root' ], $root_vars ) : $root_vars;
            }

			return $vars;
		}
    }
    new PatioTime_Custom_Colors_Styles();
}
