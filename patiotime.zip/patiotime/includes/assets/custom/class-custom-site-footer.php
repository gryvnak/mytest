<?php
if ( ! class_exists( 'PatioTime_Custom_Site_Footer' ) ) {
    class PatioTime_Custom_Site_Footer {
        /**
        * Array featured slider args base settings
        */
        protected $base_settings = array();
        /**
        * Construct function
        */
        public function __construct() {
            add_filter( 'patiotime_custom_styles', array( $this, 'custom_styles' ) );
        }
		/**
		* Generate custom styles
		*/
		public function custom_styles( $styles ) {
			global $patiotime_default_settings;
            $colors = array(
                'patiotime_site_footer_bottom_background_color' => '.site-footer .site-footer-bottom { background-color: %s; }',
                'patiotime_site_footer_bottom_text_color' => '.site-footer .site-footer-bottom { color: %s; }'
            );
            foreach( $colors as $id => $selector ) {
                $color = patiotime_get_theme_mod( $id );
                if ( ! empty( $color ) && isset( $patiotime_default_settings[ $id ] ) && ( $patiotime_default_settings[ $id ] != $color ) ) {
                    $styles[ $id ] = sprintf( $selector, $color );
                }
            }

			return $styles;
		}
    }
    new PatioTime_Custom_Site_Footer();
}
