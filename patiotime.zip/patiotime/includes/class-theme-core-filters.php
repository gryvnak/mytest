<?php
if ( ! class_exists( 'PatioTime_Theme_Core_Filters' ) ) {
    class PatioTime_Theme_Core_Filters {
        /**
        * Construct function
        */
        public function __construct() {
            add_filter( 'loftocean_get_widget_title', array( $this, 'change_widget_title' ), 99, 2 );
            add_filter( 'loftocean_get_widget_class', array( $this, 'change_widget_class' ), 99, 2 );
            add_filter( 'loftocean_instagram_widget_class', array( $this, 'instagram_widget_class' ) );
            add_filter( 'loftocean_get_image_sizes', array( $this, 'get_image_sizes' ), 99, 2 );
            add_filter( 'loftocean_get_image_size', array( $this, 'get_image_size' ), 99, 2 );
            add_filter( 'loftocean_front_has_social_menu', array( $this, 'has_social_menu' ), 99, 1 );

            add_filter( 'loftocean_translate_page_options', array( $this, 'translate_pages' ) );
            add_filter( 'loftocean_translate_attachment_options', array( $this, 'translate_attachments' ) );
            add_filter( 'loftocean_translate_taxonomy', array( $this, 'translate_taxonomy' ) );
            add_filter( 'loftocean_translate_mc4wp_forms', array( $this, 'translate_mc4wp_form_settings' ) );
            add_filter( 'loftocean_translate_mc4wp_form',  array( $this, 'translate_mc4wp_form' ) );

			add_filter( 'loftocean_get_primary_color', array( $this, 'get_primary_color' ) );
            add_filter( 'loftocean_is_loading_post_meta_by_ajax', array( $this, 'load_post_metas_by_ajax' ) );
            add_filter( 'loftocean_front_post_list_args', array( $this, 'post_list_args' ), 99 );
            add_filter( 'loftocean_front_get_opening_hours', array( $this, 'get_opening_hours' ) );
            add_filter( 'loftocean_front_get_restaurant_info', array( $this, 'get_restaurant_info' ) );
            add_filter( 'dynamic_sidebar_params', array( $this, 'check_sidebar_params' ) );

    		add_filter( 'loftocean_enable_media_lazy_load', '__return_false', 1 );
    		add_filter( 'loftocean_disable_media_preload', '__return_true', 1 );

            add_filter( 'loftocean_elementor_category_title', array( $this, 'element_category_title' ) );
            add_filter( 'loftocean_elementor_widget_name', array( $this, 'change_elementor_widget_name' ), 10, 2 );

            add_filter( 'loftocean_elementor_days', array( $this, 'get_count_down_label_days' ) );
            add_filter( 'loftocean_elementor_hours', array( $this, 'get_count_down_label_hours' ) );
            add_filter( 'loftocean_elementor_minutes', array( $this, 'get_count_down_label_minutes' ) );
            add_filter( 'loftocean_elementor_seconds', array( $this, 'get_count_down_label_seconds' ) );

            add_filter( 'loftocean_elementor_editor_json', array( $this, 'elementor_editor_json' ) );

            add_action( 'loftocean_front_the_social_menu', array( $this, 'the_social_menu' ), 10, 1 );
            add_action( 'patiotime_image_loading_attributes', array( $this, 'image_loading_attributes' ) );
            add_action( 'loftocean_elementor_navigation_menu', array( $this, 'the_navigation_menu' ), 10, 2 );

            add_action( 'loftocean_elementor_loaded', array( $this, 'elementor_loaded' ) );
            add_action( 'patiotime_after_site_footer', array( $this, 'after_site_footer' ) );
        }
		/**
		* Get primary for gutenberg
		*/
		public function get_primary_color( $color ) {
			return patiotime_get_theme_mod( 'patiotime_primary_accent_color' );
		}
        /**
        * Condition function if have social menu
        * @param boolean
        * @return boolean
        */
        public function has_social_menu( $has ) {
            return patiotime_has_nav_menu( 'social-menu' );
        }
        /**
        * Output the social menu for widget profile
        * @param string
        */
        public function the_social_menu( $id ) {
            patiotime_social_menu( array(
                'container' => 'div',
                'container_class' => 'socialwidget',
                'menu_id' => $id . '-social-menu',
                'menu_class' => 'social-nav menu'
            ) );
        }
        /**
        * Change widget title
        */
        public function change_widget_title( $title, $args ) {
            if ( ! empty( $args ) && ! empty( $args['id' ] ) ) {
                switch ( $args['id'] ) {
                    case 'profile':
                        return esc_html__( 'PatioTime Profile', 'patiotime' );
                    case 'facebook':
                        return esc_html__( 'PatioTime Facebook', 'patiotime' );
                    case 'instagram':
                        return esc_html__( 'PatioTime Instagram', 'patiotime' );
                    case 'social':
                        return esc_html__( 'PatioTime Social', 'patiotime' );
                    case 'opening-hours':
                        return esc_html__( 'PatioTime Opening Hours', 'patiotime' );
                    case 'category':
                        return esc_html__( 'PatioTime Category', 'patiotime' );
                    case 'posts':
                        return esc_html__( 'PatioTime Posts', 'patiotime' );
                }
            }
            return $title;
        }
        /**
        * Change widget class name
        */
        public function change_widget_class( $class, $args ) {
            if ( ! empty( $args ) && ! empty( $args['id' ] ) ) {
                switch ( $args['id'] ) {
                    case 'profile':
                        return 'pt-widget_about';
                    case 'instagram':
                        return 'pt-widget_instagram';
                    case 'social':
                        return 'pt-widget_social';
                    case 'opening-hours':
                        return 'pt-widget_opening_hours';
                    case 'category':
                        return 'pt-widget_cat';
                    case 'posts':
                        return 'pt-widget_posts';
                }
            }
            return $class;
        }
        /**
        * Get the instagram widget wrapper div classname
        */
        public function instagram_widget_class( $class ) {
            return 'pt-widget_instagram';
        }
        /**
        * Get image sizes
        */
        public function get_image_sizes( $sizes, $args ) {
            return PatioTime_Utils_Image::get_image_sizes( $args );
        }
        /**
        * Get image size
        */
        public function get_image_size( $size, $args ) {
            return PatioTime_Utils_Image::get_image_size( $args );
        }
        /**
        * Set the options need to be translated as page id
        */
        public function translate_pages( $pages ) {
            return array_merge( array( 'patiotime_general_404_page_custom_block' ), (array) $pages );
        }
        /**
        * Set the options need to be translated as page id
        */
        public function translate_attachments( $attach ) {
            return array_merge( array(
                'theme_mod_custom_logo',
                'theme_mod_patiotime_page_background_image',
                'theme_mod_patiotime_general_popup_box_background_image',
                'theme_mod_patiotime_mobile_site_header_background_image',
                'theme_mod_patiotime_page_title_default_background_image'
            ), (array) $attach );
        }
        /**
        * Set the taxonomy need to be translated
        */
        public function translate_taxonomy( $tax ) {
            return $tax;
        }
        /**
        * Get current form settings
        */
        public function translate_mc4wp_form_settings( $val ) {
            return get_option( 'patiotime_polylang_mc4wp_settings', $val );
        }
        /**
        * Set the mc4wp form theme mod need to be translated
        */
        public function translate_mc4wp_form( $mods ) {
            return $mods;
        }
        /**
        * Disable image preload
        */
        public function disable_image_preload( $disable ) {
            return ! patiotime_module_enabled( 'patiotime_general_enable_progressive_image_loading' );
        }
        /**
        * Enable image lazy load
        */
        public function enable_lazy_load( $enable ) {
            return patiotime_module_enabled( 'patiotime_general_enable_lazy_load' );
        }
        /**
        * If show post metas dyanmically by AJAX
        */
        public function load_post_metas_by_ajax( $enable ) {
            return patiotime_module_enabled( 'patiotime_blog_general_load_post_metas_dynamically' );
        }
        /**
        * Post List args
        */
        public function post_list_args( $args ) {
            $params = array( 'layout' => 'layout-', 'columns' => 'column-' );
            foreach ( $params as $param => $rid ) {
                if ( isset( $args[ $param ] ) ) {
                    $args[ $param ] = str_replace( $rid, '', $args[ $param ] );
                }
            }
            return $args;
        }
        /**
        * Get opening hours
        */
        public function get_opening_hours( $list = array() ) {
            $open_hours = get_option( 'patiotime_open_hours', false );
            return ( false === $open_hours ) ? $list : array_merge( $list, $open_hours );
        }
        /**
        * Get restaurant info
        */
        public function get_restaurant_info( $info = array() ) {
            $settings = array(
                'patiotime_restaurant_address' => 'address',
                'patiotime_restaurant_map_url' => 'mapURL',
                'patiotime_restaurant_phone' => 'tel',
                'patiotime_restaurant_email' => 'email'
            );
            $valus = array();
            foreach ( $settings as $setting => $id ) {
                $value[ $id ] = get_option( $setting, '' );
            }
            return array_merge( $info, $value );
        }
        /**
        * Change elementor category for theme
        */
        public function element_category_title( $title ) {
            return esc_html__( 'PatioTime Elements', 'patiotime' );
        }
        /**
        * Change elementor widget name
        */
        public function change_elementor_widget_name( $name, $args ) {
            if ( ! empty( $args ) && ! empty( $args['id' ] ) ) {
                switch ( $args['id'] ) {
                    case 'button':
                        return 'pt_button';
                    case 'section-title':
                        return 'pt_title';
                    case 'rounded-image':
                        return 'pt_rounded_image';
                    case 'food-menu':
                        return 'pt_food_menu';
                    case 'opening-hours':
                        return 'pt_open_hour';
                    case 'restaurant-info':
                        return 'pt_info';
                    case 'social-menu':
                        return 'pt_social';
                    case 'site-logo':
                        return 'pt_logo';
                    case 'testimonials':
                        return 'pt_testimonials';
                    case 'image-gallery':
                        return 'pt_gallery';
                    case 'info-box':
                        return 'pt_info_box';
                    case 'contact-form7':
                        return 'pt_form_cf7';
                    case 'mc4wp':
                        return 'pt_signup';
                    case 'block-links':
                        return 'pt_block_links';
                    case 'opentable':
                        return 'pt_open_table';
                    case 'list':
                        return 'pt_list';
                    case 'instagram':
                        return 'pt_instagram';
                    case 'food-card':
                        return 'pt_food_card';
                    case 'count-down':
                        return 'pt_countdown';
                    case 'call-to-action':
                        return 'pt_call_to_action';
                    case 'team-member':
                        return 'pt_team';
                    case 'divider':
                        return 'pt_divider';
                    case 'vertical-divider':
                        return 'pt_vertical_divider';
                    case 'mobile-menu-toggle':
                        return 'pt_menu_toggle';
                    case 'navigation-menu':
                        return 'pt_menu';
                    case 'search-button':
                        return 'pt_search';
                    case 'mini-cart':
                        return 'pt_mini_cart';
                    case 'tabs':
                        return 'pt_tabs';
                    case 'blog':
                        return 'pt_blog';
                    case 'products':
                        return 'pt_products';
                    case 'slider':
                        return 'pt_slider';
                }
            }
            return $name;
        }
        /**
        * Count down label days
        */
        public function get_count_down_label_days( $label ) {
            return esc_html__( 'Days', 'patiotime' );
        }
        /**
        * Count down label hours
        */
        public function get_count_down_label_hours( $label ) {
            return esc_html__( 'Hours', 'patiotime' );
        }
        /**
        * Count down label minutes
        */
        public function get_count_down_label_minutes( $label ) {
            return esc_html__( 'Minutes', 'patiotime' );
        }
        /**
        * Count down label seconds
        */
        public function get_count_down_label_seconds( $label ) {
            return esc_html__( 'Seconds', 'patiotime' );
        }
        /**
        * Alter the widget title before/after html
        */
        public function check_sidebar_params( $params ) {
            if ( 0 === strpos( $params[0]['widget_id'], 'mc4wp_form_widget' ) ) {
                $params[0]['before_title'] = '<div class="widget-header"><h5 class="widget-title">';
                $params[0]['after_title'] = '</h5></div>';
            }
            return $params;
        }
        /**
        * Image loading attributes action callback function
        */
        public function image_loading_attributes() {
            add_filter( 'loftocean_disable_image_loading_optization', '__return_false', 9999 );
            add_filter( 'loftocean_disable_media_preload', array( $this, 'disable_image_preload' ), 10 );
            add_filter( 'loftocean_enable_media_lazy_load', array( $this, 'enable_lazy_load' ), 10 );
        }
        /**
        * Navigation menu for elementor widget
        */
        public function the_navigation_menu( $menu_id, $args ) {
            if ( ! empty( $menu_id ) ) {
                $nav = wp_get_nav_menu_object( $menu_id );
                if ( $nav ) {
                    $args = array_merge( array( 'container_class' => '', 'menu_class' => '', 'menu_id' => '', 'style' => 'inline' ), $args );
                    $menu_args = array(
                        'fallback_cb' => '',
                        'menu' => $nav,
                        'container' => 'nav',
                        'container_class' => $args[ 'container_class' ],
                        'container_id' => '',
                        'menu_class' => $args[ 'menu_class' ],
                        'menu_id' => $args[ 'menu_id' ],
            			'link_before' => '<span>',
            			'link_after' => '</span>'
                    );
                    switch( $args[ 'style' ] ) {
                        case 'footer':
                            $menu_args[ 'depth' ] = 1;
                            break;
                        case 'mobile':
                        case 'primary':
                            if ( ! class_exists( 'Patiotime_Walker_Nav_Menu' ) ) {
                                require_once PATIOTIME_THEME_INC . 'front/class-walker-menu.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
                            }
                            $menu_args[ 'walker' ] = ( 'mobile' == $args[ 'style' ] ) ? ( new Patiotime_Walker_Fullscreen_Nav_Menu() ) : ( new Patiotime_Walker_Nav_Menu() );
                            break;
                    }
                    wp_nav_menu( $menu_args );
                }
            }
        }
        /**
        * Elementor related features
        */
        public function elementor_loaded() {
        	add_filter( 'elementor/fonts/groups', array( $this, 'add_custom_font_group' ) );
            add_filter( 'elementor/fonts/additional_fonts', array( $this, 'add_custom_fonts_to_theme_group' ) );
        }
    	/**
    	* Add custom font group to font control
    	*/
    	public function add_custom_font_group( $font_groups ) {
    		return array_merge( array(
                'patiotime_adobe_fonts' => esc_html__( 'Adobe Fonts', 'patiotime' ),
                'patiotime_custom_fonts' => esc_html__( 'Custom Fonts', 'patiotime' )
            ), $font_groups );
    	}
    	/**
    	* Add custom fonts to theme group
    	* @return array
    	*/
    	public function add_custom_fonts_to_theme_group( $additional_fonts ) {
            $custom_fonts = patiotime_get_custom_fonts();
            if ( false !== $custom_fonts ) {
                $theme_fonts = array();
                if ( isset( $custom_fonts[ 'adobe' ] ) ) {
                    foreach( $custom_fonts[ 'adobe' ][ 'fonts' ] as $font ) {
                        $theme_fonts[ $font ] = 'patiotime_adobe_fonts';
                    }
                }
                if ( isset( $custom_fonts[ 'custom' ] ) ) {
                    $fonts = array();
                    foreach ( $custom_fonts[ 'custom' ] as $font ) {
                        $theme_fonts[ $font[ 'name' ] ] = 'patiotime_custom_fonts';
                    }
                }
                if ( patiotime_is_valid_array( $theme_fonts ) ) {
                    return array_merge( $theme_fonts, $additional_fonts );
                }
            }

    		return $additional_fonts;
    	}
        /**
        * Elementor editor json
        */
        public function elementor_editor_json( $json ) {
            $json[ 'defaultColorScheme' ] = patiotime_get_theme_mod( 'patiotime_general_color_scheme', '' );
            return $json;
        }
        /**
        * After site footer content
        */
        public function after_site_footer() {
            do_action( 'loftocean_site_footer' );
        }
    }
    new PatioTime_Theme_Core_Filters();
}
