<?php
if ( patiotime_module_enabled( 'patiotime_general_popup_box_enable' ) || patiotime_is_customize_preview() ) :
    $patiotime_popup_wrapper_class = array( 'pt-popup', 'pt-site-popup', 'pt-popup-box', patiotime_get_theme_mod( 'patiotime_general_popup_box_color_scheme' ) );
    'fullscreen' == patiotime_get_theme_mod( 'patiotime_general_popup_box_size' ) ? array_push( $patiotime_popup_wrapper_class, 'pt-popup-fullsize' ) : '';
    $patiotime_popup_background_image_id = patiotime_get_theme_mod( 'patiotime_general_popup_box_background_image' ); ?>

    <div class="<?php echo esc_attr( implode( ' ', $patiotime_popup_wrapper_class ) ); ?>">
        <?php if ( patiotime_does_attachment_exist( $patiotime_popup_background_image_id ) ) {
            patiotime_the_preload_bg( array(
                'id' 	=> $patiotime_popup_background_image_id,
    			'sizes' => PatioTime_Utils_Image::get_image_sizes( array( 'module' => 'site', 'sub_module' => 'popup-background' ) ),
    			'class' => 'screen-bg'
            ) );
        } ?>
        <span class="close-button"><?php esc_html_e( 'Close', 'patiotime' ); ?></span>
        <div class="container"><?php
            $patiotime_popup_custom_block = patiotime_get_theme_mod( 'patiotime_general_popup_box_custom_block' );
            if ( PatioTime_Utils_Custom_Block::check_custom_block( $patiotime_popup_custom_block ) ) {
                do_action( 'loftocean_the_custom_blocks_content', $patiotime_popup_custom_block );
            }; ?>
        </div>
    </div>
<?php endif;
