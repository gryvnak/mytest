<?php
$patiotime_is_customize_preview = false;
if ( patiotime_module_enabled( 'patiotime_show_back_to_top_button' ) || ( $patiotime_is_customize_preview = patiotime_is_customize_preview() ) ) : ?>
    <a href="#" class="to-top<?php if ( $patiotime_is_customize_preview ): ?> hide<?php endif; ?>"></a><?php
endif;
