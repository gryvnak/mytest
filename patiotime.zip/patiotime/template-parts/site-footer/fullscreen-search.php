<div class="search-screen">
	<div class="container">
		<span class="close-button"><?php esc_html_e( 'Close', 'patiotime' ); ?></span>
		<div class="search-wrapper">
			<?php get_search_form(); ?>
		</div>
	</div>
</div>
