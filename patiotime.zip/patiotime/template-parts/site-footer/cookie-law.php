<?php if ( patiotime_module_enabled( 'patiotime_general_cookie_law_enabled' ) || patiotime_is_customize_preview() ) :
    $cookie_law_wrapper_class = array( 'pt-cookies-popup', 'pt-popup' );
    if ( ( ! patiotime_module_enabled( 'patiotime_general_cookie_law_enabled' ) ) && patiotime_is_customize_preview() ) {
        array_push( $cookie_law_wrapper_class, 'customize-preview-initial-hidden' );
    } ?>
    <div class="<?php echo esc_attr( implode( ' ', $cookie_law_wrapper_class ) ); ?>">
    	<div class="container">
    		<div class="cookies-msg"><?php echo do_shortcode( patiotime_get_theme_mod( 'patiotime_general_cookie_law_message' ) ); ?></div>
            <div class="cookies-buttons">
    			<a href="#" rel="nofollow noopener" class="button pt-btn-rounded pt-btn-small"><?php echo esc_html( patiotime_get_theme_mod( 'patiotime_general_cookie_law_accept_button_text' ) ); ?></a>
    		</div>
    	</div>
    </div><?php
endif;
