<?php if ( $patiotime_before_site_footer_text = patiotime_get_theme_mod( 'patiotime_above_site_footer_text_content' ) ) : ?>
   <div class="before-footer">
       <div class="container"><?php echo do_shortcode( $patiotime_before_site_footer_text ); ?></div>
   </div><?php
endif;
