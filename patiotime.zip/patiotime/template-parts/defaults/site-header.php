<?php
$patiotime_show_all = isset( $args, $args[ 'site_header' ] ) && ( 'custom' == $args[ 'site_header' ] );
$patiotime_site_header_class = array( 'site-header', 'site-header-layout-default', 'dropdown-dark' );
( ! $patiotime_show_all ) && patiotime_module_enabled( 'patiotime_default_site_header_enable_overlap' ) ? array_push( $patiotime_site_header_class, 'overlap-header' ) : ''; ?>

<header id="masthead" class="<?php echo esc_attr( implode( ' ', $patiotime_site_header_class ) ); ?>"<?php patiotime_the_site_header_attrs(); ?>><?php
	$patiotime_show_top_bar = $patiotime_show_all || ( ! patiotime_module_enabled( 'patiotime_default_site_header_hide_top_bar' ) );
	$patiotime_show_search_icon = $patiotime_show_all || ( ! patiotime_module_enabled( 'patiotime_default_site_header_hide_search_icon' ) );
	$patiotime_show_cart = $patiotime_show_all || ( ! patiotime_module_enabled( 'patiotime_default_site_header_hide_cart' ) );
	$patiotime_restaurant_info = patiotime_get_restaurant_info();
	$patiotime_site_header_image = patiotime_get_site_header_image();
	if ( $patiotime_show_top_bar && patiotime_is_valid_array( $patiotime_restaurant_info ) && $patiotime_restaurant_info[ 'has_info' ] ) : ?>
	<div class="header-top-bar">
		<div class="container">
			<?php if ( $patiotime_restaurant_info[ 'address' ][ 'has' ] ) : ?>
            <div class="header-section header-left">
                <div class="pt-info pt-address">
					<?php if ( $patiotime_restaurant_info[ 'mapURL' ][ 'has'] ) : ?><a href="<?php echo esc_attr( $patiotime_restaurant_info[ 'mapURL' ][ 'info' ] ); ?>" target="_blank"><?php else : ?><span><?php endif; ?>
						<i class="fas fa-map-marker-alt"></i> <?php echo esc_html( $patiotime_restaurant_info[ 'address' ][ 'info' ] ); ?>
					<?php if ( $patiotime_restaurant_info[ 'mapURL' ][ 'has'] ) : ?></a><?php else : ?></span><?php endif; ?>
				</div>
            </div>
			<?php endif; ?>
			<?php if ( $patiotime_restaurant_info[ 'phone' ][ 'has' ] || $patiotime_restaurant_info[ 'email' ][ 'has' ] ) : ?>
            <div class="header-section header-right">
                <?php if ( $patiotime_restaurant_info[ 'phone' ][ 'has' ] ) : ?>
				<div class="pt-info pt-tel">
					<a href="tel:<?php echo esc_attr( $patiotime_restaurant_info[ 'phone' ][ 'info' ] ); ?>">
						<i class="fas fa-phone"></i> <?php echo esc_html( $patiotime_restaurant_info[ 'phone' ][ 'info' ] ); ?>
					</a>
				</div>
				<?php endif; ?>
				<?php if ( $patiotime_restaurant_info[ 'email' ][ 'has' ] ) : ?>
                <div class="pt-info pt-email">
					<a href="mailto:<?php echo esc_attr( $patiotime_restaurant_info[ 'email' ][ 'info' ] ); ?>">
						<i class="far fa-envelope"></i> <?php echo esc_html( $patiotime_restaurant_info[ 'email' ][ 'info' ] ); ?>
					</a>
				</div>
				<?php endif; ?>
            </div>
			<?php endif; ?>
		</div>
	</div><?php
	endif; ?>

	<div class="site-header-main<?php if ( ! empty( $patiotime_site_header_image ) ) : ?> with-bg<?php endif; ?>">
        <div class="container">
            <!-- .site-branding -->
            <div class="header-section branding header-left">
                <div<?php patiotime_the_site_branding_class(); ?>>
					<?php patiotime_the_custom_logo(); ?>
                    <p class="site-title">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
                    </p><?php
					$description = get_bloginfo( 'description', 'display' );
        			if ( ! empty( $description ) || is_customize_preview() ) : ?>
        				<p class="site-description"><?php echo wp_kses_post( $description ); ?></p><?php
    				endif; ?>
                </div>
            </div> <!-- end of .site-branding -->
			<?php patiotime_primary_nav( array(), '<div class="header-section menu">', '</div>', true ); ?>
            <div class="header-section header-right"><?php
				if ( $patiotime_show_search_icon ) : ?>
	                <div class="site-header-search">
	                    <span class="toggle-button"><span class="screen-reader-text"><?php esc_html_e( 'Search', 'patiotime' ); ?></span></span>
	                </div><?php
				endif;
				if ( $patiotime_show_cart && patiotime_is_woocommerce_activated() ) :
					$cart_url = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : WC()->cart->get_cart_url();
					$wc_cart = \WC()->cart; ?>
	                <div id="site-header-cart" class="site-header-cart">
	                    <a id="patiotime-cart-notification" class="cart-contents" href="<?php echo esc_url( $cart_url ); ?>" title="<?php esc_attr_e( 'View your shopping cart', 'patiotime' ); ?>">
							<span class="cart-icon"></span>
						</a><?php
						if ( isset( $wc_cart ) ) : ?>
		                    <div class="widget woocommerce widget_shopping_cart">
		                        <div class="widget_shopping_cart_content"><?php woocommerce_mini_cart(); ?></div>
		                    </div><?php
						endif; ?>
	                </div><?php
				endif; ?>
                <button id="menu-toggle" class="menu-toggle"><?php esc_html_e( 'Menu', 'patiotime' ); ?></button>
            </div>
        </div>
    </div>
</header>
