<?php
if ( ! class_exists( 'Patiotime_Walker_Nav_Menu' ) ) {
    require_once get_template_directory() . '/includes/front/class-walker-menu.php';
}
$patiotime_mobile_menu_wrap_class = isset( $args, $args[ 'class' ] ) ? 'sidemenu-default ' . $args[ 'class' ] : 'sidemenu-default'; ?>

<div <?php patiotime_the_mobile_menu_class( $patiotime_mobile_menu_wrap_class ); ?>><?php
    $mobile_site_header_background_image = patiotime_get_theme_mod( 'patiotime_mobile_site_header_background_image' );
    $background_image_args = array(
        'id' 	=> $mobile_site_header_background_image,
        'sizes' => PatioTime_Utils_Image::get_image_sizes( array( 'module' => 'site', 'sub_module' => 'mobile-menu-background' ) )
    ); ?>
    <div class="container"<?php patiotime_does_attachment_exist( $mobile_site_header_background_image ) ? patiotime_the_background_image_attrs( $background_image_args ) : ''; ?>>
        <div class="sidemenu-header">
            <span class="close-button"><?php esc_html_e( 'Close', 'patiotime' ); ?></span><?php
            $custom_logo_id = get_theme_mod( 'custom_logo' );
            if ( $custom_logo_id && patiotime_does_attachment_exist( $custom_logo_id ) ) :
                $logo_size = array( apply_filters( 'patiotime_mobile_menu_site_logo_width', 150 ), 9999999 ); ?>
                <div class="mobile-menu-logo">
                    <?php echo wp_get_attachment_image( $custom_logo_id, $logo_size, '', array( 'alt' => get_bloginfo( 'name', 'display' ) ) ); ?>
                </div><?php
            endif; ?>
        </div><?php
        patiotime_primary_nav( array(
            'container_id' => 'mobile-menu-site-navigation',
            'container_class' => 'main-navigation pt-menu-mobile',
            'menu_id' => 'mobile-menu-main-menu',
            'menu_class' => 'mobile-menu',
            'walker' => class_exists( 'Patiotime_Walker_Fullscreen_Nav_Menu' ) ? new Patiotime_Walker_Fullscreen_Nav_Menu() : ''
        ) );
        patiotime_social_menu( array( 'menu_id' => 'sidemenu-social-menu', 'container_id' => 'sidemenu-social-navigation' ) );
        $mobile_menu_copyright_text = patiotime_get_theme_mod( 'patiotime_mobile_site_header_copyright_text' );
        $mobile_is_customize_preview = patiotime_is_customize_preview();
        if ( ! empty( $mobile_menu_copyright_text ) || $mobile_is_customize_preview ) :
            $copyright_class = array( 'copyright' );
            empty( $mobile_menu_copyright_text ) && $mobile_is_customize_preview ? array_push( $copyright_class, 'hide' ) : ''; ?>
            <div class="<?php echo esc_attr( implode( ' ', $copyright_class ) ); ?>"><?php echo wp_kses_post( $mobile_menu_copyright_text ); ?></div><?php
        endif;
        $patiotime_restaurant_info = patiotime_get_restaurant_info();
        if ( patiotime_is_valid_array( $patiotime_restaurant_info ) ) : ?>
        <div class="sidemenu-footer">
            <?php if ( $patiotime_restaurant_info[ 'address' ][ 'has' ] ) : ?>
                <div class="pt-info pt-address">
					<?php if ( $patiotime_restaurant_info[ 'mapURL' ][ 'has'] ) : ?><a href="<?php echo esc_attr( $patiotime_restaurant_info[ 'mapURL' ][ 'info' ] ); ?>" target="_blank"><?php else : ?><span><?php endif; ?>
                        <i class="fas fa-map-marker-alt"></i> <?php echo esc_html( $patiotime_restaurant_info[ 'address' ][ 'info' ] ); ?>
                    <?php if ( $patiotime_restaurant_info[ 'mapURL' ][ 'has'] ) : ?></a><?php else : ?></span><?php endif; ?>
                </div>
            <?php endif; ?>
            <?php if ( $patiotime_restaurant_info[ 'phone' ][ 'has' ] ) : ?>
                <div class="pt-info pt-tel">
                    <a href="tel:<?php echo esc_attr( $patiotime_restaurant_info[ 'phone' ][ 'info' ] ); ?>">
                        <i class="fas fa-phone"></i> <?php echo esc_html( $patiotime_restaurant_info[ 'phone' ][ 'info' ] ); ?>
                    </a>
                </div>
            <?php endif; ?>
            <?php if ( $patiotime_restaurant_info[ 'email' ][ 'has' ] ) : ?>
                <div class="pt-info pt-email">
                    <a href="mailto:<?php echo esc_attr( $patiotime_restaurant_info[ 'email' ][ 'info' ] ); ?>">
                        <i class="far fa-envelope"></i> <?php echo esc_html( $patiotime_restaurant_info[ 'email' ][ 'info' ] ); ?>
                    </a>
                </div>
            <?php endif; ?>
        </div><?php
        endif; ?>
    </div>
</div>
