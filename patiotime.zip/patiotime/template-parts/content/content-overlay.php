<?php
$metas = patiotime_get_post_list_prop( 'post_meta', array() );
$metas_below_title = array_intersect( $metas, array( 'author', 'date', 'comment_counts' ) );
$has_post_thumbnail = has_post_thumbnail(); ?>

<article <?php post_class(); ?>><?php
    if ( $has_post_thumbnail ) : ?>
    <div class="featured-img"><?php
        patiotime_the_list_featured_image();
        patiotime_the_list_format_label(); ?>
    </div><?php
    endif; ?>

    <div class="post-content">
        <header class="post-header"><?php
        if ( count( $metas_below_title ) > 0 ) : ?>
        <div class="meta-wrap">
            <div class="meta"><?php
                patiotime_the_list_author( $metas );
                patiotime_the_list_date( $metas );
                patiotime_the_list_comment( $metas ); ?>
            </div>
        </div><?php
        endif;
        patiotime_the_list_post_title();
        patiotime_the_list_category( $metas ); ?>
        </header>
    </div>
</article>
