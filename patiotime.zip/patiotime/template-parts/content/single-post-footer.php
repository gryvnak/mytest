<?php
$patiotime_single_post_footer_show_tags = patiotime_module_enabled( 'patiotime_blog_single_post_page_footer_show_tags' );
$patiotime_single_post_footer_show_media_sharing = patiotime_is_theme_core_activated() && patiotime_module_enabled( 'patiotime_blog_single_post_page_footer_show_social_sharings' );
if ( $patiotime_single_post_footer_show_tags || $patiotime_single_post_footer_show_media_sharing ) : ?>
    <footer class="article-footer">
        <?php $patiotime_single_post_footer_show_tags ? patiotime_the_meta_tags() : ''; ?>
        <?php $patiotime_single_post_footer_show_media_sharing ? patiotime_the_social_bar() : ''; ?>
    </footer><?php
endif;
