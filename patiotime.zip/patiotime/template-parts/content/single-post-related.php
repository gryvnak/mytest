<?php
if ( patiotime_module_enabled( 'patiotime_blog_single_post_enable_related_posts' ) ) :
	$filter = patiotime_get_theme_mod( 'patiotime_blog_single_post_related_post_filter' );
	$related_title = patiotime_get_theme_mod( 'patiotime_blog_single_post_related_post_section_title' );
	$related_posts = apply_filters( 'patiotime_front_get_related_posts', '', $filter, 2 );
    $image_size = PatioTime_Utils_Image::get_image_size( array( 'module' => 'singular', 'sub_module' => 'related-posts' ) );
	if ( ! empty( $related_posts ) && ! is_wp_error( $related_posts ) && $related_posts->have_posts() ) : ?>

		<div class="related-posts">
			<h4 class="related-posts-title"><?php echo esc_html( $related_title ); ?></h4>
			<div class="posts layout-grid column-2 img-ratio-3-2">
                <div class="posts-wrapper"><?php
				while ( $related_posts->have_posts() ) :
					$related_posts->the_post();
					$title_content = get_the_title();
					$has_title = ! empty( $title_content );
					$post_url = get_permalink();
					$post_class = has_post_thumbnail() ? array( 'related-post', 'has-post-thumbnail' ) : array( 'related-post' ); ?>
					<article <?php post_class(); ?>>
						<?php if ( has_post_thumbnail() ) : ?>
							<div class="featured-img">
								<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( $image_size); ?></a>
							</div>
						<?php endif; ?>
						<div class="post-content">
                            <header class="post-header">
								<div class="meta-wrap">
	                                <div class="meta"><?php patiotime_the_meta_date( false ); ?></div>
	                                <?php patiotime_the_meta_category(); ?>
								</div>
                                <h2 class="post-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h2>
                            </header>
						</div>
					</article><?php
				endwhile;
				wp_reset_postdata(); ?>
                </div>
			</div>
		</div><?php
	 endif;
endif;
