<?php
$metas = patiotime_get_post_list_prop( 'post_meta', array() );
$metas_below_title = array_intersect( $metas, array( 'author', 'date', 'comment_counts' ) );
$has_post_thumbnail = has_post_thumbnail(); ?>

<article <?php post_class(); ?>><?php
    if ( $has_post_thumbnail ) : ?>
    <div class="featured-img"><?php
        patiotime_the_list_featured_image();
        patiotime_the_list_format_label(); ?>
    </div><?php
    endif; ?>

    <div class="post-content">
        <header class="post-header"><?php
        if ( patiotime_is_valid_array( $metas_below_title ) || in_array( 'category', $metas ) ) : ?>
            <div class="meta-wrap"><?php
                if ( count( $metas_below_title ) > 0 ) : ?>
                    <div class="meta"><?php
                        patiotime_the_list_author( $metas );
                        patiotime_the_list_date( $metas );
                        patiotime_the_list_comment( $metas ); ?>
                    </div><?php
                endif;
                patiotime_the_list_category( $metas ); ?>
            </div><?php
        endif;
        patiotime_the_list_post_title(); ?>
        </header><?php
		patiotime_the_list_excerpt( $metas );
		if ( in_array( 'read_more_btn', $metas ) ) : ?>
            <footer class="post-footer"><?php
                patiotime_the_list_more_btn( $metas ); ?>
            </footer><?php
        endif; ?>
    </div>
</article>
