<div class="no-results not-found">
    <header class="entry-header">
        <h2 class="entry-title"><?php esc_html_e( 'Nothing Found', 'patiotime' ); ?></h2>
    </header>
    <div class="entry-content">
        <p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'patiotime' ); ?></p>
        <?php get_search_form(); ?>
    </div>
</div>
