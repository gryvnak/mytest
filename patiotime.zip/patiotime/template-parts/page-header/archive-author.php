<header<?php patiotime_the_page_title_class(); ?>><?php
    $userID = get_queried_object_id();
    if ( apply_filters( 'loftocean_has_user_featured_image', false, $userID ) ) {
        do_action(
    		'loftocean_the_user_featured_image',
    		$userID,
    		PatioTime_Utils_Image::get_image_sizes( array( 'module' => 'site', 'sub_module' => 'page-header' ) ),
    		array( 'class' => 'page-title-bg' )
    	);
    } else {
        patiotime_the_default_page_header_background_image();
    } ?>
    <div class="container">
        <?php if ( patiotime_module_enabled( 'patiotime_page_title_show_breadcrumb' ) ) {
            patiotime_the_yoast_seo_breadcrumbs();
        } ?>
        <h1 class="entry-title"><?php printf(
            // translators: %s author display name
            esc_html( __( 'Author: %s', 'patiotime'  ) ),
            esc_html( get_the_author() )
        ); ?>
        </h1>
        <?php the_archive_description( '<div class="description">', '</div>' ); ?>
        <?php do_action( 'loftocean_front_the_user_social' ); ?>
    </div>
</header>
