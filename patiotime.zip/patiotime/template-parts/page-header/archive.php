<header<?php patiotime_the_page_title_class(); ?>>
    <?php patiotime_the_default_page_header_background_image(); ?>
    <div class="container">
        <?php if ( patiotime_module_enabled( 'patiotime_page_title_show_breadcrumb' ) ) {
            patiotime_the_yoast_seo_breadcrumbs();
        }
        the_archive_title( '<h1 class="entry-title">', '</h1>' );
        the_archive_description( '<div class="description">', '</div>' ); ?>
    </div>
</header>
