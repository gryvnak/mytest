<header<?php patiotime_the_page_title_class(); ?>>
    <?php patiotime_the_default_page_header_background_image(); ?>
    <div class="container">
        <?php if ( patiotime_module_enabled( 'patiotime_page_title_show_breadcrumb' ) ) {
            patiotime_the_yoast_seo_breadcrumbs();
        } ?>
        <h1 class="entry-title"><?php printf(
            // translators: %s search keyword
            esc_html( __( 'Search: %s', 'patiotime'  ) ),
            esc_html( get_search_query() )
        ); ?>
        </h1>
    </div>
</header>
