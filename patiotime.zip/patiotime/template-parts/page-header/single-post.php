<?php
if ( apply_filters( 'patiotime_show_post_title_section', true ) ) : ?>
    <header<?php patiotime_the_page_title_class( array( 'post-header-section' ), true ); ?>>
        <?php if ( has_post_thumbnail() ) {
            patiotime_the_preload_bg( array(
                'id' 	=> get_post_thumbnail_id(),
                'sizes' => PatioTime_Utils_Image::get_image_sizes( array( 'module' => 'site', 'sub_module' => 'page-header' ) ),
                'class' => 'page-title-bg'
            ) );
        } ?>
        <div class="container">
            <?php if ( patiotime_module_enabled( 'patiotime_blog_single_post_show_yoast_seo_breadcrumb' ) ) {
                patiotime_the_yoast_seo_breadcrumbs();
            } ?>
            <h1 class="entry-title"><?php the_title(); ?></h1>
            <?php
                $patiotime_single_post_header_metas = patiotime_get_single_post_header_meta();
                $patiotime_single_post_header_normal_metas = array_intersect( $patiotime_single_post_header_metas, array( 'author', 'category', 'comment_counter', 'publish_date' ) );
                if ( patiotime_is_valid_array( $patiotime_single_post_header_normal_metas ) || in_array( 'category', $patiotime_single_post_header_metas ) ) : ?>
                    <div class="meta-wrap"><?php
                    if ( patiotime_is_valid_array( $patiotime_single_post_header_normal_metas ) ) : ?>
                        <div class="meta"><?php
                            in_array( 'author', $patiotime_single_post_header_normal_metas ) ? patiotime_the_meta_author( false, true, esc_html__( 'By', 'patiotime' ) ) : '';
                            in_array( 'publish_date', $patiotime_single_post_header_normal_metas ) ? patiotime_the_meta_date( true ) : '';
                            in_array( 'comment_counter', $patiotime_single_post_header_normal_metas ) ? patiotime_the_meta_comment( true ) : ''; ?>
                        </div><?php
                    endif;
                    in_array( 'category', $patiotime_single_post_header_metas ) ? patiotime_the_meta_category() : ''; ?>
                    </div><?php
                endif;
            ?>
        </div>
    </header><?php
endif;
