<?php 
if ( apply_filters( 'patiotime_show_page_title_section', true ) ) : ?>
    <header<?php patiotime_the_page_title_class(); ?>>
        <?php patiotime_the_default_page_header_background_image(); ?>
        <div class="container"><?php
            $patiotime_woocommerce_static_pages = apply_filters( 'patiotime_woocommerce_static_pages', array() );
            if ( patiotime_is_valid_array( $patiotime_woocommerce_static_pages ) && in_array( get_the_ID(), $patiotime_woocommerce_static_pages ) ) {
                do_action( 'patiotime_woocommerce_breadcrumbs' );
            } elseif ( patiotime_module_enabled( 'patiotime_page_title_show_breadcrumb' ) && ! is_front_page() ) {
                patiotime_the_yoast_seo_breadcrumbs();
            } ?>
            <h1 class="entry-title"><?php the_title(); ?></h1>
        </div>
    </header><?php
endif;
