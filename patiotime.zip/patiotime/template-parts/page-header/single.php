<header<?php patiotime_the_page_title_class(); ?>>
    <div class="container">
        <?php if ( patiotime_module_enabled( 'patiotime_page_title_show_breadcrumb' ) && ! is_front_page() ) {
            patiotime_the_yoast_seo_breadcrumbs();
        } ?>
        <h1 class="entry-title"><?php the_title(); ?></h1>
    </div>
</header>
